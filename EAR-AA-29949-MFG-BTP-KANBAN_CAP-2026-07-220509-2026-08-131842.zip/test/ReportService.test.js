const { GET, expect, axios } = require('./bootstrap');
axios.defaults.auth = { username: 'alice', password: '' };

describe('ReportService OData APIs', async () => {
  it('serves demandReport', async () => {
    const { data } = await GET`/odata/v4/report/demandReport ${{
      params: { plant: "'0001'", top: 2, partGroup: 'PG-00002' },
    }}`;
    expect(data).to.deep.equal({
      '@odata.context': '$metadata#ReportService.DemandReportResponse',
      '@odata.count': 3,
      receivingPlantName: 'Odessa',
      demandReportItems: [
        {
          material: 'MATERIAL_NO-00002',
          description: 'MaterialDescription-00002',
          partGroup: 'PG-00002',
          supplyingPlantMax: 90,
          supplyingPlantQohWip: 95,
          shippedQty: 15,
          receivingPlantDemand: 40,
          productionDemand: 20,
        },
        {
          material: 'MATERIAL_NO-00010',
          description: 'MaterialDescription-00010',
          partGroup: 'PG-00002',
          supplyingPlantMax: 88,
          supplyingPlantQohWip: 75,
          shippedQty: 0,
          receivingPlantDemand: 0,
          productionDemand: 13,
        },
      ],
    });

    it('supports pagination', async () => {
      const { data } = await GET`/odata/v4/report/demandReport ${{
        params: {
          plant: "'0001'",
          top: 1,
          skip: 1,
          partGroup: 'PG-00002',
        },
      }}`;
      expect(data).to.deep.equal({
        '@odata.context': '$metadata#ReportService.DemandReportResponse',
        '@odata.count': 3,
        receivingPlantName: 'Odessa',
        demandReportItems: [
          {
            material: 'MATERIAL_NO-00010',
            description: 'MaterialDescription-00010',
            partGroup: 'PG-00002',
            supplyingPlantMax: 88,
            supplyingPlantQohWip: 75,
            shippedQty: 0,
            receivingPlantDemand: 0,
            productionDemand: 13,
          },
        ],
      });
    });

    it('returns bad request when mandatory parameter is missing', async () => {
      try {
        await GET`/odata/v4/report/demandReport`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('returns bad request when plant parameter is not a supplying plant', async () => {
      try {
        await GET`/odata/v4/report/demandReport ${{
          params: { plant: "'0003'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Selected plant must be a supplying plant.'
        );
      }
    });
  });

  it('serves orderReport', async () => {
    const { data } = await GET`/odata/v4/report/orderReport ${{
      params: { plant: "'0002'" },
    }}`;
    expect(data.orderReportItems).to.deep.equal([
      {
        material: 'MATERIAL_NO-00002',
        description: 'MaterialDescription-00002',
        partGroup: 'PG-00002',
        receivingPlantOrderQty: 40,
        supplyingPlantQoh: 75,
      },
      {
        material: 'MATERIAL_NO-00005',
        description: 'MaterialDescription-00005',
        partGroup: 'PG-00002',
        receivingPlantOrderQty: 0,
        supplyingPlantQoh: 0,
      },
      {
        material: 'MATERIAL_NO-00007',
        description: 'MaterialDescription-00007',
        partGroup: 'PG-00002',
        receivingPlantOrderQty: 0,
        supplyingPlantQoh: 0,
      },
    ]);

    expect(data.supplyingPlantName).to.equal('BA');

    it('supports pagination', async () => {
      const { data } = await GET`/odata/v4/report/orderReport ${{
        params: {
          plant: "'0002'",
          top: 1,
          skip: 1,
        },
      }}`;
      expect(data.orderReportItems).to.deep.equal([
        {
          material: 'MATERIAL_NO-00005',
          description: 'MaterialDescription-00005',
          partGroup: 'PG-00002',
          receivingPlantOrderQty: 0,
          supplyingPlantQoh: 0,
        },
      ]);

      it('returns total count', async () => {
        expect(data['@odata.count']).to.equal(3);
      });
    });

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/report/orderReport`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('returns bad request when plant parameter is not a receiving plant', async () => {
      try {
        await GET`/odata/v4/report/orderReport ${{
          params: { plant: "'0001'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Selected plant must be a receiving plant.'
        );
      }
    });
  });

  it('serves comparisonReport', async () => {
    const { data } = await GET`/odata/v4/report/comparisonReport ${{
      params: {
        plants: '0002,0001,0003',
        filter: "partGroup%20eq%20'PG-00002'",
      },
    }}`;
    expect(data).to.deep.equal({
      '@odata.context': '$metadata#ReportService.ComparisonReportResponse',
      '@odata.count': 3,
      value: [
        {
          material: 'MATERIAL_NO-00002',
          description: 'MaterialDescription-00002',
          partGroup: 'PG-00002',
          plants: [
            {
              plant: '0001',
              plantName: 'BA',
              qoh: 75,
              category: 'optimalStock',
            },
            {
              plant: '0002',
              plantName: 'Odessa',
              qoh: 75,
              category: 'stockOut',
            },
            {
              plant: '0003',
              plantName: 'Yetocome',
              qoh: 10,
              category: 'stockOut',
            },
          ],
        },
        {
          material: 'MATERIAL_NO-00010',
          description: 'MaterialDescription-00010',
          partGroup: 'PG-00002',
          plants: [
            {
              plant: '0001',
              plantName: 'BA',
              qoh: 71,
              category: 'optimalStock',
            },
            {
              plant: '0002',
              plantName: 'Odessa',
              qoh: 71,
              category: 'stockOut',
            },
            {
              plant: '0003',
              plantName: 'Yetocome',
              qoh: 0,
              category: 'stockOut',
            },
          ],
        },
        {
          material: 'MATERIAL_NO-00013',
          description: 'MaterialDescription-00013',
          partGroup: 'PG-00002',
          plants: [
            {
              plant: '0001',
              plantName: 'BA',
              qoh: 100,
              category: 'overStock',
            },
            {
              plant: '0002',
              plantName: 'Odessa',
              qoh: 100,
              category: 'stockOut',
            },
            {
              plant: '0003',
              plantName: 'Yetocome',
              qoh: 0,
              category: 'stockOut',
            },
          ],
        },
      ],
    });

    it('supports custom qoh filter', async () => {
      const { data } =
        await GET`/odata/v4/report/comparisonReport?plants=0002,0001,0003&filter=partGroup%20eq%20%27PG-00002%27&qohFilter={"0001":"qoh%20ge%2072%20and%20qoh%20lt%20100","0002":"qoh%20ge%2072"%20}`;

      expect(data).to.deep.equal({
        '@odata.context': '$metadata#ReportService.ComparisonReportResponse',
        '@odata.count': 1,
        value: [
          {
            material: 'MATERIAL_NO-00002',
            description: 'MaterialDescription-00002',
            partGroup: 'PG-00002',
            plants: [
              {
                plant: '0001',
                plantName: 'BA',
                qoh: 75,
                category: 'optimalStock',
              },
              {
                plant: '0002',
                plantName: 'Odessa',
                qoh: 75,
                category: 'stockOut',
              },
              {
                plant: '0003',
                plantName: 'Yetocome',
                qoh: 10,
                category: 'stockOut',
              },
            ],
          },
        ],
      });
    });

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/report/comparisonReport`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Plants is mandatory.'
        );
      }
    });

    it('returns bad request when the number of plants is less than 2 or greater than 3', async () => {
      try {
        await GET`/odata/v4/report/comparisonReport ${{
          params: { plants: "'0001'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Number of selected plants must be between 1 and 2.'
        );
      }
    });

    it('returns not found if the passed plants do not exist', async () => {
      try {
        await GET`/odata/v4/report/comparisonReport ${{
          params: { plants: '0001,0002,0004' },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(404);
        expect(err.response.data.error.message).to.equal('Plant not found.');
      }
    });

    it('supports pagination', async () => {
      const { data } = await GET`/odata/v4/report/comparisonReport ${{
        params: {
          plants: '0002,0001,0003',
          filter: "partGroup%20eq%20'PG-00002'",
          top: 1,
          skip: 1,
        },
      }}`;
      expect(data).to.deep.equal({
        '@odata.context': '$metadata#ReportService.ComparisonReportResponse',
        '@odata.count': 3,
        value: [
          {
            material: 'MATERIAL_NO-00010',
            description: 'MaterialDescription-00010',
            partGroup: 'PG-00002',
            plants: [
              {
                plant: '0001',
                plantName: 'BA',
                qoh: 71,
                category: 'optimalStock',
              },
              {
                plant: '0002',
                plantName: 'Odessa',
                qoh: 71,
                category: 'stockOut',
              },
              {
                plant: '0003',
                plantName: 'Yetocome',
                qoh: 0,
                category: 'stockOut',
              },
            ],
          },
        ],
      });
    });
  });

  it('serves combinedInventoryReport', async () => {
    const { data } = await GET`/odata/v4/report/combinedInventoryReport ${{
      params: { supplyingPlant: "'0001'", receivingPlant: "'0002'" },
    }}`;
    expect(data).to.deep.equal({
      '@odata.context':
        '$metadata#ReportService.CombinedInventoryReportResponse',
      '@odata.count': 3,
      value: [
        {
          material: 'MATERIAL_NO-00002',
          description: 'MaterialDescription-00002',
          partGroup: 'PG-00002',
          inTransit: 15,
          receivingPlant: {
            plant: '0002',
            plantName: 'Odessa',
            min: 70,
            max: 160,
            qoh: 0,
          },
          supplyingPlant: {
            plant: '0001',
            plantName: 'BA',
            min: 60,
            max: 90,
            qoh: 75,
            wip: 20,
          },
          combinedSummary: {
            plantName: 'BA + Odessa',
            min: 130,
            max: 250,
            qoh: 75,
            wip: 20,
          },
        },
        {
          material: 'MATERIAL_NO-00005',
          description: 'MaterialDescription-00005',
          partGroup: 'PG-00002',
          inTransit: 3,
          receivingPlant: {
            plant: '0002',
            plantName: 'Odessa',
            min: 65,
            max: 20,
            qoh: 65,
          },
          supplyingPlant: {
            plant: '0001',
            plantName: 'BA',
            min: 0,
            max: 0,
            qoh: 0,
            wip: 0,
          },
          combinedSummary: {
            plantName: 'BA + Odessa',
            min: 65,
            max: 20,
            qoh: 65,
            wip: 0,
          },
        },
        {
          material: 'MATERIAL_NO-00007',
          description: 'MaterialDescription-00007',
          partGroup: 'PG-00002',
          inTransit: 0,
          receivingPlant: {
            plant: '0002',
            plantName: 'Odessa',
            min: 50,
            max: 110,
            qoh: 50,
          },
          supplyingPlant: {
            plant: '0001',
            plantName: 'BA',
            min: 0,
            max: 0,
            qoh: 0,
            wip: 0,
          },
          combinedSummary: {
            plantName: 'BA + Odessa',
            min: 50,
            max: 110,
            qoh: 50,
            wip: 0,
          },
        },
      ],
    });

    it('returns not found if the passed plants combination does not exist', async () => {
      try {
        await GET`/odata/v4/report/combinedInventoryReport ${{
          params: { supplyingPlant: "'0002'", receivingPlant: "'0001'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(404);
        expect(err.response.data.error.message).to.equal(
          'Plant combination not found.'
        );
      }
    });

    it('returns bad request when supplyingPlant parameter is missing', async () => {
      try {
        await GET`/odata/v4/report/combinedInventoryReport ${{
          params: { receivingPlant: "'0001'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Supplying plant is mandatory.'
        );
      }
    });

    it('returns bad request when receivingPlant parameter is missing', async () => {
      try {
        await GET`/odata/v4/report/combinedInventoryReport ${{
          params: { supplyingPlant: "'0001'" },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Receiving plant is mandatory.'
        );
      }
    });

    it('supports pagination', async () => {
      const { data } = await GET`/odata/v4/report/combinedInventoryReport ${{
        params: {
          supplyingPlant: "'0001'",
          receivingPlant: "'0002'",
          top: 1,
          skip: 1,
        },
      }}`;
      expect(data.value).to.deep.equal([
        {
          material: 'MATERIAL_NO-00005',
          description: 'MaterialDescription-00005',
          partGroup: 'PG-00002',
          inTransit: 3,
          receivingPlant: {
            plant: '0002',
            plantName: 'Odessa',
            min: 65,
            max: 20,
            qoh: 65,
          },
          supplyingPlant: {
            plant: '0001',
            plantName: 'BA',
            min: 0,
            max: 0,
            qoh: 0,
            wip: 0,
          },
          combinedSummary: {
            plantName: 'BA + Odessa',
            min: 65,
            max: 20,
            qoh: 65,
            wip: 0,
          },
        },
      ]);
    });
  });
});
