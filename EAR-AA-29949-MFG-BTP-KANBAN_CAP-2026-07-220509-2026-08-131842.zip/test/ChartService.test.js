const { GET, expect, axios } = require('./bootstrap');
axios.defaults.auth = { username: 'admin', password: 'admin' };

describe('ChartService OData APIs', async () => {
  it('serves healthIndex', async () => {
    const { data } = await GET`/odata/v4/chart/healthIndex ${{
      params: {
        plant: "'0001'",
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(data.value).to.containSubset([
      {
        partGroup: 'PG-00001',
        healthIndexItems: [
          {
            month: '2026-06',
            avgTotalScore: 85.833,
            grade: 'B',
          },
          {
            month: '2026-07',
            avgTotalScore: null,
            grade: 'F',
          },
          {
            month: '2026-08',
            avgTotalScore: null,
            grade: 'F',
          },
        ],
      },
      {
        partGroup: 'PG-00002',
        healthIndexItems: [
          {
            month: '2026-06',
            avgTotalScore: 81.5,
            grade: 'B',
          },
          {
            month: '2026-07',
            avgTotalScore: 75,
            grade: 'C',
          },
          {
            month: '2026-08',
            avgTotalScore: null,
            grade: 'F',
          },
        ],
      },
    ]);

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/chart/healthIndex`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('validates startDate and endDate', async () => {
      try {
        await GET`/odata/v4/chart/healthIndex ${{
          params: {
            plant: "'0001'",
            startDate: '2026-06-10',
            endDate: '2026-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'End date must be after start date.'
        );
      }
    });

    it('limits startDate and endDate range to 365 days', async () => {
      try {
        await GET`/odata/v4/chart/healthIndex ${{
          params: {
            plant: "'0001'",
            startDate: '2025-06-10',
            endDate: '2027-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Date range must be less than 365 days.'
        );
      }
    });
  });

  it('serves sumOfEvents', async () => {
    const { data: outOfStock } = await GET`/odata/v4/chart/sumOfEvents ${{
      params: {
        plant: "'0001'",
        event: 'outOfStock',
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(outOfStock.value).to.containSubset([
      {
        partGroup: 'PG-00002',
        sumOfEventsItems: [
          {
            month: '2026-06',
            count: 1,
          },
          {
            month: '2026-07',
            count: 1,
          },
          {
            month: '2026-08',
            count: 0,
          },
        ],
      },
      {
        partGroup: 'PG-00001',
        sumOfEventsItems: [
          {
            month: '2026-06',
            count: 3,
          },
          {
            month: '2026-07',
            count: 0,
          },
          {
            month: '2026-08',
            count: 0,
          },
        ],
      },
    ]);

    const { data: overStock } = await GET`/odata/v4/chart/sumOfEvents ${{
      params: {
        plant: "'0001'",
        event: 'overStock',
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(overStock.value).to.containSubset([
      {
        partGroup: 'PG-00002',
        sumOfEventsItems: [
          {
            month: '2026-06',
            count: 1,
          },
          {
            month: '2026-07',
            count: 0,
          },
          {
            month: '2026-08',
            count: 0,
          },
        ],
      },
      {
        partGroup: 'PG-00001',
        sumOfEventsItems: [
          {
            month: '2026-06',
            count: 4,
          },
          {
            month: '2026-07',
            count: 0,
          },
          {
            month: '2026-08',
            count: 0,
          },
        ],
      },
    ]);

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/chart/sumOfEvents`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('validates event enum', async () => {
      try {
        await GET`/odata/v4/chart/sumOfEvents ${{
          params: {
            plant: "'0001'",
            event: 'unknown',
            startDate: '2026-06-10',
            endDate: '2026-08-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Event is invalid.');
      }
    });

    it('validates startDate and endDate', async () => {
      try {
        await GET`/odata/v4/chart/sumOfEvents ${{
          params: {
            plant: "'0001'",
            event: 'outOfStock',
            startDate: '2026-06-10',
            endDate: '2026-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'End date must be after start date.'
        );
      }
    });

    it('limits startDate and endDate range to 365 days', async () => {
      try {
        await GET`/odata/v4/chart/sumOfEvents ${{
          params: {
            plant: "'0001'",
            event: 'outOfStock',
            startDate: '2025-06-10',
            endDate: '2027-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Date range must be less than 365 days.'
        );
      }
    });
  });

  it('serves groupControlChart', async () => {
    const { data } = await GET`/odata/v4/chart/groupControlChart ${{
      params: {
        plant: "'0001'",
        partGroup: 'PG-00002',
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(data.value).to.containSubset([
      {
        date: '2026-06-19',
        avgTotalScore: 78,
        A: 100,
        B: 89.999,
        C: 79.999,
        D: 69.999,
        F: 59.999,
      },
      {
        date: '2026-06-20',
        avgTotalScore: 85,
        A: 100,
        B: 89.999,
        C: 79.999,
        D: 69.999,
        F: 59.999,
      },
      {
        date: '2026-07-19',
        avgTotalScore: 75,
        A: 100,
        B: 89.999,
        C: 79.999,
        D: 69.999,
        F: 59.999,
      },
    ]);

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/chart/groupControlChart`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('validates startDate and endDate', async () => {
      try {
        await GET`/odata/v4/chart/groupControlChart ${{
          params: {
            plant: "'0001'",
            partGroup: 'PG-00002',
            startDate: '2026-06-10',
            endDate: '2026-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'End date must be after start date.'
        );
      }
    });

    it('limits startDate and endDate range to 365 days', async () => {
      try {
        await GET`/odata/v4/chart/groupControlChart ${{
          params: {
            plant: "'0001'",
            partGroup: 'PG-00002',
            startDate: '2025-06-10',
            endDate: '2027-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Date range must be less than 365 days.'
        );
      }
    });
  });

  it('serves controlChart', async () => {
    const { data } = await GET`/odata/v4/chart/controlChart ${{
      params: {
        plant: "'0001'",
        material: 'MATERIAL_NO-00001',
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(data.value).to.containSubset([
      {
        date: '2026-06-18',
        max: 123,
        safetyStock: 50,
        buffer: 50,
        qoh: 98,
      },
      {
        date: '2026-06-20',
        max: 123,
        safetyStock: 50,
        buffer: 50,
        qoh: 100,
      },
    ]);

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/chart/controlChart`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('validates startDate and endDate', async () => {
      try {
        await GET`/odata/v4/chart/controlChart ${{
          params: {
            plant: "'0001'",
            material: 'MATERIAL_NO-00001',
            startDate: '2026-06-10',
            endDate: '2026-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'End date must be after start date.'
        );
      }
    });

    it('limits startDate and endDate range to 365 days', async () => {
      try {
        await GET`/odata/v4/chart/controlChart ${{
          params: {
            plant: "'0001'",
            material: 'MATERIAL_NO-00001',
            startDate: '2025-06-10',
            endDate: '2027-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Date range must be less than 365 days.'
        );
      }
    });

    it('returns not found when material is not found', async () => {
      try {
        await GET`/odata/v4/chart/controlChart ${{
          params: {
            plant: "'0001'",
            material: 'MATERIAL_NO-99999',
            startDate: '2026-06-10',
            endDate: '2026-08-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(404);
        expect(err.response.data.error.message).to.equal('Material not found.');
      }
    });
  });

  it('serves groupSummary', async () => {
    const { data } = await GET`/odata/v4/chart/groupSummary ${{
      params: {
        plant: "'0001'",
        partGroup: 'PG-00002',
        startDate: '2026-06-10',
        endDate: '2026-08-10',
      },
    }}`;
    expect(data.value).to.containSubset([
      {
        material: 'MATERIAL_NO-00002',
        description: 'MaterialDescription-00002',
        avgTotalScores: [
          {
            month: '2026-06',
            avgTotalScore: 81.5,
          },
          {
            month: '2026-07',
            avgTotalScore: null,
          },
          {
            month: '2026-08',
            avgTotalScore: null,
          },
        ],
      },
      {
        material: 'MATERIAL_NO-00010',
        description: 'MaterialDescription-00010',
        avgTotalScores: [
          {
            month: '2026-06',
            avgTotalScore: null,
          },
          {
            month: '2026-07',
            avgTotalScore: 75,
          },
          {
            month: '2026-08',
            avgTotalScore: null,
          },
        ],
      },
    ]);

    it('returns bad request when mandatory parameters are missing', async () => {
      try {
        await GET`/odata/v4/chart/groupSummary`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('validates startDate and endDate', async () => {
      try {
        await GET`/odata/v4/chart/groupSummary ${{
          params: {
            plant: "'0001'",
            partGroup: 'PG-00002',
            startDate: '2026-06-10',
            endDate: '2026-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'End date must be after start date.'
        );
      }
    });

    it('limits startDate and endDate range to 365 days', async () => {
      try {
        await GET`/odata/v4/chart/groupSummary ${{
          params: {
            plant: "'0001'",
            partGroup: 'PG-00002',
            startDate: '2025-06-10',
            endDate: '2027-06-10',
          },
        }}`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Date range must be less than 365 days.'
        );
      }
    });
  });
});
