const cds = require('@sap/cds');

cds.env.folders.app = '_disabled_app_folder_';

module.exports = cds.test(__dirname + '/..', '--with-mocks');
