const { GET, POST, expect, axios } = require('./bootstrap');
axios.defaults.auth = { username: 'alice', password: '' };

describe('ChampionXService OData APIs', async () => {
  it('serves materialData', async () => {
    const { data } =
      await GET`/odata/v4/champion-x/MaterialData ${{ params: { $select: 'plant,material' } }}`;
    expect(data.value).to.containSubset([
      { plant: '0001', material: 'MATERIAL_NO-00001' },
      { plant: '0001', material: 'MATERIAL_NO-00002' },
      { plant: '0002', material: 'MATERIAL_NO-00002' },
      { plant: '0003', material: 'MATERIAL_NO-00003' },
    ]);
  });

  it('serves SerialNumberData', async () => {
    const { data } = await GET`/odata/v4/champion-x/SerialNumberData?
      $select=material,serialNumber,plant&
      $filter=material eq 'MATERIAL_NO-00007' and plant eq '0002'`;
    expect(data.value).to.containSubset([
      {
        material: 'MATERIAL_NO-00007',
        serialNumber: 'SlNo-12207396',
        plant: '0002',
      },
      {
        material: 'MATERIAL_NO-00007',
        serialNumber: 'SlNo-12207397',
        plant: '0002',
      },
    ]);
  });

  it('serves materialMovement', async () => {
    it('rejects when mandatory parameters are missing', async () => {
      try {
        await POST`/odata/v4/champion-x/materialMovement`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Direction is mandatory.'
        );
      }
    });

    it('rejects when material is not found', async () => {
      try {
        await POST(`/odata/v4/champion-x/materialMovement`, {
          direction: 'PLUS',
          plant: '0001',
          material: 'MATERIAL_NO-XXXXX',
          quantity: 10,
        });
      } catch (err) {
        expect(err.response.status).to.equal(404);
        expect(err.response.data.error.message).to.equal('Material not found.');
      }
    });

    it('rejects when quantity and serial numbers length do not match for serialized material', async () => {
      try {
        await POST(`/odata/v4/champion-x/materialMovement`, {
          direction: 'PLUS',
          plant: '0002',
          material: 'MATERIAL_NO-00007',
          quantity: 2,
          serialNumbers: ['SlNo-12207396'],
        });
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal(
          'Quantity and length of serial numbers are not the same.'
        );
      }
    });
  });
});
