const { GET, expect, axios } = require('./bootstrap');
axios.defaults.auth = { username: 'alice', password: '' };

describe('DashboardService OData APIs', () => {
  it('serves getPlants', async () => {
    const { data } = await GET`/odata/v4/dashboard/getPlants`;
    expect(data.value).to.deep.equal([
      {
        plant: '0001',
        plantName: 'BA',
        isSupplying: true,
        isReceiving: false,
      },
      {
        plant: '0002',
        plantName: 'Odessa',
        isSupplying: true,
        isReceiving: true,
      },
      {
        plant: '0003',
        plantName: 'Yetocome',
        isSupplying: false,
        isReceiving: true,
      },
    ]);
  });

  it('serves getRelatedPlants', async () => {
    const { data } =
      await GET`/odata/v4/dashboard/getRelatedPlants?plant='0001'`;
    expect(data.value).to.deep.equal([
      {
        plant: '0002',
        plantName: 'Odessa',
        isSupplying: false,
        isReceiving: true,
      },
    ]);

    it('returns bad request when plant parameter is missing', async () => {
      try {
        await GET`/odata/v4/dashboard/getRelatedPlants`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });

    it('returns not found if the passed plant does not exist', async () => {
      try {
        await GET`/odata/v4/dashboard/getRelatedPlants?plant='0004'`;
      } catch (err) {
        expect(err.response.status).to.equal(404);
        expect(err.response.data.error.message).to.equal('Plant not found.');
      }
    });

    it('returns multiple related plants', async () => {
      const { data } =
        await GET`/odata/v4/dashboard/getRelatedPlants?plant='0002'`;
      expect(data.value).to.deep.equal([
        {
          plant: '0001',
          plantName: 'BA',
          isSupplying: true,
          isReceiving: false,
        },
        {
          plant: '0003',
          plantName: 'Yetocome',
          isSupplying: false,
          isReceiving: true,
        },
      ]);
    });
  });

  it('serves getPartGroups', async () => {
    const { data } = await GET`/odata/v4/dashboard/getPartGroups?plant='0001'`;
    expect(data.value).to.deep.equal([
      {
        partGroup: 'PG-00001',
      },
      {
        partGroup: 'PG-00002',
      },
    ]);

    it('searches partGroup in getPartGroups', async () => {
      const { data } =
        await GET`/odata/v4/dashboard/getPartGroups?plant='0001'&search='02'`;
      expect(data.value).to.deep.equal([
        {
          partGroup: 'PG-00002',
        },
      ]);
    });

    it('returns bad request when plant parameter is missing', async () => {
      try {
        await GET`/odata/v4/dashboard/getPartGroups`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });
  });

  it('serves kanbanDashboard', async () => {
    const { data } = await GET`/odata/v4/dashboard/kanbanDashboard ${{
      params: {
        plant: "'0001'",
        partGroup: 'PG-00002',
      },
    }}`;
    expect(data).to.deep.equal({
      '@odata.context': '$metadata#DashboardService.Kanban',
      stockOut: [],
      underStock: [],
      triggerPoint: [],
      optimalStock: [
        {
          plant: '0001',
          material: 'MATERIAL_NO-00002',
          description: 'MaterialDescription-00002',
          partGroup: 'PG-00002',
          min: 60,
          buffer: 10,
          board: 'Y',
          baseUnit: '174',
          max: 90,
          trigger: 30,
          qoh: 75,
          stagingQoh: 65,
          inTransit: 5,
          safetyStock: 60,
          wip: 20,
          wipQoh: 95,
          orderQty: 0,
          isSerialized: false,
          batch: null,
          mainSloc: '3000',
          stagingSloc: '3001',
        },
        {
          plant: '0001',
          material: 'MATERIAL_NO-00010',
          description: 'MaterialDescription-00010',
          partGroup: 'PG-00002',
          min: 58,
          buffer: 12,
          board: 'Y',
          baseUnit: '176',
          max: 88,
          trigger: 28,
          qoh: 71,
          stagingQoh: 61,
          inTransit: 4,
          safetyStock: 58,
          wip: 4,
          wipQoh: 75,
          orderQty: 0,
          isSerialized: true,
          batch: null,
          mainSloc: '3000',
          stagingSloc: '3001',
        },
      ],
      overStock: [
        {
          plant: '0001',
          material: 'MATERIAL_NO-00013',
          description: 'MaterialDescription-00013',
          partGroup: 'PG-00002',
          min: 62,
          buffer: 15,
          board: 'Y',
          baseUnit: '172',
          max: 85,
          trigger: 100,
          qoh: 90,
          stagingQoh: 80,
          inTransit: 3,
          safetyStock: 62,
          wip: 4,
          wipQoh: 94,
          orderQty: 10,
          isSerialized: true,
          batch: null,
          mainSloc: '3000',
          stagingSloc: '3001',
        },
      ],
    });

    it('searches material and description in kanbanDashboard', async () => {
      const { data } = await GET`/odata/v4/dashboard/kanbanDashboard ${{
        params: {
          plant: "'0001'",
          search: 'Description-00002',
        },
      }}`;
      expect(data.optimalStock).to.containSubset([
        {
          partGroup: 'PG-00002',
          material: 'MATERIAL_NO-00002',
          description: 'MaterialDescription-00002',
        },
      ]);
    });

    it('returns bad request when plant parameter is missing', async () => {
      try {
        await GET`/odata/v4/dashboard/kanbanDashboard`;
      } catch (err) {
        expect(err.response.status).to.equal(400);
        expect(err.response.data.error.message).to.equal('Plant is mandatory.');
      }
    });
  });
});
