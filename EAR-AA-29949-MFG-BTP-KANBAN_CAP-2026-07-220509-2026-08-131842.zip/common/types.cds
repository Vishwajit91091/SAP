type Plant         : String(4);
type PlantName     : String(45);
type Material      : String(18);
type MaterialDesc  : String(40);
type PartGroup     : String(40);
type SerialNo      : String(18);
type MatDoc        : String(10);
type Search        : String;
type Min           : Decimal(13, 3);
type Max           : Decimal(13, 3);
type QOH           : Decimal(13, 3);
type WIP           : Decimal(13, 3);
type Trigger       : Decimal(13, 3);
type Buffer        : Decimal(13, 3);
type InTransit     : Decimal(13, 3);
type SafetyStock   : Decimal(13, 3);
type OrderQty      : Decimal(13, 3);
type GradeValue    : Decimal(13, 3);
type YYYYMM        : String(7) @assert.format: '^\\d{4}-(0[1-9]|1[0-2])$';

type Grade         : String(1) enum {
  F;
  D;
  C;
  B;
  A;
};

type StockCategory : String enum {
  stockOut;
  underStock;
  triggerPoint;
  optimalStock;
  overStock;
}
