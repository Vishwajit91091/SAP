/* checksum : d3789a744e93e3136cb361984e3aebce */
@cds.external : true
@m.IsDefaultEntityContainer : 'true'
@sap.supported.formats : 'atom json xlsx'
service chx_ecc {
  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity MaterialMovementSet {
    @sap.unicode : 'false'
    @sap.label : 'Material Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Material : String(18) not null;
    @sap.unicode : 'false'
    @sap.label : 'Plant'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Plant : String(4) not null;
    @sap.unicode : 'false'
    @sap.label : 'Material Document'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    MatDoc : String(10) not null;
    @sap.unicode : 'false'
    @sap.label : 'Quantity'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Quantity : Decimal(13, 3) not null;
    @sap.unicode : 'false'
    @sap.label : 'BaseUnit'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    BaseUnit : String(3) not null;
    @sap.unicode : 'false'
    @sap.label : 'From Storage Location'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    FromSloc : String(4) not null;
    @sap.unicode : 'false'
    @sap.label : 'To Storage Location'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    ToSloc : String(4) not null;
    @sap.unicode : 'false'
    @sap.label : 'Movement Type Indicator'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Indicator : String(1) not null;
    to_MessageNav : Association to many MessagesSet {  };
    To_SerialNav : Association to many SerialNumDetailsSet {  };
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity SerialNumDetailsSet {
    @sap.unicode : 'false'
    @sap.label : 'SerialNumber'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key SerialNumber : String(18) not null;
    @sap.unicode : 'false'
    @sap.label : 'Material'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key Material : String(18) not null;
    @sap.unicode : 'false'
    @sap.label : 'Batch Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Batch : String(10) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.pageable : 'false'
  @sap.addressable : 'false'
  @sap.content.version : '1'
  entity MessagesSet {
    @sap.unicode : 'false'
    @sap.label : 'Message Number'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    key MessageNo : String(3) not null;
    @sap.unicode : 'false'
    @sap.label : 'Message Type'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    MessageTyp : String(1) not null;
    @sap.unicode : 'false'
    @sap.label : 'Message Class'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    MessageId : String(20) not null;
    @sap.unicode : 'false'
    @sap.label : 'Message text'
    @sap.creatable : 'false'
    @sap.updatable : 'false'
    @sap.sortable : 'false'
    @sap.filterable : 'false'
    Message : String(220) not null;
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Health Index Calculation View'
  entity ZMFG_CDS_CHX_HLT_INDX {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key Plant : String(4) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.display.format : 'Date'
    @sap.label : 'Posting Date'
    key PostingDate : Date not null;
    @sap.label : 'Safety Stock'
    SafetyStock : Decimal(13, 3);
    @sap.label : 'Buffer and Safety Stoc'
    BufferSafetyStock : Decimal(13, 3);
    @sap.label : 'Out of Stock'
    OutOfStock : Decimal(13, 3);
    @sap.label : 'Over Stock'
    OverStock : Decimal(13, 3);
    @sap.label : 'Total Score Calculat'
    TotalScore : Decimal(13, 3);
    @sap.display.format : 'UpperCase'
    LetterGrade : String(1);
    @sap.label : 'Consumption Data'
    ConsumptionData : Decimal(13, 3);
    @sap.label : 'Material Description'
    MaterialDescription : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group'
    PartGroup : String(40);
    @sap.label : 'Current QOH'
    CurrentQOH : Decimal(13, 3);
    @sap.label : 'Min Stock level'
    ZminStock : Decimal(13, 3);
    @sap.label : 'Maximum stock level'
    MaximumStockLevel : Decimal(13, 3);
    @sap.label : 'Buffer Stock'
    BufferStock : Decimal(13, 3);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Plant Details'
  entity ZMFG_CDS_CHX_PlantDetails {
    @sap.display.format : 'NonNegative'
    @sap.label : 'Number'
    key SEQUENCE : String(4) not null;
    @sap.label : 'Selection value'
    SupplyingPlant : String(45);
    @sap.label : 'Name 1'
    SupplyingPlantName : String(30);
    @sap.label : 'Selection value'
    ReceivingPlant : String(45);
    @sap.label : 'Name 1'
    ReceivingPlantName : String(30);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Material Serial Number Details'
  entity ZMFG_CDS_CHX_SerialNumDetails {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Serial Number'
    key SerialNumber : String(18) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    Plant : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Storage Location'
    StorageLocation : String(4);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Stock batch'
    Batch : String(10);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Material Data'
  entity ZMFG_CDS_CHX_MaterialData {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key Plant : String(4) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.label : 'Material Description'
    MaterialDescription : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group'
    PartGroup : String(40);
    @sap.label : 'Min Stock level'
    ZminStock : Decimal(13, 3);
    @sap.label : 'Buffer Stock'
    BufferStock : Decimal(13, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Include On Board'
    IncludeOnBoard : String(1);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Material Stock Details'
  entity ZMFG_CDS_CHX_MaterialStock {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key Plant : String(4) not null;
    @sap.label : 'Material Description'
    MaterialDescription : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group'
    PartGroup : String(40);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Min Stock level'
    MinimumStock : Decimal(13, 3);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Buffer Stock'
    BufferStock : Decimal(13, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Include On Board'
    IncludeOnBoard : String(1);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Maximum stock level'
    MaximumStockLevel : Decimal(13, 3);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Reorder Point'
    ReOrderPoint : Decimal(13, 3);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Stock in Transit'
    InTransit : Decimal(13, 3);
    @sap.unit : 'BaseUnit'
    @sap.label : 'Safety Stock'
    SafetyStock : Decimal(13, 3);
    @sap.label : 'Selection value'
    MainStrgLoc : String(45);
    @sap.unit : 'BaseUnit'
    CurrentQOH : Decimal(13, 3);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Batch'
    ValuationType : String(10);
    @sap.label : 'Selection value'
    StagingStrgLoc : String(45);
    @sap.unit : 'BaseUnit'
    StagingQOH : Decimal(13, 3);
    WIP : Decimal(13, 3);
    WIPCurrentQOH : Decimal(13, 3);
    Orderqty : Decimal(13, 3);
    @sap.label : 'Base Unit of Measure'
    @sap.semantics : 'unit-of-measure'
    BaseUnit : String(3);
    @sap.display.format : 'UpperCase'
    SerialNoProfile : String(1);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Material Document quantity for Consumption data'
  entity ZMFG_CDS_CHX_MatlDocQty {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key Plant : String(4) not null;
    @sap.display.format : 'Date'
    @sap.label : 'Posting Date'
    postingDate : Date;
    MengeP : Decimal(13, 3);
    MengeN : Decimal(13, 3);
  };

  @cds.external : true
  @cds.persistence.skip : true
  @sap.creatable : 'false'
  @sap.updatable : 'false'
  @sap.deletable : 'false'
  @sap.content.version : '1'
  @sap.label : 'Kanban Material Inventory Overview'
  entity ZMFG_CDS_CHX_MAT_INV_OVW {
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material'
    key Material : String(18) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key SupplyingPlant : String(4) not null;
    @sap.display.format : 'UpperCase'
    @sap.label : 'Plant'
    key receivingPlant : String(4) not null;
    @sap.label : 'Material Description'
    MaterialDescription : String(40);
    @sap.display.format : 'UpperCase'
    @sap.label : 'Material Group'
    PartGroup : String(40);
    @sap.label : 'Min Stock level'
    SupplyingMinStock : Decimal(13, 3);
    @sap.label : 'Maximum stock level'
    SupplyingMaxStock : Decimal(13, 3);
    SupplyingQOH : Decimal(13, 3);
    @sap.label : 'Min Stock level'
    ReceivingMinStock : Decimal(13, 3);
    @sap.label : 'Maximum stock level'
    ReceivingMaxStock : Decimal(13, 3);
    ReceivingQOH : Decimal(13, 3);
    ReceivingOrderqty : Decimal(13, 3);
    @sap.label : 'Stock in Transit'
    ReceivingInTransit : Decimal(13, 3);
    SuppRecMin : Decimal(14, 3);
    SuppRecMax : Decimal(14, 3);
    SuppRecQOH : Decimal(14, 3);
    SupplyingWIP : Decimal(13, 3);
    SupplyingWIPCurrentQOH : Decimal(13, 3);
    ProductionDemand : Decimal(16, 3);
  };
};

