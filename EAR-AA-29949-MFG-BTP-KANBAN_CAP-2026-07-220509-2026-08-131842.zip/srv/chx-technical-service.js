const ChampionXBaseService = require('./handlers/championx');
const chxEcc = require('./handlers/ecc');

module.exports = class ChxTechnicalService extends ChampionXBaseService {
  async init() {
    const myEcc = await chxEcc('chx_ecc_tech');

    this.on('CREATE', this.entities.HealthIndex, async (req) => {
      return myEcc.batchCreate(
        myEcc.connection.entities.ZMFG_CDS_CHX_HLT_INDX,
        req.data.map((material) => ({
          PostingDate: `/Date(${new Date(material.date).getTime()})/`,
          Plant: material.plant,
          Material: material.material,
          MaterialDescription: material.description,
          PartGroup: material.partGroup,
          CurrentQOH: material.qoh.toFixed(3),
          ZminStock: material.min.toFixed(3),
          MaximumStockLevel: material.max.toFixed(3),
          BufferStock: material.buffer.toFixed(3),
          SafetyStock: material.safetyStock.toFixed(3),
          BufferSafetyStock: material.bufferSafetyStock.toFixed(3),
          OutOfStock: material.outOfStock.toFixed(3),
          OverStock: material.overStock.toFixed(3),
          TotalScore: material.totalScore,
          LetterGrade: material.letterGrade,
          ConsumptionData: material.consumptionData.toFixed(3),
        })),
        req
      );
    });

    return super.init(myEcc);
  }
};
