using {chx_ecc as my} from './external/chx-ecc';
using {
                Plant,
                SerialNo,
                MatDoc,
    Material as MaterialType,
} from '../common/types';

service ChampionXService {
    @readonly
    entity PlantData        as
        projection on my.ZMFG_CDS_CHX_PlantDetails {
            key SupplyingPlant     as supplyingPlant,
                SupplyingPlantName as supplyingPlantName,
                ReceivingPlant     as receivingPlant,
                ReceivingPlantName as receivingPlantName
        };

    @readonly
    entity MaterialData     as
        projection on my.ZMFG_CDS_CHX_MaterialStock {
            key Plant               as plant,
            key Material            as material,
                MaterialDescription as description,
                PartGroup           as partGroup,
                MinimumStock        as min,
                BufferStock         as buffer,
                IncludeOnBoard      as board,
                BaseUnit            as baseUnit,
                MaximumStockLevel   as max,
                ReOrderPoint        as trigger,
                CurrentQOH          as qoh,
                StagingQOH          as stagingQoh,
                InTransit           as inTransit,
                SafetyStock         as safetyStock,
                WIP                 as wip,
                WIPCurrentQOH       as wipQoh,
                Orderqty            as orderQty,
                SerialNoProfile     as isSerialized,
                ValuationType       as batch,
                MainStrgLoc         as mainSloc,
                StagingStrgLoc      as stagingSloc
        };

    @readonly
    entity SerialNumberData as
        projection on my.ZMFG_CDS_CHX_SerialNumDetails {
            key Material        as material,
            key SerialNumber    as serialNumber,
                Plant           as plant,
                StorageLocation as storageLocation,
                Batch           as batch,
        };

    @readonly
    entity Material         as
        projection on my.ZMFG_CDS_CHX_MaterialData {
            key Plant               as plant,
            key Material            as material,
                MaterialDescription as description,
                PartGroup           as partGroup,
                IncludeOnBoard      as board
        };

    @readonly
    entity HealthIndex      as
        projection on my.ZMFG_CDS_CHX_HLT_INDX {
            key PostingDate         as date,
            key Plant               as plant,
            key Material            as material,
                MaterialDescription as description,
                PartGroup           as partGroup,
                CurrentQOH          as qoh,
                ZminStock           as min,
                MaximumStockLevel   as max,
                BufferStock         as buffer,
                SafetyStock         as safetyStock,
                BufferSafetyStock   as bufferSafetyStock,
                OutOfStock          as outOfStock,
                OverStock           as overStock,
                TotalScore          as totalScore,
                LetterGrade         as letterGrade,
                ConsumptionData     as consumptionData,
        };

    /**
     * This action is used to perform material movement based on the direction (PLUS or MINUS) provided.
     * It takes the plant, material, quantity and an array of serial numbers as input parameters and returns a material document number (MatDoc) as output.
     */
    action materialMovement(direction: String enum {
        MINUS;
        PLUS;
    },
                            plant: Plant,
                            material: MaterialType,
                            quantity: Integer,
                            serialNumbers: array of SerialNo) returns {
        MatDoc : MatDoc;
    };
}
