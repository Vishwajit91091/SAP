using {
  Plant,
  PlantName,
  Material,
  MaterialDesc,
  PartGroup,
  Search,
  Min,
  Max,
  QOH,
  WIP,
  Trigger,
  Buffer,
  InTransit,
  OrderQty
} from '../common/types';

service DashboardService {
  /**
   * Returns list of plants which are either supplying or receiving materials.
   * This is required to populate the plant dropdown in the UI.
   */
  function getPlants()                                 returns array of PlantItem;

  /**
   * Returns list of plants which are either supplying or receiving materials for a given plant.
   * This is required to populate the related plants dropdown in the reports.
   */
  function getRelatedPlants(plant: Plant)              returns array of PlantItem;

  /**
   * Returns list of part groups for a given plant.
   * This is required to populate the part group dropdown in the UI.
   */
  function getPartGroups(plant: Plant, search: Search) returns array of PartGroupItem;

  /**
   * Returns the Kanban dashboard data for a given plant, part group, and search term.
   */
  function kanbanDashboard(plant: Plant,
                           partGroup: PartGroup,
                           search: Search)             returns Kanban;

  type PlantItem {
    plant       : Plant;
    plantName   : PlantName;
    isSupplying : Boolean;
    isReceiving : Boolean;
  }

  type PartGroupItem {
    partGroup : PartGroup;
  }

  type KanbanItem {
    partGroup   : PartGroup;
    material    : Material;
    description : MaterialDesc;
    qoh         : QOH;
    stagingQoh  : QOH;
    min         : Min;
    max         : Max;
    trigger     : Trigger;
    wip         : WIP;
    buffer      : Buffer;
    inTransit   : InTransit;
    orderQty    : OrderQty;
  }

  type Kanban {
    stockOut     : array of KanbanItem;
    underStock   : array of KanbanItem;
    triggerPoint : array of KanbanItem;
    optimalStock : array of KanbanItem;
    overStock    : array of KanbanItem;
  }
}
