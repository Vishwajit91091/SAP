using {
    Plant,
    Material,
    MaterialDesc,
    PartGroup,
    Grade,
    GradeValue,
    Max,
    SafetyStock,
    Buffer,
    QOH,
    YYYYMM
} from '../common/types';

service ChartService {
    action   uploadHealthData();

    /**
     * This function returns the health index data for the material type grouped by month
     */
    function healthIndex(plant: Plant,
                         startDate: Date,
                         endDate: Date)       returns HealthIndex;

    /**
     * This function returns the sum of 'out of stock', 'over stock' grouped by month
     */
    function sumOfEvents(plant: Plant,
                         event: String enum {
        outOfStock;
        overStock;
    },
                         startDate: Date,
                         endDate: Date)       returns SumOfEvents;

    /**
     * This function returns the control chart data for the material type grouped by month
     */
    function groupControlChart(plant: Plant,
                               partGroup: PartGroup,
                               startDate: Date,
                               endDate: Date) returns GroupControlChart;

    /**
     * This function returns the control chart data for the material for each day
     */
    function controlChart(plant: Plant,
                          material: Material,
                          startDate: Date,
                          endDate: Date)      returns ControlChart;

    /**
     * This function returns the Material group summary by month
     */
    function groupSummary(plant: Plant,
                          partGroup: PartGroup,
                          startDate: Date,
                          endDate: Date)      returns GroupSummary;

    type HealthIndex       : array of {
        partGroup        : PartGroup;
        healthIndexItems : array of HealthIndexItem;
    }

    type HealthIndexItem   : {
        month      : YYYYMM;
        grade      : Grade;
        totalScore : GradeValue;
    }

    type SumOfEvents       : array of {
        partGroup        : PartGroup;
        sumOfEventsItems : array of SumOfEventsItem;
    }

    type SumOfEventsItem   : {
        month : YYYYMM;
        count : Integer;
    }

    type GroupControlChart : array of {
        month         : YYYYMM;
        avgTotalScore : GradeValue;
        A             : GradeValue;
        B             : GradeValue;
        C             : GradeValue;
        D             : GradeValue;
        F             : GradeValue;
    }

    type ControlChart      : array of {
        date        : Date;
        max         : Max;
        safetyStock : SafetyStock;
        buffer      : Buffer;
        qoh         : QOH;
    }

    type GroupSummary      : array of {
        material       : Material;
        description    : MaterialDesc;
        avgTotalScores : array of {
            month         : YYYYMM;
            avgTotalScore : GradeValue
        }
    }
}
