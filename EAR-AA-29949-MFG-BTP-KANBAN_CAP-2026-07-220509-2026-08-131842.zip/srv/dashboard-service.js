const cds = require('@sap/cds');
const {
  transformPlantData,
  groupMaterialForKanban,
  getPartGroups,
} = require('./handlers/kanban');
const { validateMandatoryRequestParams } = require('./handlers/error');

module.exports = class DashboardService extends cds.ApplicationService {
  async init() {
    const chx = await cds.connect.to('ChampionXService');

    this.on('getPlants', async () => {
      const plants = await chx.read(chx.entities.PlantData);
      return transformPlantData(plants);
    });

    this.on('getRelatedPlants', async (req) => {
      const { plant } = validateMandatoryRequestParams(req, ['plant']);

      const relatedPlantsData = await chx
        .read(chx.entities.PlantData)
        .where({ supplyingPlant: plant })
        .or({ receivingPlant: plant });

      if (!relatedPlantsData.length) {
        req.reject(404, 'PLANT_NOT_FOUND');
      }

      const relatedPlants = transformPlantData(relatedPlantsData);
      return relatedPlants.filter((p) => p.plant !== plant);
    });

    this.on('getPartGroups', async (req) => {
      const { plant, search } = validateMandatoryRequestParams(req, ['plant']);
      return await getPartGroups(chx, plant, search);
    });

    this.on('kanbanDashboard', async (req) => {
      const { plant, partGroup, search } = validateMandatoryRequestParams(req, [
        'plant',
      ]);

      const query = chx.read(chx.entities.MaterialData).where({
        board: 'Y',
        plant,
        ...(partGroup && { partGroup }),
      });

      if (search) {
        if (search != encodeURIComponent(search)) {
          query.and`contains(description, ${search})`;
        } else {
          query.where`contains(material, ${search})
            or contains(description, ${search})`;
        }
      }

      const materials = await query;

      return groupMaterialForKanban(materials);
    });

    return super.init();
  }
};
