const cds = require('@sap/cds');

module.exports = class ChampionXBaseService extends cds.ApplicationService {
  async init(ecc) {
    if (!ecc) {
      throw new Error('No destination provided');
    }
    this.ecc = ecc;

    this.on('READ', '*', async (req) => {
      return ecc.read(req.query, req);
    });

    this.after('READ', this.entities.MaterialData, async (data) => {
      return this.transformMaterialData(data);
    });

    this.after('READ', this.entities.HealthIndex, async (data) => {
      return this.transformHealthIndexData(data);
    });

    return super.init();
  }

  /**
   * Adds association data for each of the list of materials.
   * @param {Object} entity - The entity to fetch association data from.
   * @param {{plant: string, material: string}[]} materials
   * @returns {Object[]} The list of materials with association information added.
   */
  async addAssociationToMaterials(entity, materials) {
    if (!entity)
      throw new Error('Entity is required to associate with materials');
    if (!materials)
      throw new Error('Materials data is required to add association data');

    const entityName = entity.name.split('.').pop();

    const plantGroups = {};
    for (const material of materials) {
      if (!plantGroups[material.plant]) {
        plantGroups[material.plant] = {};
      }
      plantGroups[material.plant][material.material] = material;
    }

    const materialsWithAssociationData = await Promise.all(
      Object.entries(plantGroups).map(async ([plant, materialsInPlant]) => {
        const queryResults = await this.read(entity).where({
          plant,
          material: Object.keys(materialsInPlant),
        });

        queryResults.forEach((result) => {
          materialsInPlant[result.material][entityName] = result;
        });

        return Object.values(materialsInPlant);
      })
    );

    return materialsWithAssociationData.flat();
  }

  /**
   * Transforms material data to make it more user-friendly.
   * @param {Object[]} materials - The list of materials to transform.
   * @returns {Object[]} The transformed material data.
   */
  transformMaterialData(materials) {
    const numericData = [
      'min',
      'buffer',
      'max',
      'trigger',
      'qoh',
      'stagingQoh',
      'inTransit',
      'safetyStock',
      'wip',
      'wipQoh',
    ];

    return materials.map((material) => {
      numericData.forEach((key) => {
        if (material[key] != null) {
          material[key] = Number(material[key]);
        }
      });
      if (Object.hasOwn(material, 'isSerialized')) {
        material.isSerialized = material.isSerialized === 'X';
      }

      return material;
    });
  }

  /**
   * Transforms health index data to make it more user-friendly.
   * @param {Object[]} healthIndexData - The list of health index data to transform.
   * @returns {Object[]} The transformed health index data.
   */
  transformHealthIndexData(healthIndexData) {
    const numericData = [
      'qoh',
      'min',
      'max',
      'buffer',
      'safetyStock',
      'bufferSafetyStock',
      'outOfStock',
      'overStock',
      'totalScore',
      'consumptionData',
    ];

    return healthIndexData.map((item) => {
      numericData.forEach((key) => {
        if (item[key] != null) {
          item[key] = Number(item[key]);
        }
      });
      return item;
    });
  }

  /**
   * Get all material data
   * @param {object} conditions
   * @returns {object[]}
   */
  async getAllMaterials(conditions = {}) {
    const PAGE_SIZE = 1000;
    let skip = 0;
    let allData = [];

    while (true) {
      const batch = await this.read(this.entities.MaterialData)
        .where(conditions)
        .limit(PAGE_SIZE, skip);

      allData.push(...batch);

      if (batch.length < PAGE_SIZE) {
        break;
      }

      skip += PAGE_SIZE;
    }

    return allData;
  }
};
