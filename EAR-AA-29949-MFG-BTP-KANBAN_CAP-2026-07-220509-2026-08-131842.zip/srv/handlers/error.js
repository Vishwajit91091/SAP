/**
 * Validates that all required parameters are present in a CDS request.
 *
 * If a required parameter is missing, the request is rejected with a
 * 400 status code and an error code in the format
 * `MANDATORY_PARAMETER_{PARAM_NAME}`.
 *
 * @param {import('@sap/cds').Request} req - The CDS request object.
 * @param {string[]} requiredParams - List of required parameter names.
 * @returns {Object} The request data (`req.data`) when validation succeeds.
 * @throws {Error} If the request object is invalid.
 * @throws {Error} If `requiredParams` is not an array.
 */
function validateMandatoryRequestParams(req, requiredParams) {
  if (!req || !req.data || !req.reject)
    throw new Error('Request object is required');
  if (!requiredParams || !Array.isArray(requiredParams))
    throw new Error('requiredParams must be an array');

  for (const param of requiredParams) {
    if (!req.data[param]) {
      req.reject(400, `MANDATORY_PARAMETER_${param.toUpperCase()}`);
    }
  }
  return req.data;
}

function validateStartAndEndDatesFromReq(
  req,
  startDateKey = 'startDate',
  endDateKey = 'endDate'
) {
  const { startDate, endDate } = validateMandatoryRequestParams(req, [
    startDateKey,
    endDateKey,
  ]);
  const start = new Date(startDate);
  const end = new Date(endDate);

  if (isNaN(start) || isNaN(end)) {
    req.reject(400, 'INVALID_DATE');
  }

  if (end < start) {
    req.reject(400, 'END_DATE_BEFORE_START_DATE');
  }

  if (end - start > 365 * 24 * 60 * 60 * 1000) {
    req.reject(400, 'INVALID_DATE_RANGE_LT_365_DAYS');
  }
}

module.exports = {
  validateMandatoryRequestParams,
  validateStartAndEndDatesFromReq,
};
