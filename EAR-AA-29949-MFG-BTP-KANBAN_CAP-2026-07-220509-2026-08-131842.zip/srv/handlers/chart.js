// Maintain this in sorted order
// to avoid sorting it manually inside grading logic
const GRADE_THRESHOLDS = Object.freeze({
  A: 90,
  B: 80,
  C: 70,
  D: 60,
  F: 0,
});

/**
 * Formats a date into a year-month string.
 * @param {Date|string|number} date - The date value to format.
 * @returns {string} The date in YYYY-MM format.
 */
const getYYYYMM = (date) =>
  date instanceof Date
    ? date.toISOString().slice(0, 7)
    : String(date).slice(0, 7);

/**
 * Calculates the health score for a material based on its stock level.
 * @param {number} qoh - The current on-hand quantity.
 * @param {number} max - The maximum stock threshold.
 * @param {number} buffer - The buffer stock value.
 * @param {number} safetyStock - The safety stock threshold.
 * @returns {number} The calculated total score.
 */
function calculateTotalScore(qoh, max, buffer, safetyStock) {
  const bufferSS = safetyStock + buffer;
  const midpoint = bufferSS + (max - bufferSS) / 2;

  // Out of stock
  if (qoh <= 0) {
    return 0;
  }

  // 0 -> Safety Stock : 60 -> 70
  if (qoh <= safetyStock) {
    return 60 + (10 * qoh) / safetyStock;
  }

  // Safety Stock -> Buffer+SS : 80 -> 90
  if (qoh <= bufferSS) {
    return 80 + (10 * (qoh - safetyStock)) / (bufferSS - safetyStock);
  }

  // Buffer+SS -> Midpoint : 90 -> 100
  if (qoh < midpoint) {
    return 90 + (10 * (qoh - bufferSS)) / (midpoint - bufferSS);
  }

  // Midpoint -> Max : 100 -> 90
  if (qoh <= max) {
    return 100 - (10 * (qoh - midpoint)) / (max - midpoint);
  }

  // Max -> 120% Max : 80 -> 70
  if (qoh <= 1.2 * max) {
    return 80 - (10 * (qoh - max)) / (0.2 * max);
  }

  // 120% Max -> 150% Max : 70 -> 60
  if (qoh <= 1.5 * max) {
    return 70 - (10 * (qoh - 1.2 * max)) / (0.3 * max);
  }

  // > 150% Max
  return 0;
}

/**
 * Maps a numeric score to its corresponding grade.
 * @param {number} totalScore - The score to evaluate.
 * @returns {string} The grade for the given score.
 */
function getGrade(totalScore) {
  const grades = Object.keys(GRADE_THRESHOLDS);
  for (const grade of grades) {
    if (totalScore >= GRADE_THRESHOLDS[grade]) {
      return grade;
    }
  }
  return 'F';
}

/**
 * Creates the upper bound values for each grade bucket.
 * @returns {Object<string, number>} An object mapping grade names to their plot cutoff values.
 */
function getGradePlots() {
  const plots = {};
  const grades = Object.keys(GRADE_THRESHOLDS);
  grades.forEach((grade, index) => {
    if (index === 0) {
      plots[grade] = 100;
      return;
    }

    plots[grade] = GRADE_THRESHOLDS[grades[index - 1]] - 0.001;
  });
  return plots;
}

/**
 * Builds a month-indexed object between the supplied start and end dates.
 * @param {Date|string} startDate - The start date for the month range.
 * @param {Date|string} endDate - The end date for the month range.
 * @param {Object} [initFields={}] - Default fields to include for each month.
 * @returns {Object<string, Object>} An object keyed by month containing the initialized data.
 */
function buildMonths(startDate, endDate, initFields = {}) {
  const months = {};

  const current = new Date(startDate);
  current.setDate(1);

  const end = new Date(endDate);
  end.setDate(1);

  while (current <= end) {
    const month = current.toISOString().slice(0, 7);

    months[month] = { month, ...initFields };

    current.setMonth(current.getMonth() + 1);
  }

  return months;
}

/**
 * Aggregates health scores by month and optionally attaches grades.
 * @param {Object[]} healthData - The input score rows.
 * @param {Date|string} startDate - The start date for aggregation.
 * @param {Date|string} endDate - The end date for aggregation.
 * @param {boolean} [fetchGrade=false] - Whether to include the grade for each month.
 * @returns {Object[]} The monthly average scores.
 */
function getMonthlyScore(healthData, startDate, endDate, fetchGrade = false) {
  const monthsAcc = buildMonths(startDate, endDate, {
    count: 0,
    totalScore: 0,
  });

  const monthlyScores = Object.values(
    healthData.reduce((acc, row) => {
      const month = getYYYYMM(row.date);

      if (!acc[month]) {
        acc[month] = {
          month,
          totalScore: 0,
          count: 0,
        };
      }

      acc[month].totalScore += row.totalScore;
      acc[month].count++;

      return acc;
    }, monthsAcc)
  ).map((month) => {
    const avgTotalScore = Number((month.totalScore / month.count).toFixed(3));
    return {
      month: month.month,
      avgTotalScore,
      ...(fetchGrade && { grade: getGrade(avgTotalScore) }),
    };
  });

  return monthlyScores;
}

/**
 * Aggregates health scores by day and optionally attaches grades.
 * @param {Object[]} healthData - The input score rows.
 * @param {Date|string} startDate - The start date for aggregation.
 * @param {Date|string} endDate - The end date for aggregation.
 * @param {boolean} [fetchGrade=false] - Whether to include the grade for each day.
 * @returns {Object[]} The daily average scores.
 */
function getDailyAvgScore(healthData, startDate, endDate, fetchGrade = false) {
  const dailyAcc = {};

  const dailyAvgScore = Object.values(
    healthData.reduce((acc, row) => {
      const date = row.date;

      if (!acc[date]) {
        acc[date] = {
          date,
          totalScore: 0,
          count: 0,
        };
      }

      acc[date].totalScore += row.totalScore;
      acc[date].count++;

      return acc;
    }, dailyAcc)
  ).map((data) => {
    const avgTotalScore = Number((data.totalScore / data.count).toFixed(3));
    return {
      date: data.date,
      avgTotalScore,
      ...(fetchGrade && { grade: getGrade(avgTotalScore) }),
    };
  });

  return dailyAvgScore;
}

/**
 * Aggregates event totals by month.
 * @param {Object[]} healthData - The input event rows.
 * @param {string} event - The event to aggregate.
 * @param {Date|string} startDate - The start date for aggregation.
 * @param {Date|string} endDate - The end date for aggregation.
 * @returns {Object[]} The monthly stock event totals.
 */
function getMonthlySumOfEvents(healthData, event, startDate, endDate) {
  const monthsAcc = buildMonths(startDate, endDate, {
    count: 0,
  });

  return Object.values(
    healthData.reduce((acc, row) => {
      const month = getYYYYMM(row.date);

      if (!acc[month]) {
        acc[month] = {
          month,
          count: 0,
        };
      }

      acc[month].count += row[event];

      return acc;
    }, monthsAcc)
  );
}

module.exports = {
  calculateTotalScore,
  getGrade,
  getGradePlots,
  getMonthlyScore,
  getDailyAvgScore,
  getMonthlySumOfEvents,
};
