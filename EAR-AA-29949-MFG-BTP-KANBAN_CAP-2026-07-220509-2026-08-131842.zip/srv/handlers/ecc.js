const cds = require('@sap/cds');

/**
 * Class representing the connection to the ChampionX ECC system.
 * This class encapsulates the logic for connecting to the ECC system and executing queries.
 */
class ChxEcc {
  constructor(destination) {
    if (!destination) {
      throw new Error('Destination is required to connect to ChampionX ECC');
    }
    this.destination = destination;
  }

  /**
   * Establishes a connection to the ChampionX destination.
   * @returns {Object} The connection object.
   */
  async connect() {
    if (this.connection) {
      return this.connection;
    }
    this.connection = await cds.connect.to(this.destination);
    return this.connection;
  }

  /**
   * Executes a read query against the ChampionX ECC system.
   * @param {Object} query - The query to execute.
   * @param {Object} req - The request object.
   * @returns {Object} The result of the query.
   */
  async read(query, req) {
    return this._eccErrorWrapper(async () => {
      if (!this.connection) {
        this.connect();
      }
      return await this.connection.read(query);
    }, req);
  }

  /**
   * Executes a create query against the ChampionX ECC system.
   * @param {Object[]} args - The arguments to pass to the create method.
   * @param {Object} req - The request object.
   * @returns {Object} The result of the query.
   */
  async create(args, req) {
    return this._eccErrorWrapper(async () => {
      if (!this.connection) {
        this.connect();
      }
      return await this.connection.create(...args);
    }, req);
  }

  /**
   * Executes a batch create query against the ChampionX ECC system.
   * @param {Object} entity - The entity to create.
   * @param {Object[]} data - The data to create.
   * @param {Object} req - The request object.
   * @param {Object} config - The configuration options.
   * @returns {Promise<void>}
   */
  async batchCreate(entity, data, req, config = { batchSize: 1000 }) {
    const entityName = entity.name.split('.').pop();
    return this._eccErrorWrapper(async () => {
      if (!this.connection) {
        this.connect();
      }
      await this.createInBatches(entityName, data, config.batchSize);
    }, req);
  }

  /**
   * Create records in batches to avoid large payload limits.
   * @param {object} client
   * @param {object} entity
   * @param {object[]} data
   * @param {number} batchSize
   * @returns {Promise<void>}
   */
  async createInBatches(entityName, data, batchSize = 1000) {
    for (let index = 0; index < data.length; index += batchSize) {
      const batch = data.slice(index, index + batchSize);

      const { body, contentType } = this.generateBatchBody(
        entityName,
        batch,
        'POST'
      );

      const response = await this.connection.send({
        method: 'POST',
        path: `/$batch`,
        headers: { 'Content-Type': contentType },
        data: body,
      });
      // eslint-disable-next-line no-console
      console.log(
        `Batch ${index / batchSize + 1} for ${entityName}:`,
        JSON.stringify(response)
      );
    }
  }

  /**
   * Generates the body for a batch request.
   * @param {string} entityName - The name of the entity to create.
   * @param {object[]} data - The data to create.
   * @returns {object} The batch request body.
   */
  generateBatchBody(entityName, data, method = 'GET') {
    const batchBoundary = `batch_${Date.now()}`;
    const changeSetBoundary = `changeset_${Date.now()}`;

    const CRLF = '\r\n';

    const body =
      `--${batchBoundary}${CRLF}` +
      `Content-Type: multipart/mixed; boundary=${changeSetBoundary}${CRLF}${CRLF}` +
      data
        .map(
          (record) =>
            `--${changeSetBoundary}${CRLF}` +
            `Content-Type: application/http${CRLF}` +
            `Content-Transfer-Encoding: binary${CRLF}${CRLF}` +
            `${method} ${entityName} HTTP/1.1${CRLF}` +
            `Content-Type: application/json${CRLF}${CRLF}` +
            `${JSON.stringify(record)}${CRLF}`
        )
        .join('') +
      `--${changeSetBoundary}--${CRLF}` +
      `--${batchBoundary}--`;

    return {
      body,
      contentType: `multipart/mixed; boundary=${batchBoundary}`,
    };
  }

  /**
   * Wraps a function in a try-catch block and maps errors to ECC errors.
   * @param {Function} fn - The function to wrap.
   * @param {Object} req - The request object.
   * @returns {Object} The result of the wrapped function.
   */
  async _eccErrorWrapper(fn, req) {
    try {
      return await fn();
    } catch (error) {
      const eccError = this._mapError(error);
      if (req) {
        req.reject(eccError.status, eccError.code);
      }
      throw eccError;
    }
  }

  /**
   * Maps an error object to an ECC error object.
   * @param {Object} error - The error object.
   * @returns {Object} The mapped error object.
   */
  _mapError(error) {
    // eslint-disable-next-line no-console
    console.error(error);
    const status =
      error.reason?.response?.status || error.response?.status || error.status;

    switch (status) {
      case 400:
        return Object.assign(new Error('ECC_BAD_REQUEST'), {
          code: 'ECC_BAD_REQUEST',
          status,
          details: error.message,
        });

      case 401:
        return Object.assign(new Error('ECC_UNAUTHORIZED'), {
          code: 'ECC_UNAUTHORIZED',
          status,
          details: error.message,
        });

      case 403:
        return Object.assign(new Error('ECC_FORBIDDEN'), {
          code: 'ECC_FORBIDDEN',
          status,
          details: error.message,
        });

      case 404:
        return Object.assign(new Error('ECC_NOT_FOUND'), {
          code: 'ECC_NOT_FOUND',
          status,
          details: error.message,
        });

      default:
        return Object.assign(new Error('ECC_INTERNAL_ERROR'), {
          code: 'ECC_INTERNAL_ERROR',
          status,
          details: error.message,
        });
    }
  }
}

/**
 * Factory function to create and connect an instance of ChxEcc.
 * @returns {ChxEcc} An instance of ChxEcc with an established connection.
 */
module.exports = (destination) => {
  const chxEcc = new ChxEcc(destination);
  chxEcc.connect();
  return chxEcc;
};
