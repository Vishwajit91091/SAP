const cds = require('@sap/cds');

const STOCK_CATEGORY = {
  STOCK_OUT: 'stockOut',
  UNDER_STOCK: 'underStock',
  TRIGGER_POINT: 'triggerPoint',
  OPTIMAL_STOCK: 'optimalStock',
  OVER_STOCK: 'overStock',
};

/**
 * Transforms ecc plant data to plant list suitable for Kanban display drop down.
 * @param {{
 *   supplyingPlant: string,
 *   supplyingPlantName: string,
 *   receivingPlant: string,
 *   receivingPlantName: string
 * }} plantData - The list of plant data from ecc.
 * @returns {{
 *   plant: string,
 *   plantName: string,
 *   isSupplying: boolean,
 *   isReceiving: boolean
 * }[]} The transformed plant data.
 */
function transformPlantData(plantData) {
  if (!plantData) throw new Error('Plant data is required to transform');
  const result = new Map();
  plantData.forEach((plant) => {
    let existingPlant = result.get(plant.supplyingPlant);
    if (!existingPlant) {
      result.set(plant.supplyingPlant, {
        plant: plant.supplyingPlant,
        plantName: plant.supplyingPlantName,
        isSupplying: true,
        isReceiving: false,
      });
    } else {
      existingPlant.isSupplying = true;
    }

    existingPlant = result.get(plant.receivingPlant);
    if (!existingPlant) {
      result.set(plant.receivingPlant, {
        plant: plant.receivingPlant,
        plantName: plant.receivingPlantName,
        isSupplying: false,
        isReceiving: true,
      });
    } else {
      existingPlant.isReceiving = true;
    }
  });
  return Array.from(result.values());
}

/**
 * Groups materials for Kanban display based on their stock levels.
 * @param {Object[]} materials - The list of materials to group.
 * @returns {{
 *  stockOut: Object[],
 *  underStock: Object[],
 *  triggerPoint: Object[],
 *  optimalStock: Object[],
 *  overStock: Object[]
 * }} The grouped material data.
 */
function groupMaterialForKanban(materials) {
  if (!materials)
    throw new Error('Materials data is required to group for Kanban');

  const groupedData = {
    [STOCK_CATEGORY.STOCK_OUT]: [],
    [STOCK_CATEGORY.UNDER_STOCK]: [],
    [STOCK_CATEGORY.TRIGGER_POINT]: [],
    [STOCK_CATEGORY.OPTIMAL_STOCK]: [],
    [STOCK_CATEGORY.OVER_STOCK]: [],
  };

  materials.forEach((material) => {
    const category = getStockCategory(material);
    groupedData[category].push(material);
  });

  return groupedData;
}

/**
 * Determines the stock category for a material.
 * @param {{
 *   qoh: number,
 *   safetyStock: number,
 *   max: number,
 *   buffer: number
 * }} material - The material data.
 * @returns {string} The stock category.
 */
function getStockCategory(material) {
  const qoh = Number(material.qoh) || 0;
  const ss = Number(material.safetyStock) || 0;
  const max = Number(material.max) || 0;
  const buffer = Number(material.buffer) || 0;

  if (qoh === 0) {
    return STOCK_CATEGORY.STOCK_OUT;
  } else if (qoh > 0 && qoh <= ss) {
    return STOCK_CATEGORY.UNDER_STOCK;
  } else if (qoh > ss && qoh <= ss + buffer) {
    return STOCK_CATEGORY.TRIGGER_POINT;
  } else if (qoh > ss + buffer && qoh <= max) {
    return STOCK_CATEGORY.OPTIMAL_STOCK;
  } else if (qoh > max) {
    return STOCK_CATEGORY.OVER_STOCK;
  }
}

/**
 * Gets the list of part groups for the given plant.
 * @param {Object} chxClient - The ChampionXService client.
 * @param {string} plant - The plant for which to get part groups.
 * @param {string} search - The search term to filter part groups.
 * @returns {Object[]} The list of part groups.
 */
async function getPartGroups(chxClient, plant, search) {
  if (!plant) throw new Error('Plant is required to get part groups');
  const chx = chxClient || (await cds.connect.to('ChampionXService'));
  const query = chx
    .read(chx.entities.Material)
    .columns('partGroup')
    .where({ board: 'Y', plant });

  if (search) {
    query.and`contains(partGroup, ${search})`;
  }

  const rows = await query;

  return [
    ...new Map(
      rows.map((row) => [
        row.partGroup,
        {
          partGroup: row.partGroup,
        },
      ])
    ).values(),
  ];
}

module.exports = {
  STOCK_CATEGORY,
  groupMaterialForKanban,
  getStockCategory,
  transformPlantData,
  getPartGroups,
};
