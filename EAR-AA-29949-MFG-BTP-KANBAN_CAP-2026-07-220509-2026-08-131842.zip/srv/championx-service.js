const ChampionXBaseService = require('./handlers/championx');
const chxEcc = require('./handlers/ecc');
const { validateMandatoryRequestParams } = require('./handlers/error');

module.exports = class ChampionXService extends ChampionXBaseService {
  async init() {
    const myEcc = await chxEcc('chx_ecc');

    this.on('materialMovement', async (req) => {
      const { direction, plant, material, quantity, serialNumbers } =
        validateMandatoryRequestParams(req, [
          'direction',
          'plant',
          'material',
          'quantity',
        ]);

      const [materialDetails] = await this.read(
        this.entities.MaterialData
      ).where({ plant, material });

      if (!materialDetails) {
        req.reject(404, 'MATERIAL_NOT_FOUND');
      }

      if (materialDetails.isSerialized && serialNumbers?.length != quantity) {
        req.reject(400, 'SERIAL_NUMBERS_AND_QUANTITY_MISMATCH');
      }

      let fromSloc = materialDetails.mainSloc,
        toSloc = materialDetails.stagingSloc,
        indicator = '-';

      if (direction === 'PLUS') {
        fromSloc = materialDetails.stagingSloc;
        toSloc = materialDetails.mainSloc;
        indicator = '+';
      }

      const serialNumbersList = [];

      if (
        materialDetails.isSerialized &&
        serialNumbers &&
        Array.isArray(serialNumbers) &&
        serialNumbers.length > 0
      ) {
        serialNumbers.forEach((serialNumber) => {
          serialNumbersList.push({
            SerialNumber: serialNumber,
            Material: material,
            Batch: materialDetails.batch,
          });
        });
      } else {
        serialNumbersList.push({
          SerialNumber: '',
          Material: '',
          Batch: '',
        });
      }

      return myEcc.create(
        [
          myEcc.connection.entities.MaterialMovementSet,
          {
            MatDoc: '',
            Material: material,
            Plant: plant,
            Quantity: quantity.toFixed(3),
            BaseUnit: materialDetails.baseUnit,
            FromSloc: fromSloc,
            ToSloc: toSloc,
            Indicator: indicator,
            To_SerialNav: serialNumbersList,
            to_MessageNav: [
              {
                MessageTyp: '',
                MessageId: '',
                MessageNo: '',
                Message: '',
              },
            ],
          },
        ],
        req
      );
    });

    return super.init(myEcc);
  }
};
