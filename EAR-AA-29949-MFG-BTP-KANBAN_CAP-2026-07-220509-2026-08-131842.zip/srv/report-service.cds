using {chx_ecc as ecc} from './external/chx-ecc';
using {
    Plant,
    PlantName,
    Material,
    MaterialDesc,
    PartGroup,
    Search,
    Min,
    Max,
    QOH,
    WIP,
    InTransit,
    OrderQty,
    StockCategory
} from '../common/types';

service ReportService {
    @readonly
    entity ReportData              as
        projection on ecc.ZMFG_CDS_CHX_MAT_INV_OVW {
            key SupplyingPlant         as supplyingPlant,
            key receivingPlant,
            key Material               as material,
                MaterialDescription    as description,
                PartGroup              as partGroup,
                SupplyingMinStock      as supplyingPlantMin,
                SupplyingMaxStock      as supplyingPlantMax,
                SupplyingWIP           as supplyingPlantWip,
                SupplyingQOH           as supplyingPlantQoh,
                SupplyingWIPCurrentQOH as supplyingPlantQohWip,
                ReceivingInTransit     as inTransit,
                ReceivingMinStock      as receivingPlantMin,
                ReceivingMaxStock      as receivingPlantMax,
                ReceivingQOH           as receivingPlantQoh,
                ReceivingOrderqty      as receivingPlantOrderQty,
                SuppRecMin             as combinedMin,
                SuppRecMax             as combinedMax,
                SuppRecQOH             as combinedQoh,
                ProductionDemand       as productionDemand,
                virtual supplyingPlantName : PlantName,
                virtual receivingPlantName : PlantName,
        }

    @readonly
    entity DemandReport            as
        projection on ReportData {
            key supplyingPlant,
            key receivingPlant,
            key material,
                description,
                partGroup,
                supplyingPlantName,
                supplyingPlantMax,
                supplyingPlantQohWip,
                inTransit              as shippedQty,
                receivingPlantName,
                receivingPlantOrderQty as receivingPlantDemand,
                productionDemand,
        }

    @readonly
    entity OrderReport             as
        projection on ReportData {
            key supplyingPlant,
            key receivingPlant,
            key material,
                description,
                partGroup,
                supplyingPlantName,
                supplyingPlantQoh,
                receivingPlantName,
                receivingPlantOrderQty,
        }

    @readonly
    entity ComparisonReport        as
        projection on ReportData {
            key supplyingPlant,
            key receivingPlant,
            key material,
                description,
                partGroup,
                supplyingPlantName,
                supplyingPlantQoh,
                receivingPlantName,
                receivingPlantQoh,
                virtual supplyingScoreCategory : StockCategory,
                virtual receivingScoreCategory : StockCategory,
        }

    @readonly
    entity CombinedInventoryReport as
        projection on ReportData {
            key supplyingPlant,
            key receivingPlant,
            key material,
                description,
                partGroup,
                supplyingPlantName,
                supplyingPlantMin,
                supplyingPlantMax,
                supplyingPlantWip,
                supplyingPlantQoh,
                inTransit,
                receivingPlantName,
                receivingPlantMin,
                receivingPlantMax,
                receivingPlantQoh,
                combinedMin,
                combinedMax,
                combinedQoh,
                // supplyingPlantWip as combinedWip,
        }


    /**
     * Returns demand report for a given supplying plant.
     * This is required to populate the demand report in the UI.
     */
    function demandReport(plant: Plant,
                          material: Search,
                          partGroup: Search,
                          search: Search,
                          top: Integer,
                          skip: Integer)            returns DemandReportResponse;

    /**
     * Returns order report for a given receiving plant.
     * This is required to populate the order report in the UI.
     */
    function orderReport(plant: Plant,
                         material: Search,
                         partGroup: Search,
                         search: Search,
                         top: Integer,
                         skip: Integer)             returns OrderReportResponse;

    /**
     * Returns comparison report for a given list of plants.
     * This is required to populate the comparison report in the UI.
     */
    function comparisonReport(plants: Search,
                              filter: LargeString,
                              qohFilter: LargeString,
                              sort: String,
                              top: Integer,
                              skip: Integer)        returns ComparisonReportResponse;

    /**
     * Returns combined inventory report for a given plant.
     * This is required to populate the combined inventory report in the UI.
     */
    function combinedInventoryReport(supplyingPlant: Plant,
                                     receivingPlant: Plant,
                                     material: Search,
                                     partGroup: Search,
                                     search: Search,
                                     top: Integer,
                                     skip: Integer) returns CombinedInventoryReportResponse;

    type DemandReportResponse {
        receivingPlantName : String;
        demandReportItems  : array of DemandReportData;
    }

    type DemandReportData {
        material             : Material;
        description          : MaterialDesc;
        partGroup            : PartGroup;
        supplyingPlantMax    : Max;
        supplyingPlantQohWip : WIP;
        shippedQty           : InTransit;
        receivingPlantDemand : OrderQty;
        productionDemand     : OrderQty;
    }

    type OrderReportResponse {
        supplyingPlantName : String;
        orderReportItems   : array of OrderReportData;

    }

    type OrderReportData {
        material               : Material;
        description            : MaterialDesc;
        partGroup              : PartGroup;
        supplyingPlantQoh      : QOH;
        receivingPlantOrderQty : OrderQty;
    }

    type ComparisonReportResponse {
        material    : Material;
        description : MaterialDesc;
        partGroup   : PartGroup;
        plants      : array of PlantStock;
    }

    type PlantStock {
        plant    : Plant;
        qoh      : QOH;
        category : StockCategory;
    }

    type CombinedInventoryReportResponse {
        material        : Material;
        description     : MaterialDesc;
        partGroup       : PartGroup;
        supplyingPlant  : SupplyingPlantInventory;
        receivingPlant  : ReceivingPlantInventory;
        combinedSummary : CombinedSummary;
        inTransit       : InTransit;
    }

    type SupplyingPlantInventory {
        plant     : Plant;
        plantName : PlantName;
        min       : Min;
        max       : Max;
        wip       : WIP;
        qoh       : QOH;
    }

    type ReceivingPlantInventory {
        plant     : Plant;
        plantName : PlantName;
        min       : Min;
        max       : Max;
        qoh       : QOH;
    }

    type CombinedSummary {
        plantName : PlantName;
        min       : Min;
        max       : Max;
        wip       : WIP;
        qoh       : QOH;
    }

}
