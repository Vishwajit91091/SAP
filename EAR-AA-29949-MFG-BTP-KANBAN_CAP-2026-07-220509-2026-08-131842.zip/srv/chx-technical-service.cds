using {chx_ecc as my} from './external/chx-ecc';

service ChxTechnicalService {
    @readonly
    entity PlantData      as
        projection on my.ZMFG_CDS_CHX_PlantDetails {
            key SupplyingPlant     as supplyingPlant,
                SupplyingPlantName as supplyingPlantName,
                ReceivingPlant     as receivingPlant,
                ReceivingPlantName as receivingPlantName
        };

    @readonly
    entity MaterialData   as
        projection on my.ZMFG_CDS_CHX_MaterialStock {
            key Plant               as plant,
            key Material            as material,
                MaterialDescription as description,
                PartGroup           as partGroup,
                MinimumStock        as min,
                BufferStock         as buffer,
                IncludeOnBoard      as board,
                BaseUnit            as baseUnit,
                MaximumStockLevel   as max,
                ReOrderPoint        as trigger,
                CurrentQOH          as qoh,
                StagingQOH          as stagingQoh,
                InTransit           as inTransit,
                SafetyStock         as safetyStock,
                WIP                 as wip,
                WIPCurrentQOH       as wipQoh,
                Orderqty            as orderQty,
                SerialNoProfile     as isSerialized,
                MainStrgLoc         as mainSloc,
                StagingStrgLoc      as stagingSloc
        };

    entity HealthIndex    as
        projection on my.ZMFG_CDS_CHX_HLT_INDX {
            key PostingDate         as date,
            key Plant               as plant,
            key Material            as material,
                MaterialDescription as description,
                PartGroup           as partGroup,
                CurrentQOH          as qoh,
                ZminStock           as min,
                MaximumStockLevel   as max,
                BufferStock         as buffer,
                SafetyStock         as safetyStock,
                BufferSafetyStock   as bufferSafetyStock,
                OutOfStock          as outOfStock,
                OverStock           as overStock,
                TotalScore          as totalScore,
                LetterGrade         as letterGrade,
                ConsumptionData     as consumptionData,
        };

    @readonly
    entity MaterialDocQty as
        projection on my.ZMFG_CDS_CHX_MatlDocQty {
            key postingDate as date,
            key Plant       as plant,
            key Material    as material,
                MengeP      as mengeP,
                MengeN      as mengeN,
        }
}
