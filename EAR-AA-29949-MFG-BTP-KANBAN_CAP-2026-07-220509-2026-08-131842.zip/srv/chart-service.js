const cds = require('@sap/cds');
const {
  validateMandatoryRequestParams,
  validateStartAndEndDatesFromReq,
} = require('./handlers/error');
const { STOCK_CATEGORY, getStockCategory } = require('./handlers/kanban');
const {
  calculateTotalScore,
  getGrade,
  getGradePlots,
  getMonthlyScore,
  getDailyAvgScore,
  getMonthlySumOfEvents,
} = require('./handlers/chart');

module.exports = class ChartService extends cds.ApplicationService {
  async init() {
    const chx = await cds.connect.to('ChampionXService');
    const chxTech = await cds.connect.to('ChxTechnicalService');

    this.on('uploadHealthData', async () => {
      const todayDate = new Date().toISOString().slice(0, 10);
      const materials = await chxTech.getAllMaterials();
      const matDocQtyList = await chxTech
        .read(chxTech.entities.MaterialDocQty)
        .where({ date: todayDate });
      const matDocQtyMap = this.getMaterialDocQtyMap(matDocQtyList);

      const data = [];

      materials.forEach((material) => {
        const stockCategory = getStockCategory(material);
        const totalScore = calculateTotalScore(
          material.qoh,
          material.max,
          material.buffer,
          material.safetyStock
        );
        const matDocQty = matDocQtyMap.get(
          `${material.material}|${material.plant}|${todayDate}`
        );
        const consumptionData = matDocQty
          ? Number(matDocQty.mengeP) - Number(matDocQty.mengeN)
          : 0;
        const bufferSS = (material.buffer || 0) + (material.safetyStock || 0);
        data.push({
          date: todayDate,
          plant: material.plant,
          material: material.material,
          description: material.description,
          partGroup: material.partGroup,
          qoh: material.qoh || 0,
          min: material.min || 0,
          max: material.max || 0,
          buffer: material.buffer || 0,
          safetyStock: material.safetyStock || 0,
          bufferSafetyStock: bufferSS,
          outOfStock: stockCategory === STOCK_CATEGORY.STOCK_OUT ? 1 : 0,
          overStock: stockCategory === STOCK_CATEGORY.OVER_STOCK ? 1 : 0,
          totalScore: totalScore.toFixed(3),
          letterGrade: getGrade(totalScore),
          consumptionData,
        });
      });

      await chxTech.create(chxTech.entities.HealthIndex, data);
    });

    this.on('healthIndex', async (req) => {
      const { plant, startDate, endDate } = validateMandatoryRequestParams(
        req,
        ['plant', 'startDate', 'endDate']
      );

      validateStartAndEndDatesFromReq(req);

      const healthData = await this.getAllHealthData(
        chx,
        startDate,
        endDate,
        { plant },
        ['date', 'material', 'partGroup', 'description', 'totalScore']
      );

      const groupMap = this.mapByPartGroup(healthData);

      return Array.from(groupMap).map(([partGroup, rows]) => ({
        partGroup,
        healthIndexItems: getMonthlyScore(rows, startDate, endDate, true),
      }));
    });

    this.on('sumOfEvents', async (req) => {
      const { plant, event, startDate, endDate } =
        validateMandatoryRequestParams(req, [
          'plant',
          'event',
          'startDate',
          'endDate',
        ]);

      validateStartAndEndDatesFromReq(req);

      if (!['outOfStock', 'overStock'].includes(event)) {
        req.reject(400, 'INVALID_EVENT');
      }

      const healthData = await this.getAllHealthData(
        chx,
        startDate,
        endDate,
        { plant, [event]: 1 },
        ['date', 'material', 'partGroup', 'description', event]
      );

      const groupMap = this.mapByPartGroup(healthData);

      return Array.from(groupMap)
        .sort(([partGroupA], [partGroupB]) =>
          partGroupA.localeCompare(partGroupB)
        )
        .map(([partGroup, rows]) => ({
          partGroup,
          sumOfEventsItems: getMonthlySumOfEvents(
            rows,
            event,
            startDate,
            endDate
          ),
        }));
    });

    this.on('groupControlChart', async (req) => {
      const { plant, partGroup, startDate, endDate } =
        validateMandatoryRequestParams(req, [
          'plant',
          'partGroup',
          'startDate',
          'endDate',
        ]);

      validateStartAndEndDatesFromReq(req);

      const healthData = await this.getAllHealthData(
        chx,
        startDate,
        endDate,
        { partGroup, plant },
        ['date', 'material', 'description', 'totalScore']
      );

      const gradePlots = getGradePlots(healthData);
      const dailyAvgScore = getDailyAvgScore(healthData, startDate, endDate);

      return dailyAvgScore.map((data) => ({
        ...data,
        ...gradePlots,
      }));
    });

    this.on('controlChart', async (req) => {
      const { plant, material, startDate, endDate } =
        validateMandatoryRequestParams(req, [
          'plant',
          'material',
          'startDate',
          'endDate',
        ]);

      validateStartAndEndDatesFromReq(req);

      const [materialData] = await chx
        .read(chx.entities.MaterialData)
        .where({ material, plant });

      if (!materialData) {
        req.reject(404, 'MATERIAL_NOT_FOUND');
      }

      const healthData = await this.getAllHealthData(
        chx,
        startDate,
        endDate,
        { material, plant },
        ['date', 'max', 'safetyStock', 'buffer', 'qoh']
      );

      return healthData;
    });

    this.on('groupSummary', async (req) => {
      const { plant, partGroup, startDate, endDate } =
        validateMandatoryRequestParams(req, [
          'plant',
          'partGroup',
          'startDate',
          'endDate',
        ]);

      validateStartAndEndDatesFromReq(req);

      const healthData = await this.getAllHealthData(
        chx,
        startDate,
        endDate,
        { partGroup, plant },
        ['date', 'material', 'description', 'totalScore']
      );

      const materialMap = new Map();

      healthData.forEach((item) => {
        if (!materialMap.has(item.material)) {
          materialMap.set(item.material, [item]);
        } else {
          materialMap.get(item.material).push(item);
        }
      });

      return Array.from(materialMap, ([material, data]) => ({
        material,
        description: data[0].description,
        avgTotalScores: getMonthlyScore(data, startDate, endDate),
      }));
    });

    return super.init();
  }

  /**
   * Get all health data
   * @param {string} startDate
   * @param {string} endDate
   * @param {object} conditions
   * @param {string[]} columns
   * @returns {object[]}
   */
  async getAllHealthData(
    client,
    startDate,
    endDate,
    conditions = {},
    columns = ['*']
  ) {
    const PAGE_SIZE = 1000;
    let skip = 0;
    let allData = [];

    while (true) {
      const batch = await client
        .read(client.entities.HealthIndex)
        .columns(...columns)
        .where(conditions)
        .and('date', '>=', startDate)
        .and('date', '<=', endDate)
        .orderBy('date')
        .limit(PAGE_SIZE, skip);

      allData.push(...batch);

      if (batch.length < PAGE_SIZE) {
        break;
      }

      skip += PAGE_SIZE;
    }

    return allData;
  }

  /**
   * Get material doc qty map
   * @param {object[]} data
   * @returns {Map}
   */
  getMaterialDocQtyMap(data) {
    const materialMap = new Map();
    data.forEach((item) => {
      const key = `${item.material}|${item.plant}|${item.date}`;
      materialMap.set(key, item);
    });
    return materialMap;
  }

  /**
   * Map data by part group
   * @param {object[]} data
   * @returns {Map}
   */
  mapByPartGroup(data) {
    const groupMap = new Map();
    data.forEach((row) => {
      if (!groupMap.has(row.partGroup)) {
        groupMap.set(row.partGroup, [row]);
      } else {
        groupMap.get(row.partGroup).push(row);
      }
    });
    return groupMap;
  }
};
