const cds = require('@sap/cds');
const {
  STOCK_CATEGORY,
  getStockCategory,
  transformPlantData,
} = require('./handlers/kanban');
const { validateMandatoryRequestParams } = require('./handlers/error');

module.exports = class ReportService extends cds.ApplicationService {
  async init() {
    const chx = await cds.connect.to('ChampionXService');
    const chxTech = await cds.connect.to('ChxTechnicalService');

    this.on('READ', '*', async (req) => {
      return chx.ecc.read(req.query, req);
    });

    this.after('READ', this.entities.ComparisonReport, async (data) => {
      await this.transformReportData(chxTech, data);
      const materials = data.map((row) => row.material);
      const materialData = await chxTech.getAllMaterials({
        material: materials,
      });
      const materialMap = new Map();
      materialData.forEach((row) => {
        materialMap.set(`${row.plant}|${row.material}`, row);
      });
      data.forEach((row) => {
        const supplyingMaterial = materialMap.get(
          `${row.supplyingPlant}|${row.material}`
        );
        row.supplyingScoreCategory = supplyingMaterial
          ? getStockCategory(supplyingMaterial)
          : STOCK_CATEGORY.STOCK_OUT;

        const receivingMaterial = materialMap.get(
          `${row.receivingPlant}|${row.material}`
        );
        row.receivingScoreCategory = receivingMaterial
          ? getStockCategory(receivingMaterial)
          : STOCK_CATEGORY.STOCK_OUT;
      });
    });

    this.after(
      'READ',
      [
        this.entities.ReportData,
        this.entities.DemandReport,
        this.entities.OrderReport,
        this.entities.CombinedInventoryReport,
      ],
      async (data) => {
        await this.transformReportData(chxTech, data);
      }
    );

    this.on('demandReport', async (req) => {
      const { plant, material, partGroup, search, top, skip } =
        validateMandatoryRequestParams(req, ['plant']);

      const [plantData] = await chx
        .read(chx.entities.PlantData)
        .where({ supplyingPlant: plant });

      if (!plantData) {
        req.reject(400, 'PLANT_MUST_BE_SUPPLYING_PLANT');
      }

      const receivingPlant = {
        plant: plantData.receivingPlant,
        plantName: plantData.receivingPlantName,
      };

      const supplyingPlantMaterials = await this.getMaterials(chx, {
        plant,
        material,
        partGroup,
        search,
        limit: top,
        offset: skip,
      });

      const result = supplyingPlantMaterials.reduce((acc, material) => {
        acc[material.material] = {
          material: material.material,
          description: material.description,
          partGroup: material.partGroup,
          supplyingPlantMax: material.max,
          supplyingPlantQohWip: material.qoh + material.wip,
          shippedQty: 0,
          receivingPlantDemand: 0,
        };
        return acc;
      }, {});

      const receivingPlantMaterials = await this.getMaterials(chx, {
        plant: receivingPlant.plant,
        material: Object.keys(result),
      });
      receivingPlantMaterials.forEach((material) => {
        result[material.material].shippedQty = material.inTransit;
        result[material.material].receivingPlantDemand = material.orderQty;
      });

      return {
        receivingPlantName: receivingPlant.plantName,
        demandReportItems: Object.values(result).map((material) => {
          return {
            ...material,
            productionDemand:
              material.supplyingPlantMax +
              material.receivingPlantDemand -
              material.supplyingPlantQohWip -
              material.shippedQty,
          };
        }),
        $count: supplyingPlantMaterials.$count,
      };
    });

    this.on('orderReport', async (req) => {
      const { plant, material, partGroup, search, top, skip } =
        validateMandatoryRequestParams(req, ['plant']);

      const [plantData] = await chx
        .read(chx.entities.PlantData)
        .where({ receivingPlant: plant });

      if (!plantData) {
        req.reject(400, 'PLANT_MUST_BE_RECEIVING_PLANT');
      }

      const supplyingPlant = {
        plant: plantData.supplyingPlant,
        name: plantData.supplyingPlantName,
      };

      const receivingPlantMaterials = await this.getMaterials(chx, {
        plant,
        material,
        partGroup,
        search,
        limit: top,
        offset: skip,
      });

      const result = receivingPlantMaterials.reduce((acc, material) => {
        acc[material.material] = {
          material: material.material,
          description: material.description,
          partGroup: material.partGroup,
          receivingPlantOrderQty: material.orderQty,
          supplyingPlantQoh: 0,
        };
        return acc;
      }, {});

      const supplyingPlantMaterials = await this.getMaterials(chx, {
        plant: supplyingPlant.plant,
        material: Object.keys(result),
      });
      supplyingPlantMaterials.forEach((material) => {
        if (result[material.material]) {
          result[material.material].supplyingPlantQoh = material.qoh;
        }
      });

      return {
        supplyingPlantName: supplyingPlant.name,
        orderReportItems: Object.values(result),
        $count: receivingPlantMaterials.$count,
      };
    });

    this.on('comparisonReport', async (req) => {
      const { plants, filter, qohFilter, sort, top, skip } =
        validateMandatoryRequestParams(req, ['plants']);

      const requestedPlants = plants.split(',');

      if (requestedPlants.length < 2 || requestedPlants.length > 3) {
        req.reject(400, 'INVALID_NO_OF_PLANTS_BTW_2_3');
      }

      const plantData = await chx
        .read(chx.entities.PlantData)
        .where({ receivingPlant: requestedPlants })
        .or({ supplyingPlant: requestedPlants });

      const foundPlants = new Map();

      plantData.forEach((row) => {
        if (requestedPlants.includes(row.receivingPlant)) {
          foundPlants.set(row.receivingPlant, row.receivingPlantName);
        }

        if (requestedPlants.includes(row.supplyingPlant)) {
          foundPlants.set(row.supplyingPlant, row.supplyingPlantName);
        }
      });

      if (foundPlants.size !== requestedPlants.length) {
        req.reject(404, 'PLANT_NOT_FOUND');
      }

      const mainPlant = requestedPlants[0];
      const comparisonPlants = requestedPlants.splice(1);

      const qohFilterJson = qohFilter ? JSON.parse(qohFilter) : {};
      const mainPlantFilter = qohFilterJson[mainPlant];
      delete qohFilterJson[mainPlant];

      const sortData = sort ? sort.split(' ') : [];
      const sortKey = sortData[0];
      const sortType = sortData[1] || 'ASC';
      const isQohSortKey = sortKey && sortKey.endsWith('_qoh');
      const qohSortPlant = isQohSortKey ? sortKey.split('_')[0] : null;

      if (
        Object.keys(qohFilterJson).length > 1 ||
        (isQohSortKey &&
          Object.keys(qohFilterJson)[0] &&
          ![mainPlant, Object.keys(qohFilterJson)[0]].includes(qohSortPlant))
      ) {
        req.reject(404, 'FILTER_LIMITATION_2_PLANTS');
      }
      const selectedPlantFilter = qohFilterJson[Object.keys(qohFilterJson)[0]];

      // if selectedPlantFilter is set, then replace that plant with the first element in comparisonPlants
      if (selectedPlantFilter) {
        let filteredPlantIndex = comparisonPlants.findIndex(
          (plant) => plant === Object.keys(qohFilterJson)[0]
        );
        comparisonPlants[filteredPlantIndex] = comparisonPlants[0];
        comparisonPlants[0] = Object.keys(qohFilterJson)[0];
      } else if (qohSortPlant) {
        comparisonPlants.unshift(qohSortPlant);
      }

      const relatedPlantsMap = transformPlantData(
        await chxTech
          .read(chxTech.entities.PlantData)
          .where({ supplyingPlant: mainPlant })
          .or({ receivingPlant: mainPlant })
      ).reduce((acc, row) => acc.set(row.plant, row), new Map());

      if (comparisonPlants.some((plant) => !relatedPlantsMap.has(plant))) {
        req.reject(404, 'UNRELATED_PLANTS');
      }

      const selectedPlantType = relatedPlantsMap.get(comparisonPlants[0])
        .isSupplying
        ? 'supplying'
        : 'receiving';
      const mainPlantType =
        selectedPlantType === 'supplying' ? 'receiving' : 'supplying';
      const [supplyingPlant, receivingPlant] =
        selectedPlantType === 'supplying'
          ? [comparisonPlants[0], mainPlant]
          : [mainPlant, comparisonPlants[0]];

      const [limit, offset] = this.getLimitOffset(top, skip);
      const comparisonQuery = this.read(this.entities.ComparisonReport)
        .where({
          receivingPlant,
          supplyingPlant,
        })
        .limit(limit, offset);
      comparisonQuery.SELECT.count = true;

      if (filter) {
        const parsedFilter = cds.odata.parse(`?$filter=${filter}`);
        comparisonQuery.SELECT.where.push('and', ...parsedFilter.SELECT.where);
      }
      if (mainPlantFilter) {
        const parsedMainPlantFilter = cds.odata.parse(
          `?$filter=${mainPlantFilter.replaceAll('qoh', `${mainPlantType}PlantQoh`)}`
        );
        comparisonQuery.SELECT.where.push(
          'and',
          ...parsedMainPlantFilter.SELECT.where
        );
      }
      if (selectedPlantFilter) {
        const parsedSelectedPlantFilter = cds.odata.parse(
          `?$filter=${selectedPlantFilter.replaceAll(
            'qoh',
            `${selectedPlantType}PlantQoh`
          )}`
        );
        comparisonQuery.SELECT.where.push(
          'and',
          ...parsedSelectedPlantFilter.SELECT.where
        );
      }

      if (isQohSortKey) {
        const sortPlantType =
          qohSortPlant === mainPlant ? mainPlantType : selectedPlantType;
        comparisonQuery.orderBy(`${sortPlantType}PlantQoh ${sortType}`);
      } else if (sortKey) {
        comparisonQuery.orderBy(`${sortKey} ${sortType}`);
      }

      const comparisonData = await comparisonQuery;

      const result = comparisonData.reduce(
        (accum, row) =>
          accum.set(row.material, {
            material: row.material,
            description: row.description,
            partGroup: row.partGroup,
            plants: [
              {
                plant: row.supplyingPlant,
                plantName: row.supplyingPlantName,
                qoh: row.supplyingPlantQoh,
                category: row.supplyingScoreCategory,
              },
              {
                plant: row.receivingPlant,
                plantName: row.receivingPlantName,
                qoh: row.receivingPlantQoh,
                category: row.receivingScoreCategory,
              },
            ],
          }),
        new Map()
      );

      if (comparisonPlants[1]) {
        const isSupplying = relatedPlantsMap.get(
          comparisonPlants[1]
        ).isSupplying;
        const otherPlantMaterials = await this.read(
          this.entities.ComparisonReport
        )
          .where(
            isSupplying
              ? {
                  receivingPlant: mainPlant,
                  supplyingPlant: comparisonPlants[1],
                }
              : {
                  receivingPlant: comparisonPlants[1],
                  supplyingPlant: mainPlant,
                }
          )
          .and({ material: Array.from(result.keys()) });

        const otherPlantMaterialsMap = otherPlantMaterials.reduce(
          (acc, row) => acc.set(row.material, row),
          new Map()
        );

        const plantType = isSupplying ? 'supplying' : 'receiving';
        result.forEach((row) => {
          if (otherPlantMaterialsMap.has(row.material)) {
            row.plants.push({
              plant: otherPlantMaterialsMap.get(row.material)[
                `${plantType}Plant`
              ],
              plantName: otherPlantMaterialsMap.get(row.material)[
                `${plantType}PlantName`
              ],
              qoh: otherPlantMaterialsMap.get(row.material)[
                `${plantType}PlantQoh`
              ],
              category: otherPlantMaterialsMap.get(row.material)[
                `${plantType}ScoreCategory`
              ],
            });
          } else {
            row.plants.push({
              plant: comparisonPlants[1],
              plantName: foundPlants.get(comparisonPlants[1]),
              qoh: 0,
              category: STOCK_CATEGORY.STOCK_OUT,
            });
          }
        });
      }

      return {
        value: Array.from(result.values()),
        $count: comparisonData.$count,
      };
    });

    this.on('combinedInventoryReport', async (req) => {
      const {
        supplyingPlant,
        receivingPlant,
        material,
        partGroup,
        search,
        top,
        skip,
      } = validateMandatoryRequestParams(req, [
        'supplyingPlant',
        'receivingPlant',
      ]);

      const [plantData] = await chx
        .read(chx.entities.PlantData)
        .where({ receivingPlant, supplyingPlant });

      if (!plantData) {
        req.reject(404, 'PLANT_COMBINATION_NOT_FOUND');
      }

      const plantMap = {
        [plantData.supplyingPlant]: plantData.supplyingPlantName,
        [plantData.receivingPlant]: plantData.receivingPlantName,
      };

      const receivingMaterials = await this.getMaterials(chx, {
        plant: receivingPlant,
        material,
        partGroup,
        search,
        limit: top,
        offset: skip,
      });

      const supplyingMaterials = await this.getMaterials(chx, {
        plant: supplyingPlant,
        material: receivingMaterials.map((m) => m.material),
      });

      const supplyingMaterialsMap = new Map(
        supplyingMaterials.map((m) => [m.material, m])
      );

      const materialsMap = new Map();
      receivingMaterials.forEach((material) => {
        const value = materialsMap.get(material.material) || {
          material: material.material,
          description: material.description,
          partGroup: material.partGroup,
          inTransit: material.inTransit || 0,
        };

        value['receivingPlant'] = {
          plant: material.plant,
          plantName: plantMap[material.plant],
          min: material.min,
          max: material?.max || 0,
          qoh: material?.qoh || 0,
        };

        const supplyingMaterial = supplyingMaterialsMap.get(material.material);
        if (supplyingMaterial) {
          value['supplyingPlant'] = {
            plant: supplyingMaterial.plant,
            plantName: plantMap[supplyingMaterial.plant],
            min: supplyingMaterial.min,
            max: supplyingMaterial.max || 0,
            qoh: supplyingMaterial.qoh || 0,
            wip: supplyingMaterial.wip || 0,
          };
        } else {
          value['supplyingPlant'] = {
            plant: supplyingPlant,
            plantName: plantMap[supplyingPlant],
            min: 0,
            max: 0,
            qoh: 0,
            wip: 0,
          };
        }

        materialsMap.set(material.material, value);
      });

      return {
        value: [...materialsMap.values()].map((m) => ({
          ...m,
          combinedSummary: {
            plantName: `${m.supplyingPlant.plantName} + ${m.receivingPlant.plantName}`,
            min: m.supplyingPlant.min + m.receivingPlant.min,
            max: m.supplyingPlant.max + m.receivingPlant.max,
            qoh: m.supplyingPlant.qoh + m.receivingPlant.qoh,
            wip: m.supplyingPlant.wip,
          },
        })),
        $count: receivingMaterials.$count,
      };
    });

    return super.init();
  }

  /**
   * Get limit and offset
   * @param {number} top
   * @param {number} skip
   * @returns {[number, number]}
   */
  getLimitOffset(top, skip) {
    const DEFAULT_LIMIT = 20,
      DEFAULT_OFFSET = 0;
    const limit = top || DEFAULT_LIMIT,
      offset = skip || DEFAULT_OFFSET;

    return [limit, offset];
  }

  /**
   * Builds a query for material data
   * @param {object} chx - cds connection
   * @param {object} params - query parameters
   */
  buildMaterialQuery(
    chx,
    { plant, material, partGroup, search, limit, offset }
  ) {
    const query = chx
      .read(chx.entities.MaterialData)
      .limit(limit, offset)
      .where({
        board: 'Y',
        plant,
        ...(material && {
          material:
            typeof material === 'string' ? material.split(',') : material,
        }),
        ...(partGroup && {
          partGroup:
            typeof partGroup === 'string' ? partGroup.split(',') : partGroup,
        }),
      });

    if (search) {
      if (search != encodeURIComponent(search)) {
        query.and`contains(description, ${search})`;
      } else {
        query.where`
        contains(material, ${search})
        or contains(description, ${search})
        or contains(partGroup, ${search})
      `;
      }
    }

    query.SELECT.count = true;

    return query;
  }

  /**
   * Get materials
   * @param {object} chx - cds connection
   * @param {{
   *   plant: string,
   *   material: string,
   *   partGroup: string,
   *   search: string,
   *   limit: number,
   *   offset: number
   * }} params - query parameters
   * @returns {object[]}
   */
  async getMaterials(
    chx,
    { plant, material, partGroup, search, limit, offset }
  ) {
    if (material && Array.isArray(material) && material.length === 0) {
      return [];
    }
    [limit, offset] = this.getLimitOffset(limit, offset);
    return await this.buildMaterialQuery(chx, {
      plant,
      material,
      partGroup,
      search,
      limit,
      offset,
    });
  }

  /**
   * Transforms report data
   * @param {object} client
   * @param {object[]} data - report data
   */
  async transformReportData(client, data) {
    const REPORT_NUMERIC_COLUMNS = [
      'supplyingPlantMin',
      'supplyingPlantMax',
      'supplyingPlantWip',
      'supplyingPlantQoh',
      'supplyingPlantQohWip',
      'inTransit',
      'shippedQty',
      'receivingPlantMin',
      'receivingPlantMax',
      'receivingPlantQoh',
      'receivingPlantOrderQty',
      'receivingPlantDemand',
      'combinedMin',
      'combinedMax',
      'combinedQoh',
      'combinedWip',
      'productionDemand',
    ];

    const plantData = await client.read(client.entities.PlantData);
    const plantMap = new Map();
    plantData.forEach((row) => {
      plantMap.set(row.supplyingPlant, row.supplyingPlantName);
      plantMap.set(row.receivingPlant, row.receivingPlantName);
    });

    data.forEach((row) => {
      REPORT_NUMERIC_COLUMNS.forEach((key) => {
        if (row[key]) {
          row[key] = Number(row[key]);
        }
      });
      row.supplyingPlantName = plantMap.get(row.supplyingPlant);
      row.receivingPlantName = plantMap.get(row.receivingPlant);
    });
  }
};
