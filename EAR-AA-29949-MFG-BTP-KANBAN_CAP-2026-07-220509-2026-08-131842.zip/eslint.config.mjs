import cds from '@sap/cds/eslint.config.mjs';
import prettier from 'eslint-plugin-prettier';
import prettierConfig from 'eslint-config-prettier';

export default [
  {
    files: ['**/*.js', '**/*.mjs'],
    plugins: {
      prettier,
    },
    rules: {
      'prettier/prettier': 'warn',
    },
    ignores: ['dist/**', 'gen/**/*'],
  },
  prettierConfig,
  ...cds.recommended,
];
