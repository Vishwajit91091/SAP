sap.ui.define([
    "sap/ui/export/Spreadsheet"
], function (Spreadsheet) {
    "use strict";
    return {

          DynamicExcelDownload: function (aColumns, data, fileName) {
            const aData = data;
           

            const oSettings = {
                workbook: {
                    columns: aColumns
                },
                dataSource: aData,
                fileName: fileName
            };

            const oSpreadsheet = new Spreadsheet(oSettings);

            oSpreadsheet.build()
                .finally(function () {
                    oSpreadsheet.destroy();
                });
        },

        DownloadExcel: function (downloadThis) {
            const aData = downloadThis.getModel("mainView").getProperty("/receivingPlantData");

            const aColumns = [
                {
                    label: "Material",
                    property: "material",
                    type: "string"
                },
                {
                    label: " Material Description",
                    property: "description",
                    type: "string"
                },
                {
                    label: "Material Group",
                    property: "partGroup",
                    type: "string"
                },
              
                {
                    label: "BA QOH",
                    property: "supplyingPlantQoh",
                    type: "number"
                },
                {
                    label: "Order Quantity",
                    property: "receivingPlantOrderQty",
                    type: "number"
                }
            ];

            const oSettings = {
                workbook: {
                    columns: aColumns
                },
                dataSource: aData,
                fileName: "OrderReport.xlsx"
            };

            const oSpreadsheet = new Spreadsheet(oSettings);

            oSpreadsheet.build()
                .finally(function () {
                    oSpreadsheet.destroy();
                });
        }


    };
});