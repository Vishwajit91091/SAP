sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/table/Column",
    "sap/m/Label",
    "sap/m/Text",
    "sap/m/HBox"
], function (JSONModel, Column, Label, Text, HBox) {
    "use strict";
    return {

        /**
         * Dynamically creates a table based on the provided configuration
         * @param {object} that 
         * @param {object} oConfig 
         */

        createDynamicTable: function (dynamicThis, oConfig) {
            const that = this;
            const oTable = dynamicThis.byId(oConfig.tableId);
            const oModel = new JSONModel(oConfig.data);
            dynamicThis.getView().setModel(oModel, oConfig.modelName);
            oTable.removeAllColumns();
            const aColumns = oConfig.defaultVisibleColumns;

            // =========================
            // CREATE COLUMNS
            // =========================

            aColumns.forEach(function (sColumn) {
                const oColumn = new Column({
                    // ...(sColumn === "description" && { width: "30rem" }),
                    // eslint-disable-next-line no-nested-ternary
                    ...(sColumn === "description" ? { width: "30rem" } : sColumn === "material" ? { width: "10rem" } : {}),
                    minWidth: sColumn === "description" ? 200 : 150,
                    label: new Label({
                        text: that._getColumnText(sColumn, dynamicThis)
                    }),

                    template: new Text({ text: "{" + oConfig.modelName + ">" + sColumn + "}" }),
                    sortProperty: oConfig.sortableColumns.includes(sColumn) ? sColumn : null,
                    visible: oConfig.defaultVisibleColumns.includes(sColumn)
                });
                oColumn.data("p13nKey", sColumn);
                oTable.addColumn(oColumn);
            });
            oTable.bindRows({
                path: oConfig.modelName + ">/"
            });

        },

        /**
         * called to apply colors to the cells of the comparison table based on the values and configuration provided
         * @param {object} oTable 
         * @param {object} oConfig 
         */
        _applyComparisonTableColors: function (oTable, oConfig) {

            const aRows = oTable.getRows();

            aRows.forEach(function (oRow) {

                const aCellDom = oRow.getDomRef()?.querySelectorAll("td");

                if (!aCellDom) {
                    return;
                }

                // Always clear previous colors
                aCellDom.forEach(function (oCellDom) {
                    oCellDom.classList.remove(
                        "stockOut",
                        "underStock",
                        "triggerPoint",
                        "optimalStock",
                        "overStock"
                    );
                });

                const oContext = oRow.getBindingContext(oConfig.modelName);

                if (!oContext) {
                    return;
                }

                const oData = oContext.getObject();

                if (oData.material === "") {
                    return;
                }

                aCellDom.forEach(function (oCellDom, index) {

                    const oColumn = oTable.getColumns()[index];

                    if (!oColumn) {
                        return;
                    }

                    const sColumnName = oColumn.data("p13nKey");

                    if (oConfig.colorColumns.includes(sColumnName)) {

                        const sClrColumn = sColumnName.replace("_QOH", "_CLR");
                        const sColorClass = oData[sClrColumn];

                        if (sColorClass) {
                            oCellDom.classList.add(sColorClass);
                        }

                    }

                });

            });

        },

        createHealthIndexTable: function (dynamicThis, oConfig) {

            const oTable = dynamicThis.byId(oConfig.tableId);
            // =========================
            // SET MODEL
            // =========================
            const oModel = new JSONModel(oConfig.data);
            dynamicThis.getView().setModel(oModel, oConfig.modelName);
            // =========================
            // RESET TABLE
            // =========================
            oTable.removeAllColumns();
            oTable.setModel(oModel, oConfig.modelName);
            oTable.bindRows({ path: oConfig.modelName + ">/results" });

            // =========================
            // FIRST COLUMN
            // =========================

            // oTable.addColumn(
            //     new sap.ui.table.Column({
            //         width: oConfig.firstColumn.width || "12rem",
            //         label: new sap.m.Label({ text: oConfig.firstColumn.header }),
            //         template: new sap.m.Text({ text: { path: oConfig.modelName + ">" + oConfig.firstColumn.field } })
            //     })
            // );

            const oMetrialGroupColumn = new sap.ui.table.Column({
                // width: "12rem",
                minWidth: 200,
                label: new sap.m.Label({ text: oConfig.firstColumn.header }),
                template: new sap.m.Text({ text: { path: oConfig.modelName + ">" + oConfig.firstColumn.field } })
            });
            oMetrialGroupColumn.data("exportProperty", oConfig.firstColumn.field);
            oMetrialGroupColumn.data("exportLabel", oConfig.firstColumn.header);
            oTable.addColumn(oMetrialGroupColumn);

            // =========================
            // DYNAMIC MONTH COLUMNS
            // =========================

            oConfig.data.months.forEach(
                function (sMonth) {
                    // =========================
                    // SCORE COLUMN
                    // =========================

                    const sDisplayMonth = sMonth.replace(
                        /^([A-Za-z]{3})(\d{4})$/,
                        "$1-$2"
                    );


                    const oScoreColumn = new sap.ui.table.Column({
                        // width: "", 
                        minWidth: 100,
                        headerSpan: 2,
                        multiLabels: [
                            // new sap.m.Label({ width: "100%", text: sMonth, textAlign: "Center" }),
                            // new sap.m.Label({ width: "100%", text: "Score", textAlign: "Center" })
                            new sap.m.Label({ width: "100%", text: sDisplayMonth, textAlign: "Center" }),
                            new sap.m.Label({ width: "100%", text: "Score", textAlign: "Center" })
                        ],

                        template: new sap.m.HBox({
                            justifyContent: "Center",
                            items: [
                                new sap.m.Text({ text: { path: oConfig.modelName + ">" + sMonth + "/" + oConfig.scoreField } })
                            ]
                        })
                    });
                    oScoreColumn.data("exportProperty", sMonth + "_Score");
                    oScoreColumn.data("exportLabel", `${sDisplayMonth} - Score`);

                    oTable.addColumn(oScoreColumn);



                    // =========================
                    // GRADE COLUMN
                    // =========================


                    const oGradeColumn = new sap.ui.table.Column({
                        // width: "",
                        minWidth: 100,
                        headerSpan: 2,
                        multiLabels: [
                            new sap.m.Label({ text: sMonth, textAlign: "Center", width: "100%" }),
                            new sap.m.Label({ text: "Grade", textAlign: "Center", width: "100%" })
                        ],
                        template:
                            new sap.m.HBox({
                                justifyContent: "Center",
                                items: [
                                    new sap.m.Text({
                                        text: {
                                            path: oConfig.modelName + ">" + sMonth + "/Grade"
                                        }
                                    })
                                ]
                            })
                    });

                    oGradeColumn.data("type", "GRADE");
                    oGradeColumn.data("month", sMonth);

                    oGradeColumn.data("exportProperty", sMonth + "_Grade");
                    oGradeColumn.data("exportLabel", `${sMonth} - Grade`);

                    oTable.addColumn(oGradeColumn);

                }

            );

        },


        createGroupedDynamicTable: function (dynamicThis, oConfig) {

            const oTable = dynamicThis.byId(oConfig.tableId);
            const oModel = new JSONModel(oConfig.data);
            dynamicThis.getView().setModel(oModel, oConfig.modelName);
            oTable.removeAllColumns();
            oTable.setModel(oModel, oConfig.modelName);
            oTable.bindRows({ path: oConfig.modelName + ">/" });

            const aColumns = oConfig.columns || [];

            // =========================
            // GROUP COUNT
            // =========================

            const mGroupCount = {};
            aColumns.forEach(function (oCol) {
                if (oCol.group) {
                    if (!mGroupCount[oCol.group]) {
                        mGroupCount[oCol.group] = 0;
                    }
                    mGroupCount[oCol.group]++;
                }
            });

            // =========================
            // CREATE COLUMNS
            // =========================

            aColumns.forEach(function (oCol, index) {
                let aLabels = [];
                // single column without group
                if (!oCol.group) {
                    aLabels = [new Label({ text: oCol.label })];
                }
                // Grouped column with group label and column label
                else {
                    aLabels = [new Label({ text: oCol.group, textAlign: "Center", width: "100%" }),
                    new Label({ text: oCol.label, textAlign: "Center", width: "100%" })
                    ];
                }

                const iMaxDataLength = Math.max(
                    oCol.label?.length || 0,
                    ...oConfig.data.map(row =>
                        String(row[oCol.field] ?? "").length
                    )
                );

                let sDynamicWidth = Math.max(
                    Math.ceil(iMaxDataLength * 0.7),
                    5
                ) + "rem";

                // Force width for Material Description column
                if (oCol.field === "description") {
                    sDynamicWidth = "30rem";
                }
                if (oCol.field === "material") {
                    sDynamicWidth = "10rem";
                }

                const bSortable = ![
                    "material",
                    "description",
                    "partGroup"
                ].includes(oCol.field);

                const oTableColumn = new sap.ui.table.Column({
                    width: oCol.width || sDynamicWidth,
                    multiLabels: aLabels,
                    headerSpan: oCol.group ? mGroupCount[oCol.group] : 1,
                    template: new Text({ text: { path: oConfig.modelName + ">" + oCol.field } }),
                    sortProperty: bSortable ? oCol.field : null
                    // filterProperty: oCol.field
                });

                oTableColumn.data("p13nKey", oCol.field);
                oTableColumn.data("group", oCol.group);
                oTableColumn.data("originalIndex", index);

                oTableColumn.data("field", oCol.field);
                oTableColumn.data("field", oCol.field);

                oTableColumn.data("isAggregatable", oCol.isAggregatable);
                oTable.addColumn(oTableColumn);
            });

        },

        _getColumnText: function (sColumn, oController) {
            const oBundle = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
            return oBundle.hasText(sColumn) ? oBundle.getText(sColumn) : sColumn;
        }

    };
});