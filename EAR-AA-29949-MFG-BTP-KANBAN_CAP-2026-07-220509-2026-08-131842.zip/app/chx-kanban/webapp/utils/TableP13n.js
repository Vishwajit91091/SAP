/* eslint-disable max-params */
 
sap.ui.define([
    "sap/m/p13n/Engine",
    "sap/m/p13n/SelectionController",
    "sap/m/p13n/SortController",
    "sap/m/p13n/FilterController",
    "sap/m/table/ColumnWidthController",
    "sap/m/p13n/MetadataHelper",
    "sap/ui/model/Sorter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
     
], function (Engine, SelectionController, SortController, FilterController, ColumnWidthController, MetadataHelper, Sorter, Filter, FilterOperator
) {
    "use strict";
    var global;
    const TableP13n = {

        _mInstanceData: {},

        register: function (oController, oConfig) {
            global = oController;
            const oTable = oController.byId(oConfig.tableId);
            const oMetadataHelper = new MetadataHelper(oConfig.metadata);
            this._mInstanceData[oConfig.tableId] = { helper: oMetadataHelper };
            Engine.getInstance().register(oTable, {
                helper: oMetadataHelper,
                controller: {
                    Columns: new SelectionController({
                        targetAggregation: "columns",
                        control: oTable
                    }),
                    Sorter: new SortController({
                        control: oTable
                    }),
                    Filter: new FilterController({
                        control: oTable
                    }),
                    ColumnWidth: new ColumnWidthController({
                        control: oTable
                    })
                }

            });
            Engine.getInstance().attachStateChange(
                this._handleStateChange.bind(this)
            );

        },

        openSettings: function (oController, oEvent) {
            const oButton = oEvent.getSource();
            const oTable = oController;
            Engine.getInstance().show(oTable, [
                "Columns",
                "Sorter"
            ], {

                contentHeight: "50rem",
                contentWidth: "45rem",
                source: oButton

            });

        },

        /* eslint-disable max-statements */
        // eslint-disable-next-line complexity
        _handleStateChange: function (oEvt) {

            const oTable = oEvt.getParameter("control");
            const oState = oEvt.getParameter("state");
            if (!oState) { return; }
            const sTableId = oTable.getId().split("--").pop();
            this._updateColumns(oTable, oState);


            let aSorters = this._createSorters(sTableId, oState);
            const aFilters = this._createFilters(oState);
            const oModel = global.getModel("mainView");

            let aData;
            const bReceving = global.oDashBoardModel.getProperty("/isReceivingPlant");
            const bSupplying = global.oDashBoardModel.getProperty("/isSupplyingPlant");
            if (bReceving) {

                // receiving order report table
                if (sTableId === "idReceivingOrderReportTable") {
                    aData = oModel.getProperty("/receivingFullPlantData");

                    global.getModel("mainView").setProperty("/sortPropertyTableP13Rece", aSorters);

                    aData = this._processTableData(
                        aData,
                        aFilters,
                        aSorters,
                        (oTotalRow, aNormalData) => {
                            const oSum = this._columnSumCalculation(
                                aNormalData,
                                bReceving,
                                bSupplying
                            );

                            oTotalRow.supplyingPlantQoh = oSum.totalQOH;
                            oTotalRow.receivingPlantOrderQty = oSum.totalOrderQty;
                        }
                    );

                    oModel.setProperty("/receivingPlantData", aData);
                    oTable.setVisibleRowCount(aData.length);
                }

                // receiving comparison table

                if (sTableId === "idReceComparisonTable") {
                    //store sorting data for controller use
                    global.getModel("mainView").setProperty("/sortPropertyTableP13ReceCompp", aSorters);
                    aData = oModel.getProperty("/comparisonRecevingData") || [];
                    aData = this._processTableData(aData, aFilters, aSorters);
                    
           

                    global.getModel("ComparisonReport").setData(aData);
                    oTable.setVisibleRowCount(aData.length);

                }


                // receiving inventory table
                if (sTableId === "idReceCombinedInventoryTable") {

                    var that = this;
                    let aBackendSorters;
                    if (aSorters.length > 0) {
                        aBackendSorters = aSorters.map(function (oSorter) {
                            return new sap.ui.model.Sorter(
                                that.convertToBackendField(oSorter.sPath),
                                oSorter.bDescending
                            );

                        });
                    }

                    global.getModel("mainView").setProperty("/sortPropertyTableP13ReceInventory", aBackendSorters || aSorters);


                    aData = oModel.getProperty("/OdessaCombinedInventoryData") || [];
                    this._rebuildHeaderSpans(oTable);
                    aData = this._processTableData(aData, aFilters, aSorters);
                    global.getModel("OdessaCombinedInventoryModel").setData(aData);
                    oTable.setVisibleRowCount(aData.length);

                }
            }
            if (!bReceving && bSupplying) {
                // supplying order report table
                if (sTableId === "idSupplyingReportTable") {
                    // store sorting property
                    if (aSorters.length > 0) {
                        global.getModel("mainView").setProperty("/sortPropertyTableP13Supp", aSorters);

                    }

                    aData = oModel.getProperty("/supplyingFullPlantData") || [];
                    aData = this._processTableData(aData,
                        aFilters,
                        aSorters,
                        (oTotalRow, aNormalData) => {
                            const oSum = this._columnSumCalculation(
                                aNormalData,
                                bReceving,
                                bSupplying
                            );



                            oTotalRow.supplyingPlantQohWip = oSum.supplyingPlantQohWip;
                            oTotalRow.shippedQty = oSum.shippedQty;
                            oTotalRow.receivingPlantDemand = oSum.receivingPlantDemandQty;
                            oTotalRow.productionDemand = oSum.productionDemandQty;
                            oTotalRow.supplyingPlantMax = oSum.supplyingPlantMax;
                        }
                    );
                    oModel.setProperty("/supplyingPlantData", aData);
                    oTable.setVisibleRowCount(aData.length);
                }
                // supplying comparison table

                if (sTableId === "idSupplyingComparisonTableId") {
                    aData = oModel.getProperty("/comparisonSupplyingData") || [];

                    // store sorting property
                    global.getModel("mainView").setProperty("/sortPropertyTableP13SupplyingCompp", aSorters);
                    aData = this._processTableData(aData, aFilters, aSorters);
                    global.getModel("SupplyingComparison").setData(aData);
                    oTable.setVisibleRowCount(aData.length);

                }
                // supplying inventory table
                if (sTableId === "idSuppCombinedInventoryTable") {
                    // eslint-disable-next-line no-redeclare
                    var that = this;
                    let aBackendSorters;
                    if (aSorters.length > 0) {
                        aBackendSorters = aSorters.map(function (oSorter) {
                            return new sap.ui.model.Sorter(
                                that.convertToBackendField(oSorter.sPath),
                                oSorter.bDescending
                            );

                        });
                    }

                    global.getModel("mainView").setProperty("/sortPropertyTableP13SuppInventory", aBackendSorters || aSorters);
                    aData = oModel.getProperty("/supplyingCombinedInventoryData") || [];
                    this._rebuildHeaderSpans(oTable);
                    aData = this._processTableData(aData, aFilters, aSorters);
                    global.getModel("supplyingCombinedInventoryModel").setData(aData);
                    oTable.setVisibleRowCount(aData.length);

                }

            }

        },


        convertToBackendField(sPath) {

            const mMapping = {
                // "supplyingPlant_min": "supplyingPlantMin",
                // "supplyingPlant_max": "supplyingPlantMax",
                // "supplyingPlant_qoh": "supplyingPlantQoh",
                // "receivingPlant_min": "receivingPlantMin",
                // "receivingPlant_max": "receivingPlantMax",
                // "receivingPlant_qoh": "receivingPlantQoh",
                // "combinedMin": "combinedMin",
                // "combinedMax": "combinedMax",
                // "combinedQoh": "combinedQoh",


                "combinedSummary_max" : "combinedMax",
                "combinedSummary_min" : "combinedMin",
                "combinedSummary_qoh"  : "combinedQoh",
                "combinedSummary_wip"  : "combinedWip",
                "description" : "description",
                "inTransit" : "inTransit",
                "material" : "material",
                "partGroup" : "partGroup",
                "receivingPlant_max" : "receivingPlantMax",
                "receivingPlant_min" : "receivingPlantMin",
                "receivingPlant_qoh" : "receivingPlantQoh",
                "supplyingPlant_max" : "supplyingPlantMax",
                "supplyingPlant_min" : "supplyingPlantMin",
                "supplyingPlant_qoh" : "supplyingPlantQoh",
                "supplyingPlant_wip" : "supplyingPlantWip"
            };

            return mMapping[sPath] || sPath;
        },

        /* eslint-enable max-statements */



        _columnSumCalculation: function (aNormal, bReceving, bSupplying) {

            let oFooterSumObj = {
                totalQOH: 0,
                totalOrderQty: 0,
                supplyingPlantQohWip: 0,
                shippedQty: 0,
                receivingPlantDemandQty: 0,
                productionDemandQty: 0,
                supplyingPlantMax: 0
            };

            if (bReceving) {
                aNormal.forEach((items) => {
                    if (items.material !== "") {
                        oFooterSumObj.totalQOH += items.supplyingPlantQoh;
                        oFooterSumObj.totalOrderQty += items.receivingPlantOrderQty;
                    }
                });

            }
            if (!bReceving && bSupplying) {

                aNormal.forEach((items) => {
                    if (items.material !== "") {

                        oFooterSumObj.supplyingPlantQohWip += items.supplyingPlantQohWip;
                        oFooterSumObj.shippedQty += items.shippedQty;
                        oFooterSumObj.receivingPlantDemandQty += items.receivingPlantDemand;
                        oFooterSumObj.productionDemandQty += items.productionDemand;
                        oFooterSumObj.supplyingPlantMax += items.supplyingPlantMax;
                    }
                });
            }

            return oFooterSumObj;


        },

        /* function to update the visibility and order of columns in the table based on the state provided by the personalization engine. 
           It first hides all columns and then iterates through the columns specified in the state to make them visible and reorder them according to the specified order. 
           Additionally, it applies any column width settings from the state. 
           Finally, it restores the original order of the visible columns to ensure consistency. */

        _updateColumns: function (oTable, oState) {

            oTable.getColumns().forEach(function (oColumn) {
                oColumn.setVisible(false);
            });

            const aVisibleColumns = [];

            oState.Columns.forEach(function (oProp, iIndex) {

                const oColumn = oTable.getColumns().find(function (oCol) {
                    return oCol.data("p13nKey") === oProp.key;
                });

                if (oColumn) {
                    oColumn.setVisible(true);
                    oTable.removeColumn(oColumn);
                    oTable.insertColumn(oColumn, iIndex);
                    const sWidth = oState.ColumnWidth && oState.ColumnWidth[oProp.key];
                    if (sWidth) {
                        oColumn.setWidth(sWidth);
                    }
                    aVisibleColumns.push(oColumn); // MISSING
                }
            });

            // restore original order
            aVisibleColumns.sort(function (a, b) {
                return (
                    a.data("originalIndex") -
                    b.data("originalIndex")
                );
            });

            aVisibleColumns.forEach(function (oColumn1, iIndex1) {

                oTable.removeColumn(oColumn1);
                oTable.insertColumn(oColumn1, iIndex1);

            });

        },

        _processTableData(aData, aFilters, aSorters, fnUpdateTotal) {
            const oTotalRow = aData.find(item => item.material === "");
            let aNormalData = this._applyFilterAndSort(
                aData.filter(item => item.material !== ""),
                aFilters,
                aSorters
            );

            if (!aNormalData) {
                aNormalData = aData.filter(item => item.material !== "");
            }

            if (oTotalRow && fnUpdateTotal) {
                fnUpdateTotal(oTotalRow, aNormalData);
                return [...aNormalData, oTotalRow];
            }

            return oTotalRow ? [...aNormalData, oTotalRow] : aNormalData;
        },

        _rebuildHeaderSpans: function (oTable) {

            const aVisibleColumns = oTable.getColumns().filter(function (oCol) {
                return oCol.getVisible();
            });

            const mGroups = {};

            aVisibleColumns.forEach(function (oCol) {

                const aLabels = oCol.getMultiLabels();

                if (aLabels.length > 1) {

                    const sGroup = aLabels[0].getText();

                    if (!mGroups[sGroup]) {
                        mGroups[sGroup] = [];
                    }

                    mGroups[sGroup].push(oCol);
                }
            });

            Object.keys(mGroups).forEach(function (sGroup) {

                const aCols = mGroups[sGroup];

                aCols.forEach(function (oCol, index) {

                    if (index === 0) {
                        oCol.setHeaderSpan(aCols.length);
                    } else {
                        oCol.setHeaderSpan(1);
                    }

                });

            });

        },

        _createSorters: function (sTableId, oState) {

            const aSorters = [];
            const oHelper = this._mInstanceData[sTableId].helper;
            if (oState.Sorter) {
                oState.Sorter.forEach(function (oSorter) {
                    const sPath = oHelper.getProperty(oSorter.key).path;
                    aSorters.push(
                        new Sorter(
                            sPath,
                            oSorter.descending
                        )
                    );

                });



            }
            return aSorters;

        },

        /* function to apply filters and sorters to the table data. 
        It first filters the data based on the provided filters, and then sorts the filtered data according to the provided sorters. 
        The filtering is done using the Array.filter method, while sorting is done using the Array.
        sort method with a custom comparator that takes into account multiple sorters and their respective sort directions. */

        _applyFilterAndSort(aData, aFilters, aSorters) {

            // Filter
            let aFilteredSortData;
            if (aFilters.length) {
                aFilteredSortData = aData.filter(obj => {
                    return aFilters.every(f => {
                        // eslint-disable-next-line eqeqeq
                        return obj[f.sPath] == f.oValue1;
                    });
                });
            }

            // Sort
            if (!aFilteredSortData) {
                aFilteredSortData = aData;
            }
            if (aSorters.length) {
                aFilteredSortData.sort((a, b) => {
                    for (let i = 0; i < aSorters.length; i++) {
                        const oSorter = aSorters[i];
                        const sPath = oSorter.sPath;
                        const bDesc = oSorter.bDescending;

                        let vA = a[sPath];
                        let vB = b[sPath];

                        if (vA === null) { vA = ""; }
                        if (vB === null) { vB = ""; }

                        if (vA < vB) {
                            return bDesc ? 1 : -1;
                        }

                        if (vA > vB) {
                            return bDesc ? -1 : 1;
                        }
                    }

                    return 0;
                });
            }

            return aFilteredSortData;
        },
        /* function to create filters based on the state provided by the personalization engine. 
        It iterates through the filter conditions specified in the state and creates Filter instances for each condition, 
        which can then be applied to the table data. */

        _createFilters: function (oState) {

            const aFilters = [];

            if (oState.Filter) {

                Object.keys(oState.Filter).forEach(function (sKey) {

                    oState.Filter[sKey].forEach(function (oCondition) {

                        if (oCondition.values && oCondition.values.length) {

                            aFilters.push(
                                new Filter({
                                    path: sKey,
                                    operator: FilterOperator.EQ,
                                    value1: oCondition.values[0]
                                })
                            );

                        }

                    });

                });

            }

            return aFilters;

        },
        _removeFilters: function (oTable) {
            Engine.getInstance().reset(oTable);
        }

    };

    return TableP13n;

});