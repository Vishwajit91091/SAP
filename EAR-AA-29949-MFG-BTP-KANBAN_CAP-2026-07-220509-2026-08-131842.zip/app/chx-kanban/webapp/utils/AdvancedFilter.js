sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel"
], function (
    BaseObject,
    Fragment,
    JSONModel
) {
    "use strict";

    return BaseObject.extend("com.slb.chxkanban.util.AdvancedFilter", {

        constructor: function () {

            this._oDialog = null;
            this._oView = null;
            this._oTable = null;
            this._aMetadata = [];
            this._mFilterState = {};

        },
        /**
        * Open Advanced Filter Dialog
        */
        open: async function (oConfig) {
            this._oConfig = oConfig;
            this._oController = oConfig.controller;
            this._oView = oConfig.view;
            this._oTable = oConfig.table;
            this._aMetadata = oConfig.metadata;



            // storing previous metadata and filters state for each filterId, so that when user opens the dialog again, it will show the previous state.
            const sFilterId = oConfig.filterId;

            if (!this._mFilterState[sFilterId]) {

                this._mFilterState[sFilterId] = {
                    columns: this._aMetadata,
                    filters: [{
                        column: "",
                        operator: "",
                        operators: [],
                        value1: "",
                        value2: "",
                        showSecondValue: false
                    }]
                };

            } else {
                // Metadata may change between openings
                this._mFilterState[sFilterId].columns = this._aMetadata;
            }

            if (!this._oDialog) {

                this._oDialog = await Fragment.load({
                    id: this._oView.getId(),
                    name: "com.slb.chxkanban.fragments.AdvancedFilterDialog",
                    controller: this
                });

                this._oView.addDependent(this._oDialog);
                this._initializeModel();

            }

            //this._initializeModel();

            // if (!this._oDialog.getModel("advancedFilter")) {
            //     this._initializeModel();
            // }

            this._oDialog.getModel("advancedFilter").setData(this._mFilterState[sFilterId]);



            this._oDialog.open();

        },

        /**
         * Close Dialog
         */
        onCloseAdvancedFilter: function () {

            this._oDialog.close();

        },

        /**
         * Create JSON Model
         */
        _initializeModel: function () {

            var oModel = new JSONModel({

                columns: this._aMetadata,

                filters: [
                    {
                        column: "",
                        operator: "",
                        operators: [],
                        value1: "",
                        value2: "",
                        showSecondValue: false
                    }
                ]

            });

            this._oDialog.setModel(oModel, "advancedFilter");

        },
        onAddFilterRow: function () {

            var oModel = this._oDialog.getModel("advancedFilter");

            var aFilters = oModel.getProperty("/filters");

            aFilters.push({
                column: "",
                operator: "",
                operators: [],
                value1: "",
                value2: "",
                showSecondValue: false
            });

            oModel.refresh(true);

        },

        onDeleteFilterRow: function (oEvent) {

            var oContext = oEvent.getSource().getBindingContext("advancedFilter");

            var sPath = oContext.getPath();

            var iIndex = Number(sPath.split("/").pop());

            var oModel = this._oDialog.getModel("advancedFilter");

            var aFilters = oModel.getProperty("/filters");

            aFilters.splice(iIndex, 1);

            if (aFilters.length === 0) {

                aFilters.push({
                    column: "",
                    operator: "",
                    operators: [],
                    value1: "",
                    value2: "",
                    showSecondValue: false
                });

            }

            oModel.refresh(true);

        },

        onColumnChanged: function (oEvent) {

            var sKey = oEvent.getSource().getSelectedKey();

            var oContext = oEvent.getSource().getBindingContext("advancedFilter");

            var oModel = this._oDialog.getModel("advancedFilter");

            var oRow = oContext.getObject();

            var oColumn = this._aMetadata.find(function (oItem) {

                return oItem.key === sKey;

            });

            if (!oColumn) {
                return;
            }

            var aOperators = [];

            switch (oColumn.dataType) {

                case "sap.ui.model.type.String":

                    aOperators = [
                        { key: "EQ", text: "Equal" },
                        { key: "NE", text: "Not Equal" },
                        { key: "Contains", text: "Contains" },
                        { key: "StartsWith", text: "Starts With" },
                        { key: "EndsWith", text: "Ends With" }
                    ];

                    break;

                case "sap.ui.model.type.Integer":

                    aOperators = [
                        { key: "EQ", text: "Equal" },
                        { key: "NE", text: "Not Equal" },
                        { key: "GT", text: "Greater Than" },
                        { key: "GE", text: "Greater Than Equal" },
                        { key: "LT", text: "Less Than" },
                        { key: "LE", text: "Less Than Equal" },
                        { key: "BT", text: "Between" }
                    ];

                    break;

                case "sap.ui.model.type.Date":

                    aOperators = [
                        { key: "EQ", text: "Equal" },
                        { key: "GT", text: "Greater Than" },
                        { key: "GE", text: "Greater Than Equal" },
                        { key: "LT", text: "Less Than" },
                        { key: "LE", text: "Less Than Equal" },
                        { key: "BT", text: "Between" }
                    ];

                    break;

                default:

                    aOperators = [
                        { key: "EQ", text: "Equal" }
                    ];

            }

            oRow.operator = aOperators[0].key;

            oRow.operators = aOperators;

            oModel.refresh(true);

        },

        onOperatorChanged: function (oEvent) {

            var sOperator = oEvent.getSource().getSelectedKey();

            var oContext = oEvent.getSource().getBindingContext("advancedFilter");

            var oRow = oContext.getObject();

            oRow.showSecondValue = (sOperator === "BT");

            this._oDialog.getModel("advancedFilter").refresh(true);

        },

        onApplyAdvancedFilter: function () {

            var oModel = this._oDialog.getModel("advancedFilter");

            var aRows = oModel.getProperty("/filters");
            let aMetadata = this._aMetadata;
            aRows.map((item) =>{
                let matchingField = aMetadata.find( field => field.key === item.column);
                if (matchingField && matchingField.sPlantId) {
                    item.sPlantId = matchingField.sPlantId;
                }
            });

            if(this._oTable.getId().includes("idSupplyingReportTable"))
            {
                this._oController.getModel("mainView").setProperty("/supplyingPlantAdvancedFilters",aRows);
                this._oConfig.onApplySupplyTableBindingFilters(aRows);
            }
            else if(this._oTable.getId().includes("idReceivingOrderReportTable"))
            {
                this._oController.getModel("mainView").setProperty("/receivingPlantAdvancedFilters",aRows);
                this._oConfig.onApplyReceivingTableBindingFilters(aRows);
            }
            else if(this._oTable.getId().includes("idSuppCombinedInventoryTable"))
            {
                this._oController.getModel("mainView").setProperty("/supplyingPlantInventoryAdvancedFilters",aRows);
                this._oConfig.onApplySuppCombinedTableBindingFilters(aRows);
            }
            else if(this._oTable.getId().includes("idReceCombinedInventoryTable"))
            {
                this._oController.getModel("mainView").setProperty("/receivingPlantInventoryAdvancedFilters",aRows);
                this._oConfig.onApplyReceCombinedTableBindingFilters(aRows);
            }
            else if(this._oTable.getId().includes("idSupplyingComparisonTableId"))
            {
                this._oController.getModel("mainView").setProperty("/supplyingPlantComparisonAdvancedFilters",aRows);
                this._oConfig.onApplySupplyingComparisonFilter(aRows);
            }
            else if(this._oTable.getId().includes("idReceComparisonTable"))
            {
                this._oController.getModel("mainView").setProperty("/receivingComparisonAdvancedFilters",aRows);
                this._oConfig.onApplyReceComparisonAdvancedFilter(aRows);
            }

            this._oDialog.close();


        },

        clearFilters: function () {

            if (!this._oDialog) {
                return;
            }

            const oModel = this._oDialog.getModel("advancedFilter");

            oModel.setProperty("/filters", [{
                column: "",
                operator: "",
                operators: [],
                value1: "",
                value2: "",
                showSecondValue: false
            }]);

            this._oController?.getModel("mainView").setProperty("/supplyingPlantAdvancedFilters", []);
            this._oController?.getModel("mainView").setProperty("/receivingPlantAdvancedFilters", []);
            this._oController?.getModel("mainView").setProperty("/supplyingPlantInventoryAdvancedFilters", []);
            this._oController?.getModel("mainView").setProperty("/receivingPlantInventoryAdvancedFilters", []);
            this._oController?.getModel("mainView").setProperty("/supplyingPlantComparisonAdvancedFilters",[]);
            this._oController?.getModel("mainView").setProperty("/receivingComparisonAdvancedFilters",[]);
        }


    });

});
