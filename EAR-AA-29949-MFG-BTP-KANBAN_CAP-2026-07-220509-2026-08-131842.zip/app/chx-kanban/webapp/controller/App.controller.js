sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.slb.chxkanban.controller.App", {
      onInit() {
      }
  });
});