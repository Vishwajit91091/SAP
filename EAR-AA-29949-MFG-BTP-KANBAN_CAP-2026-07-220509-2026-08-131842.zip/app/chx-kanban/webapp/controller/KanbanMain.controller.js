/* eslint-disable max-params */
/* eslint-disable no-undef */
sap.ui.define([
    "com/slb/chxkanban/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "com/slb/chxkanban/utils/TableP13n",
    "com/slb/chxkanban/utils/DynamicTable",
    "com/slb/chxkanban/utils/DownloadFile",
    "com/slb/chxkanban/model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/BusyDialog",
    "sap/m/Label",
    "sap/m/Link",
    "sap/m/Text",
    "com/slb/chxkanban/utils/AdvancedFilter",
    "sap/m/Button",
    "sap/m/MessageToast"
], (BaseController, JSONModel, TableP13n, DynamicTable, DownloadFile,
    formatter, Filter, FilterOperator,
    MessageBox, BusyDialog, Label, Link, Text, AdvancedFilter, Button, MessageToast) => {
    "use strict";


    return BaseController.extend("com.slb.chxkanban.controller.KanbanMain", {
        formatter: formatter,

        /** Called when the controller is initialized. Used to set up initial models and data for the view. Currently includes:
            - Setting up a view model to manage busy state, delay, and plant selection
            - Initializing the Odessa Comparison Report with default data
            - Initializing the BA Kanban Comparison Report with default data
            - Initializing the inverted comparison data for the combined inventory table
            - Setting up table personalization for all tables in the app (column selection, sorting, filtering, etc.)
           @param {}
           @public  
           @memberof com.slb.chxkanban.controller.Main
         * 
         */

        onInit() {
            const oViewModel = new JSONModel({
                busy: false,
                delay: 0
            });
            this.setModel(oViewModel, "mainView");

            this.busy = new BusyDialog();
            this.oServiceModel = this.getOwnerComponent().getModel();
            this.championXModel = this.getOwnerComponent().getModel("championService");
            this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            this.chartServiceModel = this.getOwnerComponent().getModel("chartService");
            var oDashBoardModel = new JSONModel();
            this.oDashBoardModel = oDashBoardModel;
            this.getView().setModel(oDashBoardModel, "oDashBoardModel");
            this.getView().getModel("oDashBoardModel").setSizeLimit(1000);

            // this.initializeDashboardData();
            //table personalization columns setup for reciving report and supplying  report
            this._setDefaultPagination();
            this._setTablePersonalization();
            this.initializeDashboardData();

            this._oAdvancedFilter = new AdvancedFilter();
            // Inventory count field mapping
            this._inventoyCountFieldMapping();

        },
        onExit: function () {
            if (this.serialNumFragment) {
                this.serialNumFragment.destroy();
                this.serialNumFragment = null;
            }
            if (this.oDashBoardModel) {
                this.oDashBoardModel.destroy();
                this.oDashBoardModel = null;
            }
            if (this.busy) {
                this.busy.destroy();
                this.busy = null;
            }
        },

        /**
         * 
         * Dashboard changes - kishan 
         */
        onIconTabBarSelect: function (oEvent) {
            var sKey = oEvent.getSource().getSelectedKey();
            document.cookie = `selectedTab=${encodeURIComponent(sKey)}; path=/`;
            switch (sKey) {
                case "HOME":
                    this.initializeHomeScreen();
                    break;

                case "REPORTS":
                    this._fnReportBinding();
                    break;

                case "CHARTS & VISUALS":
                    this.initChartsAndVisuals();
                    this._cleanHealthIndexFilters();
                    this._getHealthIndexData().then((data) => {
                        this._healthIndexTableBinding(data);
                    }).catch((error) => {
                        this.showErrorMessage(error.message);
                    });
                    break;
                default:
                    MessageBox.error(this.oBundle.getText("UNKNOWNTAB"));
                    break;
            }
        },

        initializeDashboardData: async function () {
            try {
                let initData = {
                    "plants": [],
                    "selectedPlant": "",
                    "partGroups": [],
                    "selectedPartGroup": "",
                    "searchValue": "",
                    "underStockData": [],
                    "stockOutData": [],
                    "triggerPointData": [],
                    "optimalStockData": [],
                    "overStockData": [],
                    "emptyList": []
                };
                this.oDashBoardModel.setData(initData, true);

                await this.loadPlantData();
                await this.loadPartGroupData();
                await this.loadDashboardData();

                const selectedTabCookie = this.getCookie("selectedTab") || "";
                if (selectedTabCookie) {
                    const selectedTab = (decodeURIComponent(selectedTabCookie));
                    this.byId("idMainNavigationTabBar").setSelectedKey(selectedTab);
                    this.byId("idMainNavigationTabBar").fireSelect({
                        selectedKey: selectedTab
                    });
                }
            }
            catch (err) {
                MessageBox.error(this.oBundle.getText("INITIALIZATION_ERROR"), err.message || err);
            }
        },

        initializeHomeScreen: async function () {
            await this.loadPartGroupData();
            await this.loadDashboardData();
        },

        loadPlantData: async function () {
            //let that = this;
            try {

                const oBinding = this.oServiceModel.bindContext(
                    "/getPlants(...)"
                );
                this.busy.open();
                await oBinding.execute();

                const response = await oBinding.getBoundContext().getObject();
                this.busy.close();
                const aPlants = response?.value || [];

                this.oDashBoardModel.setProperty("/plants", aPlants);
                this.oDashBoardModel.setProperty("/selectedPlant", aPlants[0]?.plant || "");
                this.oDashBoardModel.setProperty("/isSupplyingPlant", aPlants[0]?.isSupplying);
                this.oDashBoardModel.setProperty("/isReceivingPlant", aPlants[0]?.isReceiving);

                let oSessionStoragePlantData = JSON.parse(this.getCookie("selectedPlantData"));
                if (oSessionStoragePlantData) {
                    this.oDashBoardModel.setProperty("/selectedPlant", oSessionStoragePlantData?.plant || "");
                    this.oDashBoardModel.setProperty("/isSupplyingPlant", oSessionStoragePlantData?.isSupplying);
                    this.oDashBoardModel.setProperty("/isReceivingPlant", oSessionStoragePlantData?.isReceiving);
                }
                else {
                    this.oDashBoardModel.setProperty("/selectedPlant", aPlants[0]?.plant || "");
                    this.oDashBoardModel.setProperty("/isSupplyingPlant", aPlants[0]?.isSupplying);
                    this.oDashBoardModel.setProperty("/isReceivingPlant", aPlants[0]?.isReceiving);
                }
                return aPlants;
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("PLANT_DATA_LOADING_ERROR"), err.message || err);
                this.oDashBoardModel.setProperty("/plants", []);
                throw err;
            }
        },

        loadPartGroupData: async function () {
            try {
                let sSelectedPlant = this.oDashBoardModel.getProperty("/selectedPlant"); // Remove this hardcoding after testing

                const oBinding = this.oServiceModel.bindContext(
                    "/getPartGroups(...)"
                );
                oBinding.setParameter("plant", sSelectedPlant);

                this.busy.open();
                await oBinding.execute();

                const response = await oBinding.getBoundContext().getObject();
                this.busy.close();
                let aPartGroups = response?.value || [];
                this.oDashBoardModel.setProperty("/partGroups", aPartGroups);
                this.oDashBoardModel.setProperty("/selectedPartGroup", aPartGroups[0]?.partGroup || "");
                return aPartGroups;
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("PART_GROUP_DATA_LOADING_ERROR"), err.message || err);
                this.oDashBoardModel.setProperty("/partGroups", []);
                throw err;
            }
        },

        loadDashboardData: async function () {
            try {
                let sSelectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                let sSelectedPartGroup = this.oDashBoardModel.getProperty("/selectedPartGroup");
                let sSearchValue = this.oDashBoardModel.getProperty("/searchValue");

                const oBinding = this.oServiceModel.bindContext(
                    "/kanbanDashboard(...)"
                );

                oBinding.setParameter("plant", sSelectedPlant);
                oBinding.setParameter("partGroup", sSelectedPartGroup);
                oBinding.setParameter("search", sSearchValue || "");
                this.busy.open();
                await oBinding.execute();

                const response = await oBinding.getBoundContext().getObject();
                this.busy.close();
                this.oDashBoardModel.setProperty("/underStockData", response?.underStock);
                this.oDashBoardModel.setProperty("/stockOutData", response?.stockOut);
                this.oDashBoardModel.setProperty("/triggerPointData", response?.triggerPoint);
                this.oDashBoardModel.setProperty("/optimalStockData", response?.optimalStock);
                this.oDashBoardModel.setProperty("/overStockData", response?.overStock);

                this.oDashBoardModel.setProperty("/allDashBoardData", []);
                const stockData = [
                    ...(response?.stockOut || []).map(item => ({
                        ...item,
                        status: "STOCKOUT"
                    })),

                    ...(response?.underStock || []).map(item => ({
                        ...item,
                        status: "UNDERSTOCK"
                    })),

                    ...(response?.triggerPoint || []).map(item => ({
                        ...item,
                        status: "TRIGGER"
                    })),

                    ...(response?.optimalStock || []).map(item => ({
                        ...item,
                        status: "OPTIMALSTOCK"
                    })),

                    ...(response?.overStock || []).map(item => ({
                        ...item,
                        status: "OVERSTOCK"
                    }))
                ];

                this.oDashBoardModel.setProperty("/allDashBoardData", stockData);



                var oGrid = this.byId("gridList");



                oGrid.getItems().forEach(function (oItem) {

                    var sStatus = oItem
                        .getBindingContext("oDashBoardModel")
                        .getProperty("status");
                    oItem.removeStyleClass();

                    switch (sStatus) {
                        case "STOCKOUT":
                            oItem.addStyleClass("blackCardBackGroundClass");
                            break;

                        case "UNDERSTOCK":
                            oItem.addStyleClass("redCardBackGroundClass");
                            break;

                        case "TRIGGER":
                            oItem.addStyleClass("yellowCardBackGroundClass");
                            break;

                        case "OPTIMALSTOCK":
                            oItem.addStyleClass("greenCardBackGroundClass");
                            break;

                        case "OVERSTOCK":
                            oItem.addStyleClass("violetCardBackGroundClass");
                            break;

                        default:
                            oItem.addStyleClass("blackCardBackGroundClass");
                    }
                });

                return response;
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("DASHBOARD_DATA_LOADING_ERROR"), err.message || err);
                this.oDashBoardModel.setProperty("/underStockData", []);
                this.oDashBoardModel.setProperty("/stockOutData", []);
                this.oDashBoardModel.setProperty("/triggerPointData", []);
                this.oDashBoardModel.setProperty("/optimalStockData", []);
                this.oDashBoardModel.setProperty("/overStockData", []);
                this.oDashBoardModel.setProperty("/allDashBoardData", []);

                throw err;
            }

        },



        _onPlantChange: async function (oEvent) {

            let oSelectedItem = oEvent.getParameter("selectedItem");
            let selectedObject = oSelectedItem.getBindingContext("oDashBoardModel").getObject();
            document.cookie = `selectedPlantData=${encodeURIComponent(JSON.stringify(selectedObject))}; path=/`;
            this.oDashBoardModel.setProperty("/selectedPlant", selectedObject.plant);
            this.oDashBoardModel.setProperty("/isSupplyingPlant", selectedObject.isSupplying);
            this.oDashBoardModel.setProperty("/isReceivingPlant", selectedObject.isReceiving);
            this.oDashBoardModel.setProperty("/searchValue", "");
            await this.loadPartGroupData();
            await this.loadDashboardData();
            this._fnReportBinding(selectedObject);
            this.initHealthIndex();
            this.initControlChart();

            // health index tab binding
            this._cleanHealthIndexFilters();
            this._getHealthIndexData().then((data) => {
                this._healthIndexTableBinding(data);
            }).catch((error) => {
                this.showErrorMessage(error.message);
            });

        },
        _onSearchDashBoard: function (sValue) {
            if (sValue === "Reset") {
                this.oDashBoardModel.setProperty("/searchValue", "");
                let aPartGroups = this.oDashBoardModel.getProperty("/partGroups") || [];
                this.oDashBoardModel.setProperty("/selectedPartGroup", aPartGroups[0]?.partGroup || "");
            }

            this.loadDashboardData();
        },


        _onPressGoToReports: function () {
            this.byId("idMainNavigationTabBar").setSelectedKey("REPORTS");
            this._fnReportBinding();
        },

        /**
         * 
         * Odessea Dashboard section 
         */

        getSerialNum: async function () {
            var that = this;
            try {
                let selectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                let oSelectedObj = this.oDashBoardModel.getProperty("/selectedObjForMovement");
                let searchValue = this.oDashBoardModel.getProperty("/serialNumSearchValue") || "";
                let storageLocation = this.oDashBoardModel.getProperty("/movementDirection") === "PLUS" ? "3001" : "3000";
                let skip = 0;
                let top = 50;


                const aFilters = [
                    new Filter("material", FilterOperator.EQ, oSelectedObj.material),
                    new Filter("plant", FilterOperator.EQ, selectedPlant),
                    new Filter("storageLocation", FilterOperator.EQ, storageLocation)
                ];

                if (searchValue) {
                    aFilters.push(new Filter("serialNumber", FilterOperator.Contains, searchValue));
                }

                const oBinding = this.championXModel.bindList(
                    "/SerialNumberData",
                    null, null, aFilters
                );
                //Kept this code for reverting if needed will remove it after testing
                // const oBinding = this.championXModel.bindList(
                //     "/SerialNumberData",
                //     null, null, null,
                //     {
                //         $filter: `material eq '${oSelectedObj.material}' and plant eq '${selectedPlant}' and contains(serialNumber, '${searchValue}') and storageLocation eq '${storageLocation}'`
                //         // $search: searchValue || undefined
                //     }
                //     // { 
                //     //     $filter : `material eq 'MATERIAL_NO-00002' and plant eq '0002'`,
                //     //     $search: searchValue ? `"${searchValue}"` : undefined
                //     // }
                // );


                this.busy.open();
                let aAllSerialNums = [];
                while (true) {
                    const aContexts = await oBinding.requestContexts(skip, top);
                    const response = aContexts.map((ctx) => ctx.getObject());
                    aAllSerialNums = aAllSerialNums.concat(response);
                    if (response.length < top) {
                        this.busy.close();
                        if (!this.serialNumFragment) {
                            this.serialNumFragment = await this.loadFragment({
                                name: "com.slb.chxkanban.fragments.serialNumFragment"
                            });
                        }

                        aAllSerialNums = aAllSerialNums.sort((a, b) =>
                            a.serialNumber.localeCompare(b.serialNumber, undefined, {
                                numeric: true
                            })
                        );
                        this.oDashBoardModel.setProperty("/serialNumList", aAllSerialNums);
                        this.serialNumFragment.open();
                        return aAllSerialNums;
                    }
                    skip += top;
                }
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(that.oBundle.getText("SERIALNUMBERS_LOADING_ERROR") + "\n" + (err?.message || err));
                this.oDashBoardModel.setProperty("/serialNumList", []);
                throw err;
            }
        },
        _onPressMove: async function (oEvent) {
            var oSelectedObj = oEvent.getSource().getBindingContext("oDashBoardModel")?.getObject();

            this.oDashBoardModel.setProperty("/selectedObjForMovement", oSelectedObj);
            this.oDashBoardModel.setProperty("/serialNumSearchValue", "");
            this.oDashBoardModel.setProperty("/serialNumList", []);
            this.oDashBoardModel.setProperty("/selectedSerialNums", []);

            var icon = oEvent.getSource().getIcon();
            if (icon.includes("add")) {

                if (oSelectedObj.stockInputValue > oSelectedObj.stagingQoh) {
                    MessageBox.warning(this.oBundle.getText("STOCK_INPUT_EXCEEDS_STAGING_QOH", [oSelectedObj.stagingQoh]));
                    return;
                }

                this.oDashBoardModel.setProperty("/movementDirection", "PLUS");
            }
            else if (icon.includes("less")) {
                this.oDashBoardModel.setProperty("/movementDirection", "MINUS");
            }

            if (oSelectedObj.isSerialized) {
                await this.getSerialNum();
            }
            else {
                MessageBox.confirm("Are you sure you want to move the stock?", {
                    onClose: (oAction) => {
                        if (oAction === MessageBox.Action.OK) {
                            this.triggerMaterialMovement();
                        }
                    }
                });
            }

        },

        _onPressCloseSerialNumFragment: function (oEvent) {
            if (this.serialNumFragment) {
                this.serialNumFragment.close();
            }
            this.oDashBoardModel.setProperty("/selectedObjForMovement", "");
            this.oDashBoardModel.setProperty("/serialNumSearchValue", "");
            this.oDashBoardModel.setProperty("/serialNumList", []);
            let oTable = oEvent.getSource()?.getParent()?.getContent()[1]?.getItems()[2];
            if (oTable) {
                oTable.removeSelections(true);
            }
        },

        _onSerialNumSelection: function (oEvent) {
            let oTable = oEvent.getSource();
            let selectionItem = oEvent.getParameter("listItem");
            let aSelectedItems = oTable.getSelectedItems();
            let selectedObj = this.oDashBoardModel.getProperty("/selectedObjForMovement");
            let isSelectAll = oEvent.getParameter("selectAll");
            if (aSelectedItems.length > Number(selectedObj.stockInputValue)) {
                if (isSelectAll) {
                    oTable.removeSelections(true);
                }
                else {
                    oTable.setSelectedItem(selectionItem, false);
                }
                MessageBox.warning(this.oBundle.getText("SERIALNUM_SELECTION_ERROR"));

            }
        },

        _onSearchSerialNum: async function (oEvent) {
            var searchValue = oEvent.getSource().getValue() || "";
            searchValue = searchValue.trim();
            this.oDashBoardModel.setProperty("/serialNumSearchValue", searchValue);
            await this.getSerialNum();

            if (searchValue === "") {
                let oTable = oEvent.getSource().getParent().getParent().getItems()[2];
                if (oTable) {
                    oTable.removeSelections(true);
                }
            }
        },

        _onPressConfirmSerialNum: function (oEvent) {
            try {
                let selectedObj = this.oDashBoardModel.getProperty("/selectedObjForMovement");
                var oTable = oEvent.getSource()?.getParent()?.getContent()[1]?.getItems()[2];
                var aSelectedItems = oTable.getSelectedItems();
                var aSelectedSerialNums = aSelectedItems?.map(item => item.getBindingContext("oDashBoardModel")?.getObject()?.serialNumber);
                this.oDashBoardModel.setProperty("/selectedSerialNums", aSelectedSerialNums);
                if (aSelectedSerialNums?.length === Number(selectedObj.stockInputValue)) {
                    this.triggerMaterialMovement();

                    oTable.removeSelections(true);
                    if (this.serialNumFragment) {
                        this.serialNumFragment.close();
                    }

                }

                else {
                    MessageBox.warning(this.oBundle.getText("SERIALNUM_MISMATCH_ERROR"));
                }
            }
            catch (err) {
                this.busy.close();
                throw err;
            }


        },
        getSpecificMaterialData: async function (sMaterial) {
            try {
                let sSelectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                const sPath = `/MaterialData(plant='${encodeURIComponent(sSelectedPlant)}',material='${encodeURIComponent(sMaterial)}')?$select=qoh`;

                const oContextBinding = this.championXModel.bindContext(sPath);

                const response = await oContextBinding.requestObject();

                // const response = await oBinding.getBoundContext().getObject();
                return response;
            }
            catch (err) {
                this.busy.close();
                clearInterval(this.timeInterval);
                throw err;
            }
        },

        triggerMaterialMovement: async function () {
            try {
                let selectedObj = this.oDashBoardModel.getProperty("/selectedObjForMovement");
                let movementDirection = this.oDashBoardModel.getProperty("/movementDirection");
                let aSerialNums = this.oDashBoardModel.getProperty("/selectedSerialNums") || [];

                const oAction = this.championXModel.bindContext(
                    "/materialMovement(...)"
                );
                oAction.setParameter("direction", movementDirection);
                oAction.setParameter("plant", this.oDashBoardModel.getProperty("/selectedPlant"));
                oAction.setParameter("material", selectedObj.material);
                oAction.setParameter("quantity", Number(selectedObj.stockInputValue));
                oAction.setParameter("serialNumbers", aSerialNums);

                this.busy.open();
                await oAction.execute();
                const response = oAction.getBoundContext().getObject();
                this.busy.close();
                // MessageBox.success(this.oBundle.getText("MATERIAL_MOVEMENT_SUCCESS_MESSAGE"));

                if (response?.MatDoc) {
                    this.busy.open();
                    let prevResponse = selectedObj;
                    this.timeInterval = setInterval(async () => {
                        let data = await this.getSpecificMaterialData(selectedObj.material);
                        if (prevResponse && data?.qoh !== prevResponse?.qoh) {
                            clearInterval(this.timeInterval);
                            this.loadDashboardData();
                            this.busy.close();
                            MessageBox.success(this.oBundle.getText("MATERIAL_MOVEMENT_SUCCESS_MESSAGE"));
                        }
                        else {
                            prevResponse = data;
                        }

                    }, 2000);
                    // this.loadDashboardData();
                }

                else {
                    MessageBox.error(response?.to_MessageNav?.[0].message || "Material movement failed. Please try again.");
                }

            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("MATERIAL_MOVEMENT_ERROR_MESSAGE"));
                throw err;
            }
        },

        _onStockInputChange: function (oEvent) {
            let oInput = oEvent.getSource();
            let sValue = oInput.getValue();

            // Allow only digits (0-9)
            sValue = sValue.replace(/[^0-9]/g, "");

            oInput.setValue(sValue);
        },

        /**
         * called to fetch the receiving plant data based on the search criteria entered by the user in the Receiving Report tab.
         * Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
         * @param {Object} recevingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
         * @returns {Promise} - A promise that resolves with the receiving plant data or rejects with an error.
         */
        /* eslint-disable complexity */
        _getReceivingPlant: async function (oPlantObj, iTop) {
            const sMaterial = oPlantObj?.material || this.getModel("mainView").getProperty("/materialForSearch") || "";
            const sPartGroup = oPlantObj?.partGroup || this.getModel("mainView").getProperty("/partGroupReceSearch") || "";
            const sSearch = oPlantObj?.search || this.getModel("mainView").getProperty("/searchReceivingReports") || "";
            let iSkip = oPlantObj?.skip || 0;
            try {

                const aFilters = [];

                let isReceivingPlant = this.oDashBoardModel.getProperty("/isReceivingPlant");
                let sSelectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                if (isReceivingPlant) {
                    aFilters.push(new Filter("receivingPlant", FilterOperator.EQ, sSelectedPlant));
                }
                else {
                    aFilters.push(new Filter("supplyingPlant", FilterOperator.EQ, sSelectedPlant));
                }

                if (sMaterial !== "") {
                    aFilters.push(new Filter("material", FilterOperator.EQ, sMaterial));
                }

                if (sPartGroup !== "") {
                    aFilters.push(new Filter("partGroup", FilterOperator.EQ, sPartGroup));
                }

                if (sSearch !== "") {
                    aFilters.push(
                        new Filter({
                            filters: [
                                new Filter("material", FilterOperator.Contains, sSearch),
                                new Filter("description", FilterOperator.Contains, sSearch),
                                new Filter("partGroup", FilterOperator.Contains, sSearch)
                            ],
                            and: false // OR
                        })
                    );
                }

                const advancedFilters = this.getModel("mainView").getProperty("/receivingPlantAdvancedFilters") || [];
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {
                        if (filter.operator === "BT") {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1, filter.value2));
                        }
                        else {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1));
                        }
                    });

                }

                // sorting logic
                let aSorters = [];

                if (this._sortProperty) {
                    aSorters.push(
                        new sap.ui.model.Sorter(
                            this._sortProperty,
                            this._receOrderSorting || false
                        )
                    );
                } else {
                    aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13Rece");
                }


                this.reportService = this.getOwnerComponent().getModel("reportService");
                const oBinding = this.reportService.bindList(
                    "/OrderReport",
                    null,
                    // null,
                    aSorters,
                    aFilters,
                    {
                        $count: true
                    }
                );
                let pageSize;

                if (iTop) {
                    pageSize = iTop;
                    iSkip = 0;
                } else {
                    pageSize = this.getView().getModel("mainView").getProperty("/objPagination/receReportPageSize") || 10;
                }


                const aContexts = await oBinding.requestContexts(iSkip, pageSize);
                const response = aContexts.map((ctx) => ctx.getObject());
                const iCount = oBinding.getLength();
                var obj =
                {
                    "orderReportItems": response,
                    "@odata.count": iCount,
                    "supplyingPlantName": response[0]?.receivingPlantName || ""
                };
                return obj;
            }

            catch (error) {
                throw error;
            }


        },
        /* eslint-enable complexity */

        /**
       * 
       *  Chart Section
       */
        initChartsAndVisuals: function () {
            if (!this.oControlChartModel) {
                this.oControlChartModel = new JSONModel();
            }
            this.oControlChartModel.setProperty("/", {});
            this.getView().setModel(this.oControlChartModel, "oControlChartModel");
            this.setStartAndEndDate("controlChartMaterialGrp");
            this.setStartAndEndDate("controlChartMaterialNum");
            this.setStartAndEndDate("summaryByMonth");
            this.setStartAndEndDate("sumOutOfStock");
            this.initHealthIndex();
            this.initControlChart();

        },

        onChartsAndVisualsTabSelect: function (oEvent) {
            var sKey = oEvent.getSource().getSelectedKey();

            switch (sKey) {
                case "HEALTH_INDEX":
                    this.initHealthIndex();
                    this._cleanHealthIndexFilters();
                    this._getHealthIndexData().then((data) => {
                        this._healthIndexTableBinding(data);
                    }).catch((error) => {
                        this.showErrorMessage(error.message);

                    });
                    break;

                case "CONTROL_CHART":
                    this.initControlChart();
                    break;

                default:
                    MessageBox.error(this.oBundle.getText("UNKNOWNTAB"));
                    break;
            }
        },


        initControlChart: async function () {

            var oComboBox = this.byId("idMaterialNumComboBox");

            oComboBox.setFilterFunction(function (sTerm, oItem) {
                return oItem.getText()
                    .toLowerCase()
                    .indexOf(sTerm.toLowerCase()) > -1;
            });

            // var data = [
            //         { Date: "2024-01-01", Quantity: 120, AverageTotalScore: 130, A: 110, B: 140, C: 125, D: 130, F: 80 },
            //         { Date: "2024-01-02", Quantity: 135, AverageTotalScore: 120, A:112, B: 150, C: 124, D: 135, F: 85 },
            //         { Date: "2024-01-03", Quantity: 128, AverageTotalScore: 60, A: 115, B: 145, C: 125, D: 130, F: 80},
            //         { Date: "2024-01-04", Quantity: 142, AverageTotalScore: 135, A: 105, B: 165, C: 116, D: 130, F: 82 },
            //         { Date: "2024-01-05", Quantity: 138, AverageTotalScore: 131, A: 100, B: 150, C: 117, D: 130, F: 85 },
            //         { Date: "2024-01-06", Quantity: 150, AverageTotalScore: 140, A: 105, B: 157, C: 118, D: 130, F: 85 },
            //         { Date: "2024-01-07", Quantity: 145, AverageTotalScore: 138, A: 105, B: 150, C: 119, D: 130, F: 85 }
            //     ];
            this.oControlChartModel.setProperty("/controlChartMaterialGrpData", []);
            // let materialData = [
            //         { Date: "2024-01-01", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 150 },
            //         { Date: "2024-01-02", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 155 },
            //         { Date: "2024-01-03", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 108 },
            //         { Date: "2024-01-04", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 192 },
            //         { Date: "2024-01-05", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 108 },
            //         { Date: "2024-01-06", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 140 },
            //         { Date: "2024-01-07", maxValue: 150, safetyStock: 120, bufferStock: 130, QOH: 195 }
            //     ];
            this.oControlChartModel.setProperty("/controlChartMaterialNumData", []);


            let aPartGroups = this.oDashBoardModel.getProperty("/partGroups");
            this.oControlChartModel.setProperty("/selectedMaterialGroup", aPartGroups[0]?.partGroup || "");
            this.oControlChartModel.setProperty("/selectedMaterialGroupSummary", aPartGroups[0]?.partGroup || "");

            // this.setStartAndEndDate("controlChartMaterialGrp");
            // this.setStartAndEndDate("controlChartMaterialNum");
            // this.setStartAndEndDate("summaryByMonth");
            await this.loadMaterialList();
            // this.createSummaryByMonthTable();
            // this._onLoadControlChart("MaterialGroup");
            this._onLoadControlChartMaterialGrp();
            this._onLoadControlChartMaterialNum();
            this.loadSummaryByMonthData();


        },

        setStartAndEndDate: function (sValue) {
            let dTodayDate = new Date();
            let dPreviousYearDate = new Date(dTodayDate);
            dPreviousYearDate.setFullYear(dTodayDate.getFullYear() - 1);

            dTodayDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(dTodayDate));
            dPreviousYearDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(dPreviousYearDate));

            if (sValue === "controlChartMaterialGrp") {
                this.oControlChartModel.setProperty("/materialGroupStartDate", dPreviousYearDate);
                this.oControlChartModel.setProperty("/materialGroupEndDate", dTodayDate);
            }

            else if (sValue === "controlChartMaterialNum") {
                this.oControlChartModel.setProperty("/materialNumStartDate", dPreviousYearDate);
                this.oControlChartModel.setProperty("/materialNumEndDate", dTodayDate);
            }

            else if (sValue === "summaryByMonth") {
                this.oControlChartModel.setProperty("/materialGroupSummaryStartDate", dPreviousYearDate);
                this.oControlChartModel.setProperty("/materialGroupSummaryEndDate", dTodayDate);
            }

            else if (sValue === "sumOutOfStock") {
                this.oControlChartModel.setProperty("/sumOutOfStockStartDate", dPreviousYearDate);
                this.oControlChartModel.setProperty("/sumOutOfStockEndDate", dTodayDate);
            }

            else if (sValue === "sumOverStock") {
                this.oControlChartModel.setProperty("/sumOverStockStartDate", dPreviousYearDate);
                this.oControlChartModel.setProperty("/sumOverStockEndDate", dTodayDate);
            }

        },

        loadMaterialList: async function () {
            try {
                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                const oBinding = this.championXModel.bindList(
                    "/Material",
                    null, null, null,
                    {
                        $filter: `plant eq '${sPlant}'`
                    }
                );

                this.busy.open();
                const aContexts = await oBinding.requestContexts(0);

                const response = aContexts.map(ctx => ctx.getObject());

                this.oControlChartModel.setProperty("/materialList", response);
                this.oControlChartModel.setProperty("/selectedMaterialNum", response[0]?.material || "");
                this.busy.close();

                return response;
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("MATERIALLIST_LOADING_ERROR"), err.message || err);
                this.oControlChartModel.setProperty("/materialList", []);
                throw err;
            }
        },

        _onLoadControlChartMaterialGrp: async function (sValue) {
            try {
                const oBindings = this.chartServiceModel.bindContext("/groupControlChart(...)");
                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const sSelectedMaterialGroup = this.oControlChartModel.getProperty("/selectedMaterialGroup") || "";
                const sStartDate = this.oControlChartModel.getProperty("/materialGroupStartDate") || "2024-01-01";
                const sEndDate = this.oControlChartModel.getProperty("/materialGroupEndDate") || "2024-01-07";



                // Date validation
                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error(this.oBundle.getText("START_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error(this.oBundle.getText("END_DATE_FUTURE_ERROR"));
                        return;
                    }
                }





                oBindings.setParameter("plant", sPlant);
                oBindings.setParameter("partGroup", sSelectedMaterialGroup);
                oBindings.setParameter("startDate", sStartDate);
                oBindings.setParameter("endDate", sEndDate);
                this.busy.open();
                await oBindings.execute();
                const response = oBindings.getBoundContext().getObject();
                this.busy.close();
                this.oControlChartModel.setProperty("/controlChartMaterialGrpData", response?.value || []);
                let maxValue = 120;
                if (response?.value && response.value.length > 0) {
                    maxValue = Math.max(...response.value.map(item => item["Average Total Score"]));
                }


                let oVizFrameMatGrp = this.byId("idControlMatGrpChartGraph");
                oVizFrameMatGrp.setVizProperties({
                    title: {
                        visible: false,
                        text: "Average Under Line Corresponds to Grade"
                    },
                    plotArea: {
                        primaryScale: {
                            fixedRange: true,
                            minValue: 0,
                            maxValue: maxValue || 120
                        },
                        dataLabel: {
                            visible: true
                        },
                        colorPalette: ["Black", "Grey", "#00DC66", "#F79220", "#FFCB00", "#F92C2C"],
                        referenceLine: {
                            line: {
                                valueAxis: [
                                    {
                                        value: 100,          // Y-axis value
                                        color: "Grey",
                                        size: 1.5,
                                        type: "solid"

                                    },
                                    {
                                        value: 89.999,          // Y-axis value
                                        color: "#00DC66",
                                        size: 1.5,
                                        type: "solid",
                                        label: {
                                            text: ""
                                        }
                                    },
                                    {
                                        value: 79.999,          // Y-axis value
                                        color: "#F79220",
                                        size: 1.5,
                                        type: "solid",
                                        label: {
                                            text: ""
                                        }
                                    },
                                    {
                                        value: 69.999,          // Y-axis value
                                        color: "#FFCB00",
                                        size: 1.5,
                                        type: "solid",
                                        label: {
                                            text: ""
                                        }
                                    },
                                    {
                                        value: 59.999,          // Y-axis value
                                        color: "#F92C2C",
                                        size: 1.5,
                                        type: "solid",
                                        label: {
                                            text: ""
                                        }
                                    }
                                ]
                            }
                        }

                    },
                    valueAxis: {
                        title: {
                            visible: false
                        }
                    },
                    legend: {
                        visible: false
                    },
                    categoryAxis: {
                        title: {
                            visible: false
                        }
                    }
                });

            }

            catch (err) {
                this.busy.close();
                MessageBox.error(err.message || this.oBundle.getText("fragment.chartsHome.MATGRP_CONTROLCHART_LOADING_ERROR"));
                this.oControlChartModel.setProperty("/controlChartMaterialGrpData", []);

            }
        },

        _onLoadControlChartMaterialNum: async function (sValue) {
            try {
                const oBindings = this.chartServiceModel.bindContext("/controlChart(...)");

                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const sMaterialNumber = this.oControlChartModel.getProperty("/selectedMaterialNum") || "";
                const sStartDate = this.oControlChartModel.getProperty("/materialNumStartDate") || "2024-01-01";
                const sEndDate = this.oControlChartModel.getProperty("/materialNumEndDate") || "2024-01-07";

                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error(this.oBundle.getText("START_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error(this.oBundle.getText("END_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                oBindings.setParameter("plant", sPlant);
                oBindings.setParameter("material", sMaterialNumber);
                oBindings.setParameter("startDate", sStartDate);
                oBindings.setParameter("endDate", sEndDate);

                this.busy.open();
                await oBindings.execute();
                const response = oBindings.getBoundContext().getObject();
                this.busy.close();
                this.oControlChartModel.setProperty("/controlChartMaterialNumData", response?.value || []);
                var oVizFrameMaterial = this.byId("idControlMaterialNumChartGraph");
                oVizFrameMaterial.setVizProperties({
                    title: {
                        visible: false,
                        text: "Average Under Line Corresponds to Grade"
                    },
                    plotArea: {
                        dataLabel: {
                            visible: true
                        },
                        colorPalette: ["#00DC66", "#F92C2C", "#F79220", "Black"],
                        dataPointStyle: {
                            rules: [
                                {
                                    dataContext: {
                                        "Max Value": "*"
                                    },
                                    properties: {
                                        lineType: "dash"
                                    }
                                },
                                {
                                    dataContext: {
                                        "Safety Stock": "*"
                                    },
                                    properties: {
                                        lineType: "dash"
                                    }
                                },
                                {
                                    dataContext: {
                                        "Buffer Stock": "*"
                                    },
                                    properties: {
                                        lineType: "dash"
                                    }
                                }
                            ]
                        }
                    },
                    valueAxis: {
                        title: {
                            visible: false
                        }
                    },
                    legend: {
                        visible: false
                    },
                    categoryAxis: {
                        title: {
                            visible: false
                        }
                    }
                });
            }
            catch (err) {
                this.busy.close();
                MessageBox.error(err.message || this.oBundle.getText("fragment.chartsHome.MATNUM_CONTROLCHART_LOADING_ERROR"));
                this.oControlChartModel.setProperty("/controlChartMaterialNumData", []);
            }
        },

        _onResetControlChartMaterialGrp: function () {
            const aPartGroups = this.oDashBoardModel.getProperty("/partGroups");
            this.oControlChartModel.setProperty("/selectedMaterialGroup", aPartGroups[0]?.partGroup || "");
            this.setStartAndEndDate("controlChartMaterialGrp");
            this._onLoadControlChartMaterialGrp();
        },

        _onResetControlChartMaterialNum: function () {

            const aMaterialList = this.oControlChartModel.getProperty("/materialList") || [];
            this.oControlChartModel.setProperty("/selectedMaterialNum", aMaterialList[0]?.material || "");

            this.setStartAndEndDate("controlChartMaterialNum");
            this._onLoadControlChartMaterialNum();
        },


        loadSummaryByMonthData: async function () {
            try {
                const oBindings = this.chartServiceModel.bindContext("/groupSummary(...)");

                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const sSelectedMaterialGroup = this.oControlChartModel.getProperty("/selectedMaterialGroupSummary") || "";
                const sStartDate = this.oControlChartModel.getProperty("/materialGroupSummaryStartDate") || "";
                const sEndDate = this.oControlChartModel.getProperty("/materialGroupSummaryEndDate") || "";


                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error(this.oBundle.getText("START_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error(this.oBundle.getText("END_DATE_FUTURE_ERROR"));
                        return;
                    }
                }


                oBindings.setParameter("plant", sPlant);
                oBindings.setParameter("partGroup", sSelectedMaterialGroup);
                oBindings.setParameter("startDate", sStartDate);
                oBindings.setParameter("endDate", sEndDate);
                this.busy.open();
                await oBindings.execute();
                const response = oBindings.getBoundContext().getObject();
                this.busy.close();
                this.oControlChartModel.setProperty("/summaryByMonthData", response?.value || []);
                this.createSummaryByMonthTable(response || []);
            }

            catch (err) {
                this.busy.close();
                // MessageBox.error(this.oBundle.getText("fragment.chartsHome.MATSUMMARY_LOADING_ERROR") + "\n\n" + (err.message || err));
                MessageBox.error(this.oBundle.getText(err.message || err));
                this.oControlChartModel.setProperty("/summaryByMonthData", []);
                throw err;
            }
        },


        createSummaryByMonthTable: function (data) {
            let oTable = this.byId("idSummaryByMonthTable");
            let oColumns = oTable.getColumns();

            for (let i = oColumns.length - 1; i >= 2; i--) {
                oTable.removeColumn(oColumns[i]);
            }
            let aRestructuredData = [];
            let aColumnList = [];

            data.value[0]?.avgTotalScores?.forEach((scoreItem) => {
                aColumnList.push(scoreItem.month);
            });


            data.value?.map((item) => {
                let newItem = item;
                let avgTotalScores = item.avgTotalScores || [];

                avgTotalScores.forEach((scoreItem) => {

                    newItem[scoreItem.month] = scoreItem.avgTotalScore;
                });

                delete newItem.avgTotalScores;
                aRestructuredData.push(newItem);
            });

            this.oControlChartModel.setProperty("/summaryByMonthData", aRestructuredData);
            oTable.setRowMode(
                new sap.ui.table.rowmodes.Fixed({
                    rowCount: aRestructuredData.length
                })
            );

            aColumnList.forEach((month) => {

                var oColumn = new sap.ui.table.Column({
                    minWidth: 120,
                    headerSpan: "1,1",
                    multiLabels: [
                        new Label({
                            text: month,
                            textAlign: "Center",
                            width: "100%"
                        }),
                        new Label({
                            text: "Average Total Score",
                            textAlign: "Center",
                            width: "100%",
                            wrapping: true
                        })
                    ],
                    template: new sap.m.HBox({
                        justifyContent: "Center",
                        items: [
                            new Text({
                                text: `{oControlChartModel>${month}}`
                            })
                        ]
                    })

                });

                oTable?.addColumn(oColumn);
            });

        },

        _onResetSummaryByMonth: function () {
            const aPartGroups = this.oDashBoardModel.getProperty("/partGroups");
            this.oControlChartModel.setProperty("/selectedMaterialGroupSummary", aPartGroups[0]?.partGroup || "");

            this.setStartAndEndDate("summaryByMonth");
            this.loadSummaryByMonthData();

        },

        _onPressDownloadSummaryByMonth: function () {

            let aData = this.oControlChartModel.getProperty("/summaryByMonthData") || [];

            let aColumns = [];
            Object.keys(aData[0]).map((key) => {
                let obj;
                if (key === "description" || key === "material") {
                    obj = {
                        label: key === "description" ? "Material Description" : "Material Number",
                        property: key,
                        type: "string"
                    };
                }
                else {
                    obj = {
                        label: key,
                        property: key,
                        type: "string"
                    };
                }

                aColumns.push(obj);
            });
            DownloadFile.DynamicExcelDownload(aColumns, aData, "Material Group Summary By Month");

        },
        onDownloadChartPDF: function (sId) {
            this.busy.open();
            sap.ui.getCore().applyChanges();
            var oPanel = this.byId(sId);
            /* eslint-disable @sap-ux/fiori-tools/sap-timeout-usage */
            setTimeout(() => {
                const html2canvas = window.html2canvas;
            var that = this;

            html2canvas(oPanel.getDomRef(), {
                scale: 2,
                useCORS: true,
                backgroundColor: "#ffffff"
            }).then(function (canvas) {

                var imgData = canvas.toDataURL("image/png");
                const { jsPDF: JsPDF } = window.jspdf;
                var pdf = new JsPDF("l", "mm", "a4");

                var pageWidth = pdf.internal.pageSize.getWidth();
                var pageHeight = pdf.internal.pageSize.getHeight();

                var margin = 5;

                var imgWidth = pageWidth - (margin * 2);
                var imgHeight = (canvas.height * imgWidth) / canvas.width;

                var heightLeft = imgHeight;
                var position = margin;

                pdf.addImage(
                    imgData,
                    "PNG",
                    margin,
                    position,
                    imgWidth,
                    imgHeight
                );

                heightLeft -= (pageHeight - (margin * 2));

                while (heightLeft > 0) {
                    position = heightLeft - imgHeight + margin;

                    pdf.addPage();

                    pdf.addImage(
                        imgData,
                        "PNG",
                        margin,
                        position,
                        imgWidth,
                        imgHeight
                    );

                    heightLeft -= (pageHeight - (margin * 2));
                }
                const pdfName = sId === "idPanelControlChartMaterialGrp" ? "ControlChart_MaterialGroup.pdf" : "ControlChart_MaterialNumber.pdf";
                pdf.save(pdfName);
                that.busy.close();
            });
            },50);
            /* eslint-enable @sap-ux/fiori-tools/sap-timeout-usage */
            
        },

        initHealthIndex: function () {
            this.oControlChartModel.setProperty("/sumOutOfStockTableData", []);
            this.oControlChartModel.setProperty("/sumOutOfStockStartDate", this.oControlChartModel.getProperty("/materialGroupSummaryStartDate") || "");
            this.oControlChartModel.setProperty("/sumOutOfStockEndDate", this.oControlChartModel.getProperty("/materialGroupSummaryEndDate") || "");
            this.oControlChartModel.setProperty("/sumOverStockStartDate", this.oControlChartModel.getProperty("/materialGroupSummaryStartDate") || "");
            this.oControlChartModel.setProperty("/sumOverStockEndDate", this.oControlChartModel.getProperty("/materialGroupSummaryEndDate") || "");
            this._onLoadSumOutOfStockData();
            this._onLoadSumOverStockData();
        },

        _onLoadSumOutOfStockData: async function () {
            try {
                const oBindings = this.chartServiceModel.bindContext("/sumOfEvents(...)");

                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const sStartDate = this.oControlChartModel.getProperty("/sumOutOfStockStartDate") || "";
                const sEndDate = this.oControlChartModel.getProperty("/sumOutOfStockEndDate") || "";

                if (!sStartDate || !sEndDate) {
                    MessageBox.error(this.oBundle.getText("MANDATORY_FIELDS_ERROR"));
                    return;
                }


                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error(this.oBundle.getText("START_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error(this.oBundle.getText("END_DATE_FUTURE_ERROR"));
                        return;
                    }
                }




                oBindings.setParameter("plant", sPlant);
                oBindings.setParameter("startDate", sStartDate);
                oBindings.setParameter("endDate", sEndDate);
                oBindings.setParameter("event", "outOfStock");
                this.busy.open();
                await oBindings.execute();
                const response = oBindings.getBoundContext().getObject();
                this.busy.close();
                this.oControlChartModel.setProperty("/sumOutOfStockTableData", response?.value || []);
                this.createSumOfStockTable(response || [], "idSumOutOfStockTable");
            }

            catch (err) {
                this.busy.close();
                MessageBox.error(err.message, this.oBundle.getText("fragment.chartsHome.SUM_OUT_OF_STOCK_LOADING_ERROR"));
                this.oControlChartModel.setProperty("/sumOutOfStockTableData", []);
                throw err;
            }
        },


        createSumOfStockTable: function (data, sId) {
            let oTable = this.byId(sId);
            let oColumns = oTable.getColumns();

            for (let i = oColumns.length - 1; i >= 1; i--) {
                oTable.removeColumn(oColumns[i]);
            }
            let aRestructuredData = [];
            let aColumnList = [];

            data.value[0]?.sumOfEventsItems?.forEach((item) => {
                aColumnList.push(item.month);
            });


            data.value?.map((item) => {
                let newItem = item;
                let sumOfEventsItems = item.sumOfEventsItems || [];

                sumOfEventsItems.forEach((scoreItem) => {

                    newItem[scoreItem.month] = scoreItem.count;
                });

                delete newItem.sumOfEventsItems;
                aRestructuredData.push(newItem);
            });
            if (sId === "idSumOutOfStockTable") {
                this.oControlChartModel.setProperty("/sumOutOfStockTableData", aRestructuredData);
            }
            else if (sId === "idSumOverStockTable") {
                this.oControlChartModel.setProperty("/sumOverStockTableData", aRestructuredData);
            }
            if (aRestructuredData.length > 0) {
                oTable.setRowMode(
                    new sap.ui.table.rowmodes.Fixed({
                        rowCount: aRestructuredData.length
                    })
                );
            }

            aColumnList.forEach((month, index) => {

                var oColumn = new sap.ui.table.Column({
                    minWidth: 120,
                    headerSpan: "1,1",
                    multiLabels: [
                        new Label({
                            text: month,
                            textAlign: "Center",
                            width: "100%"
                        }),
                        new Label({
                            text: sId === "idSumOutOfStockTable" ? "Sum Out of Stock" : "Sum Over Stock",
                            textAlign: "Center",
                            width: "100%",
                            wrapping: true
                        })
                    ],
                    template: new sap.m.HBox({
                        justifyContent: "Center",
                        items: [
                            new Link({
                                text: `{oControlChartModel>${month}}`,
                                press: (oEvent) => this.onSumOutOfStockLinkPress(oEvent, month, index, aColumnList.length, sId === "idSumOutOfStockTable" ? "outOfStock" : "overStock")
                            })
                        ]
                    })
                });

                oTable?.addColumn(oColumn);
            });

        },

        _onResetSumOutOfStockData: function () {
            this.setStartAndEndDate("sumOutOfStock");
            this._onLoadSumOutOfStockData();
        },
        _onResetSumOverStockData: function () {
            this.setStartAndEndDate("sumOverStock");
            this._onLoadSumOverStockData();
        },

        onSumOutOfStockLinkPress: async function (oEvent, sMonth, iColumnIndex, iTotalColumns, sSumofEvents) {
            let oCurrentObject = oEvent.getSource().getBindingContext("oControlChartModel").getObject();
            // let sMonth = oEvent.getSource().getParent().getMultiLabels()[0].getText();
            let sPartGroup = oCurrentObject.partGroup;
            // let iSumOutOfStock = oCurrentObject[sMonth];

            this.getSumOfStockMaterialData(sMonth, sPartGroup, iColumnIndex === 0, iColumnIndex === iTotalColumns - 1, sSumofEvents);


            if (!this.sumofStockFragment) {
                this.sumofStockFragment = await this.loadFragment({
                    name: "com.slb.chxkanban.fragments.chartsAndVisuals.sumOfStock"
                });
            }
            // this.sumofStockFragment.open();

        },

        _onPressCloseSumOfStockFragment: function () {
            if (this.sumofStockFragment) {
                this.sumofStockFragment.close();
            }
        },


        getSumOfStockMaterialData: async function (sMonth, sPartGroup, isFirstColumn, isLastColumn, sSumofEvents) {
            try {
                let selectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                // let oSelectedObj = this.oDashBoardModel.getProperty("/selectedObjForMovement");

                // const month = "2026-05";

                const [year, monthIndex] = sMonth.split("-").map(Number);
                let startDate, endDate;

                startDate = new Date(year, monthIndex - 1, 1);
                endDate = new Date(year, monthIndex, 0);// Format as YYYY-MM-DD
                if (isFirstColumn) {
                    startDate = this.oControlChartModel.getProperty("/sumOutOfStockStartDate");
                }

                if (isLastColumn) {
                    endDate = this.oControlChartModel.getProperty("/sumOutOfStockEndDate");
                }
                startDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(startDate));
                endDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(endDate));
                // startDate = startDate.toLocaleDateString("en-CA");
                // endDate = endDate.toLocaleDateString("en-CA");



                const oBinding = this.championXModel.bindList(
                    "/HealthIndex",
                    null, null, null,
                    {
                        $filter: `plant eq '${selectedPlant}' and partGroup eq '${sPartGroup}' and date ge '${startDate}' and date le '${endDate}' and ${sSumofEvents} eq 1`
                    }
                    // {
                    //     $filter: `plant eq '${selectedPlant}' and partGroup eq '${sPartGroup}' and month between '${startDate}' and '${endDate}'`,
                    // }
                );


                this.busy.open();
                const aContexts = await oBinding.requestContexts();
                const response = aContexts.map((ctx) => ctx.getObject());

                this.oControlChartModel.setProperty("/sumOfStockData", response || []);

                this.busy.close();
                if (!this.sumofStockFragment) {
                    this.sumofStockFragment = await this.loadFragment({
                        name: "com.slb.chxkanban.fragments.chartsAndVisuals.sumOfStock"
                    });
                }
                this.oControlChartModel.setProperty("/sumOfStockTitle", this.oBundle.getText("fragment.healthIndexFragment.SUM_OUT_OF_STOCK_TITLE"));
                this.sumofStockFragment.open();
                return response;

            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("SUM_OF_STOCK_LOADING_ERROR") + "\n" + (err?.message || err));
                this.oControlChartModel.setProperty("/sumOfStockData", []);
                throw err;
            }
        },

        _onExportSumOfStockData: function () {
            let aData = this.oControlChartModel.getProperty("/sumOfStockData") || [];




            const aColumnOrder = [
                "date",
                "material",
                "partGroup",
                "description"
            ];

            const mColumnLabel = {
                date: "Date",
                material: "Material No.",
                partGroup: "Material Group",
                description: "Material Description"
            };

            const aColumns = [];

            aColumnOrder.forEach(function (sKey) {
                if (aData[0].hasOwnProperty(sKey)) {
                    aColumns.push({
                        label: mColumnLabel[sKey],
                        property: sKey,
                        type: "string"
                    });
                }
            });



            // const mColumnLabel = {
            //     date: "Date",
            //     material: "Material No.",
            //     partGroup: "Material Group",
            //     description: "Material Description"
            // };

            // const aColumns = [];

            // Object.keys(aData[0]).forEach(function (sKey) {

            //     if (mColumnLabel[sKey]) {

            //         aColumns.push({
            //             label: mColumnLabel[sKey],
            //             property: sKey,
            //             type: "string"
            //         });

            //     }

            // });

            // let aColumns = [];
            // Object.keys(aData[0]).map((key) => {
            //     if (key === "date" || key === "material" || key === "partGroup" || key === "description") {
            //         let obj = {
            //             label: key,
            //             property: key,
            //             type: "string"
            //         };
            //         aColumns.push(obj);
            //     }
            // });
            DownloadFile.DynamicExcelDownload(aColumns, aData, this.oControlChartModel.getProperty("/sumOfStockTitle"));
        },
        // sum over stock section 

        _onLoadSumOverStockData: async function () {
            try {
                const oBindings = this.chartServiceModel.bindContext("/sumOfEvents(...)");

                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const sStartDate = this.oControlChartModel.getProperty("/sumOverStockStartDate") || "";
                const sEndDate = this.oControlChartModel.getProperty("/sumOverStockEndDate") || "";

                if (!sStartDate || !sEndDate) {
                    MessageBox.error(this.oBundle.getText("MANDATORY_FIELDS_ERROR"));
                    return;
                }

                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error(this.oBundle.getText("START_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error(this.oBundle.getText("END_DATE_FUTURE_ERROR"));
                        return;
                    }
                }

                oBindings.setParameter("plant", sPlant);
                oBindings.setParameter("startDate", sStartDate);
                oBindings.setParameter("endDate", sEndDate);
                oBindings.setParameter("event", "overStock");
                this.busy.open();
                await oBindings.execute();
                const response = oBindings.getBoundContext().getObject();
                this.busy.close();
                this.oControlChartModel.setProperty("/sumOverStockTableData", response?.value || []);
                this.createSumOfStockTable(response || [], "idSumOverStockTable");
            }

            catch (err) {
                this.busy.close();
                MessageBox.error(err.message, this.oBundle.getText("fragment.chartsHome.SUM_OVER_STOCK_LOADING_ERROR"));
                this.oControlChartModel.setProperty("/sumOverStockTableData", []);
                throw err;
            }
        },


        getCellHealthIndexData: async function (sStartDate, sEndDate, skip, top, sSumofEvents) {
            try {
                let selectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                const oBinding = this.championXModel.bindList(
                    "/HealthIndex",
                    null, null, null,
                    {
                        $filter: `plant eq '${selectedPlant}' and date ge '${sStartDate}' and date le '${sEndDate}' and ${sSumofEvents} eq 1`,
                        $select: "date,material,partGroup,description"
                    }
                );


                const aContexts = await oBinding.requestContexts(skip, top);
                const response = aContexts.map((ctx) => ctx.getObject());
                // oData = response || [];
                return response;

            }
            catch (err) {
                this.busy.close();
                MessageBox.error(this.oBundle.getText("SUM_OF_STOCK_LOADING_ERROR") + "\n" + (err?.message || err));
                throw err;
            }


        },

        _onExportSumofEvent: async function (sValue) {
            let oTableData = [];
            let sStartDate = "";
            let sEndDate = "";
            let allData = [];
            let skip = 0;
            let top = 1000;

            if (sValue === "sumOutOfStock") {
                oTableData = this.oControlChartModel.getProperty("/sumOutOfStockTableData") || [];
                sStartDate = this.oControlChartModel.getProperty("/sumOutOfStockStartDate") || "";
                sEndDate = this.oControlChartModel.getProperty("/sumOutOfStockEndDate") || "";
            } else if (sValue === "sumOverStock") {
                oTableData = this.oControlChartModel.getProperty("/sumOverStockTableData") || [];
                sStartDate = this.oControlChartModel.getProperty("/sumOverStockStartDate") || "";
                sEndDate = this.oControlChartModel.getProperty("/sumOverStockEndDate") || "";
            }

            this.busy.open();

            while (true) {
                let responseData = await this.getCellHealthIndexData(
                    sStartDate,
                    sEndDate,
                    skip,
                    top,
                    sValue === "sumOutOfStock" ? "outOfStock" : "overStock"
                );

                allData = allData.concat(responseData);

                if (responseData.length < top) {
                    const XLSX = window.XLSX;
                    let wb = XLSX.utils.book_new();
                    let ws1 = XLSX.utils.json_to_sheet(oTableData);

                    // Change only the Excel header
                    if (ws1.A1) {
                        ws1.A1.v = "Material-Group";
                    }

                    XLSX.utils.book_append_sheet(wb, ws1, "Sheet1");

                    const aExportData = allData.map(function (item) {
                        let oRow = Object.assign({}, item);

                        if (oRow.partGroup !== undefined) {
                            oRow["Material-Group"] = oRow.partGroup;
                            delete oRow.partGroup;
                        }

                        return oRow;
                    });

                    let ws2 = XLSX.utils.json_to_sheet(aExportData);
                    XLSX.utils.book_append_sheet(wb, ws2, "Sheet2");

                    //==========================
                    // Download
                    //==========================
                    XLSX.writeFile(wb, "Report.xlsx");

                    this.busy.close();
                    break;
                }

                skip += top;
            }
        },

        /* called to fetch the receiving inventory report data based on the search criteria entered by the user in the Receiving Inventory Report tab. 
            Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
            @param {Object} recevingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
            @returns {Promise} - A promise that resolves with the receiving inventory report data or rejects with an error.
        */

        _getRecevingInventoryRpt2(oPlantObj) {

            return new Promise(async (resolve, reject) => {
                const oCurrentPlant = this._fnPlantSelectionForInventory();
                const oModel = this.getModel("mainView");
                let supplyingPlant;
                let receivingPlant;
                if (oCurrentPlant.isReceiving) {
                    receivingPlant = oCurrentPlant.plant;
                    supplyingPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                }
                if (oCurrentPlant.isSupplying) {
                    supplyingPlant = oCurrentPlant.plant;
                    receivingPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                }
                const sMaterial = oPlantObj?.material || oModel.getProperty("/materialRecInvSrh") || "";
                const sPartGroup = oPlantObj?.partGroup || oModel.getProperty("/partGroupReceInvSearch") || "";
                const sSearch = oPlantObj?.search || oModel.getProperty("/searchReceInv") || "";
                const iSkip = oPlantObj?.skip || 0;
                try {
                    const oAction = this.getView().getModel("reportService").bindContext("/combinedInventoryReport(...)");
                    oAction.setParameter("supplyingPlant", supplyingPlant);
                    oAction.setParameter("receivingPlant", receivingPlant);
                    oAction.setParameter("material", sMaterial);
                    oAction.setParameter("partGroup", sPartGroup);
                    oAction.setParameter("search", sSearch);
                    oAction.setParameter("top", oPlantObj?.top || this._iTopReceInventory);
                    oAction.setParameter("skip", iSkip);
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();
                    //const iCount = aData["@odata.count"] || 0;

                    resolve(aData);
                } catch (error) {
                    this.busy.close();
                    reject(error);

                }
            });

        },
        /* eslint-disable complexity */
        /* eslint-disable max-statements */

        _getRecevingInventoryRpt: async function (oPlantObj, iTop) {
            const oCurrentPlant = this._fnPlantSelectionForInventory();
            const oModel = this.getModel("mainView");
            let supplyingPlant;
            let receivingPlant;
            if (oCurrentPlant.isReceiving) {
                receivingPlant = oCurrentPlant.plant;
                supplyingPlant = this.oDashBoardModel.getProperty("/selectedPlant");

            }
            if (oCurrentPlant.isSupplying) {
                supplyingPlant = oCurrentPlant.plant;
                receivingPlant = this.oDashBoardModel.getProperty("/selectedPlant");
            }
            const sMaterial = oPlantObj?.material || oModel.getProperty("/materialRecInvSrh") || "";
            const sPartGroup = oPlantObj?.partGroup || oModel.getProperty("/partGroupReceInvSearch") || "";
            const sSearch = oPlantObj?.search || oModel.getProperty("/searchReceInv") || "";
            let iSkip = oPlantObj?.skip || 0;

            try {
                const aFilters = [];

                if (supplyingPlant !== "") {
                    aFilters.push(new Filter("supplyingPlant", FilterOperator.EQ, supplyingPlant));
                }

                if (receivingPlant !== "") {
                    aFilters.push(new Filter("receivingPlant", FilterOperator.EQ, receivingPlant));
                }

                if (sMaterial !== "") {
                    aFilters.push(new Filter("material", FilterOperator.EQ, sMaterial));
                }

                if (sPartGroup !== "") {
                    aFilters.push(new Filter("partGroup", FilterOperator.EQ, sPartGroup));
                }

                if (sSearch !== "") {
                    aFilters.push(
                        new Filter({
                            filters: [
                                new Filter("material", FilterOperator.Contains, sSearch),
                                new Filter("description", FilterOperator.Contains, sSearch),
                                new Filter("partGroup", FilterOperator.Contains, sSearch)
                            ],
                            and: false // OR
                        })
                    );
                }

                const advancedFilters = this.getModel("mainView").getProperty("/receivingPlantInventoryAdvancedFilters") || [];
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {
                        if (filter.operator === "BT") {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1, filter.value2));
                        }
                        else {
                            let columnName = filter.column;
                            if (filter.column === "supplyingPlant_min") {
                                columnName = "supplyingPlantMin";
                            }
                            else if (filter.column === "supplyingPlant_max") {
                                columnName = "supplyingPlantMax";
                            }
                            else if (filter.column === "supplyingPlant_qoh") {
                                columnName = "supplyingPlantQoh";
                            }
                            else if (filter.column === "supplyingPlant_wip") {
                                columnName = "supplyingPlantWip";
                            }
                            else if (filter.column === "receivingPlant_min") {
                                columnName = "receivingPlantMin";
                            }
                            else if (filter.column === "receivingPlant_max") {
                                columnName = "receivingPlantMax";
                            }
                            else if (filter.column === "receivingPlant_qoh") {
                                columnName = "receivingPlantQoh";
                            }
                            else if (filter.column === "combinedSummary_min") {
                                columnName = "combinedMin";
                            }
                            else if (filter.column === "combinedSummary_max") {
                                columnName = "combinedMax";
                            }
                            else if (filter.column === "combinedSummary_qoh") {
                                columnName = "combinedQoh";
                            }
                            else if (filter.column === "combinedSummary_wip") {
                                columnName = "supplyingPlantWip";
                            }
                            aFilters.push(new Filter(columnName, filter.operator, filter.value1));
                        }
                    });

                }

                // sorting logic
                let aSorters = [];

                if (this._sortReceInventoryProperty) {
                    aSorters.push(
                        new sap.ui.model.Sorter(
                            this._sortReceInventoryProperty,
                            this._receInventoryOrderSorting || false
                        )
                    );
                } else {
                    aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13ReceInventory") || null;
                }


                this.reportService = this.getOwnerComponent().getModel("reportService");
                const oBinding = this.reportService.bindList(
                    "/CombinedInventoryReport",
                    null,
                    aSorters,
                    aFilters,
                    {
                        $count: true
                    }
                );

                let receInventoryTop;
                let receInventorySkip;

                if (iTop) {
                    receInventoryTop = iTop;
                    receInventorySkip = 0;

                } else {
                    receInventoryTop = this.getView().getModel("mainView").getProperty("/objPagination/receCombinedInventoryPageSize") || 10;
                    receInventorySkip = iSkip;

                }

                //const pageSize = this.getView().getModel("mainView").getProperty("/objPagination/receCombinedInventoryPageSize") || 10;
                const aContexts = await oBinding.requestContexts(receInventorySkip, receInventoryTop);
                const response = aContexts.map((ctx) => ctx.getObject());
                const iCount = oBinding.getLength();
                let value = [];

                response.map((item) => {
                    let obj = {
                        "material": item.material,
                        "description": item.description,
                        "partGroup": item.partGroup,
                        "inTransit": item.inTransit,
                        "receivingPlant": {
                            "plant": item?.receivingPlant,
                            "plantName": item?.receivingPlantName,
                            "min": item?.receivingPlantMin,
                            "max": item?.receivingPlantMax,
                            "qoh": item?.receivingPlantQoh
                        },
                        "supplyingPlant": {
                            "plant": item?.supplyingPlant,
                            "plantName": item?.supplyingPlantName,
                            "min": item?.supplyingPlantMin,
                            "max": item?.supplyingPlantMax,
                            "qoh": item?.supplyingPlantQoh,
                            "wip": item?.supplyingPlantWip
                        },
                        "combinedSummary": {
                            "plantName": item?.supplyingPlantName + " + " + item?.receivingPlantName,
                            "min": item?.combinedMin,
                            "max": item?.combinedMax,
                            "qoh": item?.combinedQoh,
                            "wip": item?.supplyingPlantWip
                        }
                    };
                    value.push(obj);
                });


                var oData =
                {
                    "@odata.count": iCount,
                    "value": value
                };
                return oData;
            }
            catch (error) {
                this.busy.close();
                throw error;
            }

        },
        /* eslint-enable complexity */
        /* eslint-enable max-statements */

        /* called to fetch the supplying inventory report data based on the search criteria entered by the user in the BA Kanban Inventory Report tab.
            Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
            @param {Object} supplyingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
            @returns {Promise} - A promise that resolves with the supplying inventory report data or rejects with an error.
        */

        _getSuppInventoryApiCall2(supplyingPlantObj) {


            return new Promise(async (resolve, reject) => {
                const oCurrentPlant = this._fnPlantSelectionForInventory();
                const oModel = this.getModel("mainView");
                let supplyingPlant;
                let receivingPlant;
                if (oCurrentPlant.isReceiving) {
                    receivingPlant = oCurrentPlant.plant;
                    supplyingPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                }
                if (oCurrentPlant.isSupplying) {
                    supplyingPlant = oCurrentPlant.plant;
                    receivingPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                }
                const sMaterial = supplyingPlantObj?.material || oModel.getProperty("/materialSuppInvSrh") || "";
                const sPartGroup = supplyingPlantObj?.partGroup || oModel.getProperty("/partGroupSuppInvSearch") || "";
                const sSearch = supplyingPlantObj?.search || oModel.getProperty("/searchSuppInv") || "";
                const iSkip = supplyingPlantObj?.skip || 0;
                try {
                    const oAction = this.getView().getModel("reportService").bindContext("/combinedInventoryReport(...)");
                    oAction.setParameter("supplyingPlant", supplyingPlant);
                    oAction.setParameter("receivingPlant", receivingPlant);
                    oAction.setParameter("material", sMaterial);
                    oAction.setParameter("partGroup", sPartGroup);
                    oAction.setParameter("search", sSearch);
                    oAction.setParameter("top", supplyingPlantObj?.top || this._iTopSuppInventory);
                    oAction.setParameter("skip", iSkip);
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();

                    resolve(aData);
                } catch (error) {
                    this.busy.close();
                    reject(error);

                }
            });

        },

        /* eslint-disable complexity */
        /* eslint-disable max-statements */
        _getSuppInventoryApiCall: async function (supplyingPlantObj, iTop) {
            const oCurrentPlant = this._fnPlantSelectionForInventory();
            const oModel = this.getModel("mainView");
            let supplyingPlant;
            let receivingPlant;
            if (oCurrentPlant.isReceiving) {
                receivingPlant = oCurrentPlant.plant;
                supplyingPlant = this.oDashBoardModel.getProperty("/selectedPlant");

            }
            if (oCurrentPlant.isSupplying) {
                supplyingPlant = oCurrentPlant.plant;
                receivingPlant = this.oDashBoardModel.getProperty("/selectedPlant");
            }
            const sMaterial = supplyingPlantObj?.material || oModel.getProperty("/materialSuppInvSrh") || "";
            const sPartGroup = supplyingPlantObj?.partGroup || oModel.getProperty("/partGroupSuppInvSearch") || "";
            const sSearch = supplyingPlantObj?.search || oModel.getProperty("/searchSuppInv") || "";
            let iSkip = supplyingPlantObj?.skip || 0;


            try {
                const aFilters = [];

                if (supplyingPlant !== "") {
                    aFilters.push(new Filter("supplyingPlant", FilterOperator.EQ, supplyingPlant));
                }

                if (receivingPlant !== "") {
                    aFilters.push(new Filter("receivingPlant", FilterOperator.EQ, receivingPlant));
                }

                if (sMaterial !== "") {
                    aFilters.push(new Filter("material", FilterOperator.EQ, sMaterial));
                }

                if (sPartGroup !== "") {
                    aFilters.push(new Filter("partGroup", FilterOperator.EQ, sPartGroup));
                }

                if (sSearch !== "") {
                    aFilters.push(
                        new Filter({
                            filters: [
                                new Filter("material", FilterOperator.Contains, sSearch),
                                new Filter("description", FilterOperator.Contains, sSearch),
                                new Filter("partGroup", FilterOperator.Contains, sSearch)
                            ],
                            and: false // OR
                        })
                    );
                }

                const advancedFilters = this.getModel("mainView").getProperty("/supplyingPlantInventoryAdvancedFilters") || [];
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {
                        if (filter.operator === "BT") {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1, filter.value2));
                        }
                        else {
                            let columnName = filter.column;
                            if (filter.column === "supplyingPlant_min") {
                                columnName = "supplyingPlantMin";
                            }
                            else if (filter.column === "supplyingPlant_max") {
                                columnName = "supplyingPlantMax";
                            }
                            else if (filter.column === "supplyingPlant_qoh") {
                                columnName = "supplyingPlantQoh";
                            }
                            else if (filter.column === "supplyingPlant_wip") {
                                columnName = "supplyingPlantWip";
                            }
                            else if (filter.column === "receivingPlant_min") {
                                columnName = "receivingPlantMin";
                            }
                            else if (filter.column === "receivingPlant_max") {
                                columnName = "receivingPlantMax";
                            }
                            else if (filter.column === "receivingPlant_qoh") {
                                columnName = "receivingPlantQoh";
                            }
                            else if (filter.column === "combinedSummary_min") {
                                columnName = "combinedMin";
                            }
                            else if (filter.column === "combinedSummary_max") {
                                columnName = "combinedMax";
                            }
                            else if (filter.column === "combinedSummary_qoh") {
                                columnName = "combinedQoh";
                            }
                            else if (filter.column === "combinedSummary_wip") {
                                columnName = "supplyingPlantWip";
                            }
                            aFilters.push(new Filter(columnName, filter.operator, filter.value1));
                        }
                    });

                }


                // sorting logic
                let aSorters = [];

                if (this._sortSuppInventoryProperty) {
                    aSorters.push(
                        new sap.ui.model.Sorter(
                            this._sortSuppInventoryProperty,
                            this._suppInventoryOrderSorting || false
                        )
                    );
                } else {
                    aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13SuppInventory");
                }


                this.reportService = this.getOwnerComponent().getModel("reportService");
                const oBinding = this.reportService.bindList(
                    "/CombinedInventoryReport",
                    null,
                    aSorters,
                    aFilters,
                    {
                        $count: true
                    }
                );

                let suppInventoryTop;
                let suppInventorySkip;

                if (iTop) {
                    suppInventoryTop = iTop;
                    suppInventorySkip = 0;
                } else {

                    suppInventoryTop = this.getView().getModel("mainView").getProperty("/objPagination/suppCombinedInventoryPageSize") || 10;
                    suppInventorySkip = iSkip;

                }



                //const pageSize = this.getView().getModel("mainView").getProperty("/objPagination/suppCombinedInventoryPageSize") || 10;
                const aContexts = await oBinding.requestContexts(suppInventorySkip, suppInventoryTop);
                const response = aContexts.map((ctx) => ctx.getObject());
                const iCount = oBinding.getLength();
                let value = [];

                response.map((item) => {
                    let obj = {
                        "material": item.material,
                        "description": item.description,
                        "partGroup": item.partGroup,
                        "inTransit": item.inTransit,
                        "receivingPlant": {
                            "plant": item?.receivingPlant,
                            "plantName": item?.receivingPlantName,
                            "min": item?.receivingPlantMin,
                            "max": item?.receivingPlantMax,
                            "qoh": item?.receivingPlantQoh
                        },
                        "supplyingPlant": {
                            "plant": item?.supplyingPlant,
                            "plantName": item?.supplyingPlantName,
                            "min": item?.supplyingPlantMin,
                            "max": item?.supplyingPlantMax,
                            "qoh": item?.supplyingPlantQoh,
                            "wip": item?.supplyingPlantWip
                        },
                        "combinedSummary": {
                            "plantName": item?.supplyingPlantName + " + " + item?.receivingPlantName,
                            "min": item?.combinedMin,
                            "max": item?.combinedMax,
                            "qoh": item?.combinedQoh,
                            "wip": item?.supplyingPlantWip
                        }
                    };
                    value.push(obj);
                });


                var oData =
                {
                    "@odata.count": iCount,
                    "value": value
                };
                return oData;
            }
            catch (error) {
                this.busy.close();
                throw error;
            }
        },
        /* eslint-enable complexity */
        /* eslint-enable max-statements */

        _fnPlantSelectionForInventory() {
            const sPlant = this.getModel("mainView").getProperty("/selectedReceInventoryPlant");
            const aPlants = this.getModel("mainView").getProperty("/plantsDetails") || [];
            const oCurrentPlant = aPlants.find(plant => plant.plant === sPlant);
            return oCurrentPlant;

        },

        /* called to fetch the supplying plant data based on the search criteria entered by the user in the BA Kanban Report tab.
            Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
            @param {Object} supplyingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
            @returns {Promise} - A promise that resolves with the supplying plant data or rejects with an error.
        */

        _getSupplyingPlantData2(supplyingPlantObj) {
            const sMaterial = supplyingPlantObj?.material || this.getModel("mainView").getProperty("/supplyingMaterial") || "";
            const sPartGroup = supplyingPlantObj?.partGroup || this.getModel("mainView").getProperty("/supplyingPartGroup") || "";
            const sSearch = supplyingPlantObj?.search || this.getModel("mainView").getProperty("/searchSupplyingReports") || "";
            const iSkip = supplyingPlantObj?.skip || 0;

            return new Promise(async (resolve, reject) => {
                try {
                    const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    const oAction = this.getView().getModel("reportService").bindContext("/demandReport(...)");
                    oAction.setParameter("plant", sPlant);
                    oAction.setParameter("material", sMaterial);
                    oAction.setParameter("partGroup", sPartGroup);
                    oAction.setParameter("search", sSearch);
                    oAction.setParameter("top", this._iTopSuppReport);
                    oAction.setParameter("skip", iSkip);
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData);
                } catch (error) {
                    reject(error);
                    this.busy.close();

                }
            });

        },
        /* eslint-disable complexity */
        _getSupplyingPlantData: async function (supplyingPlantObj, iTop) {
            const sMaterial = supplyingPlantObj?.material || this.getModel("mainView").getProperty("/supplyingMaterial") || "";
            const sPartGroup = supplyingPlantObj?.partGroup || this.getModel("mainView").getProperty("/supplyingPartGroup") || "";
            const sSearch = supplyingPlantObj?.search || this.getModel("mainView").getProperty("/searchSupplyingReports") || "";
            let iSkip = supplyingPlantObj?.skip || 0;

            try {

                const aFilters = [];

                let isReceivingPlant = this.oDashBoardModel.getProperty("/isReceivingPlant");
                let sSelectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");

                if (isReceivingPlant) {
                    aFilters.push(new Filter("receivingPlant", FilterOperator.EQ, sSelectedPlant));
                }
                else {
                    aFilters.push(new Filter("supplyingPlant", FilterOperator.EQ, sSelectedPlant));
                }

                if (sMaterial !== "") {
                    aFilters.push(new Filter("material", FilterOperator.EQ, sMaterial));
                }

                if (sPartGroup !== "") {
                    aFilters.push(new Filter("partGroup", FilterOperator.EQ, sPartGroup));
                }

                if (sSearch !== "") {
                    aFilters.push(
                        new Filter({
                            filters: [
                                new Filter("material", FilterOperator.Contains, sSearch),
                                new Filter("description", FilterOperator.Contains, sSearch),
                                new Filter("partGroup", FilterOperator.Contains, sSearch)
                            ],
                            and: false // OR
                        })
                    );
                }

                const advancedFilters = this.getModel("mainView").getProperty("/supplyingPlantAdvancedFilters") || [];
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {
                        if (filter.operator === "BT") {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1, filter.value2));
                        }
                        else {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1));
                        }
                    });

                }

                // sorting logic for table columns in the BA Kanban Report tab. The sorting is based on the property and order specified by the user.
                let aSorters = [];

                if (this._sortPropertySupp) {
                    aSorters.push(
                        new sap.ui.model.Sorter(
                            this._sortPropertySupp,
                            this._suppOrderSorting || false
                        )
                    );
                } else {

                    aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13Supp");

                }



                this.reportService = this.getOwnerComponent().getModel("reportService");
                const oBinding = this.reportService.bindList(
                    "/DemandReport",
                    null,
                    aSorters,
                    aFilters,
                    {
                        $count: true
                    }
                );

                let pageSize;

                if (iTop) {
                    pageSize = iTop;
                    iSkip = 0;

                } else {
                    pageSize = this.getView().getModel("mainView").getProperty("/objPagination/suppReportPageSize") || 10;


                }


                const aContexts = await oBinding.requestContexts(iSkip, pageSize);
                const response = aContexts.map((ctx) => ctx.getObject());
                const iCount = oBinding.getLength();
                var obj =
                {
                    demandReportItems: response,
                    "@odata.count": iCount,
                    "ReceivingPlantName": response[0]?.receivingPlantName || ""
                };
                return obj;
            }

            catch (error) {
                throw error;
            }

        },

        getDemandReportData: async function (supplyingPlantObj) {
            const sMaterial = supplyingPlantObj?.material || this.getModel("mainView").getProperty("/supplyingMaterial") || "";
            const sPartGroup = supplyingPlantObj?.partGroup || this.getModel("mainView").getProperty("/supplyingPartGroup") || "";
            const sSearch = supplyingPlantObj?.search || this.getModel("mainView").getProperty("/searchSupplyingReports") || "";
            const iSkip = supplyingPlantObj?.skip || 0;

            try {

                const aFilters = [];

                if (sMaterial !== "") {
                    aFilters.push(new Filter("material", FilterOperator.EQ, sMaterial));
                }

                if (sPartGroup !== "") {
                    aFilters.push(new Filter("partGroup", FilterOperator.EQ, sPartGroup));
                }

                if (sSearch !== "") {
                    aFilters.push(new Filter("search", FilterOperator.Contains, sSearch));
                }

                const advancedFilters = this.getModel("mainView").getProperty("/supplyingPlantAdvancedFilters") || [];
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {
                        if (filter.operator === "BT") {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1, filter.value2));
                        }
                        else {
                            aFilters.push(new Filter(filter.column, filter.operator, filter.value1));
                        }
                    });
                }


                this.reportService = this.getOwnerComponent().getModel("reportService");
                const oBinding = this.reportService.bindList(
                    "/DemandReport",
                    null, null, aFilters,
                    {
                        $count: true
                    }
                );

                const pageSize = this.getView().getModel("mainView").getProperty("/objPagination/suppReportPageSize") || 10;
                const aContexts = await oBinding.requestContexts(iSkip, pageSize);
                const response = aContexts.map((ctx) => ctx.getObject());
                const iCount = oBinding.getLength();
                var obj =
                {
                    demandReportItems: response,
                    "@odata.count": iCount,
                    "ReceivingPlantName": response[0]?.receivingPlantName || ""
                };
                return obj;
            }

            catch (error) {
                throw error;
            }
        },
        /* eslint-enable complexity */


        /* called to fetch the receiving plant comparison data based on the search criteria entered by the user in the Odessa vs BA Comparison Report tab.  
            Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
            @param {Object} recevingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
            @returns {Promise} - A promise that resolves with the receiving plant comparison data or rejects with an error.
        */
        /* eslint-disable complexity */
        _getRecevingPlantComparison(oPlantObj, iTop) {


            // eslint-disable-next-line max-statements
            return new Promise(async (resolve, reject) => {
                const oModel = this.getModel("mainView");
                const sMaterial = oPlantObj?.material || oModel.getProperty("/materialCompSearch") || "";
                const sPartGroup = oPlantObj?.partGroup || oModel.getProperty("/partGroupCompSearch") || "";
                const sSearch = oPlantObj?.search || oModel.getProperty("/compSearchValue") || "";
                let selectedPlants;
                let sPlant;
                const aPlants = this.getModel("mainView").getProperty("/selectedReceComparisonPlant");
                if (aPlants && aPlants.length === 1) {
                    sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    selectedPlants = [sPlant, ...aPlants].join(",");
                } else if (aPlants && aPlants.length > 1) {
                    selectedPlants = aPlants.join(",");
                } else {
                    sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    selectedPlants = sPlant;
                }
                let aFilters = [];
                let aQOH = {};
                if (sSearch !== "") {
                    aFilters.push(`(contains (material,'${sSearch}') or contains (description,'${sSearch}') or contains (partGroup,'${sSearch}'))`);
                }

                if (sMaterial !== "") {
                    aFilters.push(`material eq '${sMaterial}'`);
                }

                if (sPartGroup !== "") {
                    aFilters.push(`partGroup eq '${sPartGroup}'`);
                }

                let advancedFilters = this.getModel("mainView").getProperty("/receivingComparisonAdvancedFilters");
                if (advancedFilters && advancedFilters.length !== 0) {
                    advancedFilters.forEach((filter) => {

                        if (filter.column === "material" || filter.column === "MaterialGroup" || filter.column === "description") {
                            let columnName = {
                                "material": "material",
                                "MaterialGroup": "partGroup",
                                "description": "description"
                            };
                            if (filter.operator === "EQ" || filter.operator === "NE") {
                                aFilters.push(`${columnName[filter.column]} ${(filter.operator).toLowerCase()} '${filter.value1}'`);
                            }
                            else {
                                aFilters.push(`${filter.operator}(${columnName[filter.column]},'${filter.value1}')`);
                            }
                        }

                        else if (filter.column.includes("_")) {
                            if (filter.operator === "BT") {
                                aQOH[filter.sPlantId] = `qoh gt ${Number(filter.value1)} and qoh lt ${Number(filter.value2)}`;
                            }
                            else {
                                aQOH[filter.sPlantId] = `qoh ${(filter.operator).toLowerCase()} ${Number(filter.value1)}`;
                            }
                        }
                    });

                }
                let filter = aFilters.join(" and ");

                let Top;
                let skip;

                if (iTop) {
                    Top = iTop;
                    skip = 0;

                } else {
                    Top = this._iTopRecComp;
                    skip = oPlantObj?.skip || 0;

                }

                // sorting logic
                
                let sSortProperty;

                if (this._sortReceComparisonProperty) {

                    const sPlantName = this._sortReceComparisonProperty.replace(/_QOH$/, "");

                    const oPlant = this.oDashBoardModel.getProperty("/plants").find((p) => {
                        return p.plantName === sPlantName;
                    });

                    if (oPlant) {
                        if (this._receComparisonOrderSorting) {
                            sSortProperty = `${oPlant.plant}_QOH desc`;
                        } else {
                            sSortProperty = `${oPlant.plant}_QOH asc`;
                        }

                    }
                }

                try {
                    const oAction = this.getView().getModel("reportService").bindContext("/comparisonReport(...)");
                    oAction.setParameter("plants", selectedPlants);
                    oAction.setParameter("top", Top);
                    oAction.setParameter("skip", skip);
                    oAction.setParameter("filter", filter);
                    oAction.setParameter("sort", sSortProperty || "");
                    if (aQOH && Object.keys(aQOH).length > 0) {
                        oAction.setParameter("qohFilter", JSON.stringify(aQOH));
                    }
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData);
                } catch (error) {
                    this.busy.close();
                    reject(error);

                }
            });

        },
        /* eslint-enable complexity */

        /* called to fetch the supplying plant comparison data based on the search criteria entered by the user in the BA Kanban vs Odessa Comparison Report tab.
            Makes a call to the backend with the search criteria and returns the data to be displayed in the table.
            @param {Object} supplyingPlantObj - The search criteria object containing plant, material, partGroup, search text, top, and skip values.
            @returns {Promise} - A promise that resolves with the supplying plant comparison data or rejects with an error.
        */
        /* eslint-disable complexity */
        _getSupplyingPlantComparison(supplyingPlantObj, iTop) {

            // eslint-disable-next-line max-statements
            return new Promise(async (resolve, reject) => {
                const oModel = this.getModel("mainView");
                const sMaterial = supplyingPlantObj?.material || oModel.getProperty("/materialSuppSearch") || "";
                const sPartGroup = supplyingPlantObj?.partGroup || oModel.getProperty("/partGroupSuppSearch") || "";
                const sSearch = supplyingPlantObj?.search || oModel.getProperty("/suppSearch") || "";
                let selectedPlants;
                let sPlant;
                const aPlants = this.getModel("mainView").getProperty("/selectedSuppComparisonPlant");
                if (aPlants && aPlants.length === 1) {
                    sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    selectedPlants = [sPlant, ...aPlants].join(",");
                } else if (aPlants && aPlants.length > 1) {
                    selectedPlants = aPlants.join(",");
                } else {
                    sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    selectedPlants = sPlant;
                }

                let aFilters = [];
                let aQOH = {};
                if (sMaterial !== "") {
                    aFilters.push(`material eq '${sMaterial}'`);
                }
                if (sPartGroup !== "") {
                    aFilters.push(`partGroup eq '${sPartGroup}'`);
                }
                if (sSearch !== "") {
                    aFilters.push(`(contains (material,'${sSearch}') or contains (description,'${sSearch}') or contains (partGroup,'${sSearch}'))`);
                }

                let advancedFilters = this.getModel("mainView").getProperty("/supplyingPlantComparisonAdvancedFilters") || [];
                advancedFilters.map((item) => {
                    if (item.column === "material" || item.column === "MaterialGroup" || item.column === "description") {
                        let columnName = {
                            "material": "material",
                            "MaterialGroup": "partGroup",
                            "description": "description"
                        };
                        if (item.operator === "EQ" || item.operator === "NE") {
                            aFilters.push(`${columnName[item.column]} ${(item.operator).toLowerCase()} '${item.value1}'`);
                        }
                        else {
                            aFilters.push(`${item.operator}(${columnName[item.column]},'${item.value1}')`);
                        }
                    }

                    else if (item.column.includes("_")) {
                        if (item.operator === "BT") {
                            // aQOH.push(new Filter(item.sPlantId, item.operator, item.value1, item.value2));
                            aQOH[item.sPlantId] = `qoh gt ${Number(item.value1)} and qoh lt ${Number(item.value2)}`;
                        }
                        else {
                            aQOH[item.sPlantId] = `qoh ${(item.operator).toLowerCase()} '${item.value1}'`;
                        }
                    }

                });
                let filter = aFilters.join(" and ");

                let suppComparisonTop;
                let suppComparisonSkip;

                if (iTop) {
                    suppComparisonTop = iTop;
                    suppComparisonSkip = 0;

                } else {
                    suppComparisonTop = this._iTopSuppComp;
                    suppComparisonSkip = supplyingPlantObj?.skip || 0;

                }
                try {

                    const oAction = this.getView().getModel("reportService").bindContext("/comparisonReport(...)");
                    oAction.setParameter("plants", selectedPlants);
                    // oAction.setParameter("material", sMaterial);
                    // oAction.setParameter("partGroup", sPartGroup);
                    // oAction.setParameter("search", sSearch);
                    oAction.setParameter("top", suppComparisonTop);
                    oAction.setParameter("skip", suppComparisonSkip);
                    oAction.setParameter("filter", filter);
                    if (aQOH && Object.keys(aQOH).length > 0) {
                        oAction.setParameter("qohFilter", JSON.stringify(aQOH));
                    }
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData);
                } catch (error) {
                    this.busy.close();
                    reject(error);

                }
            });

        },
        /* eslint-enable complexity */
        onReceComparisonPlantSelectionFinish() {
            this._getRecevingPlantComparison().then((oData) => {
                this._fnDynamicTableForComparison(oData);
            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        onSuppComparisonPlantSelectionFinish() {
            this._getSupplyingPlantComparison().then((oData) => {
                this._fnDynamicTableForSupplyingComparison(oData);
            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        /* Sets up table personalization for all tables in the app. Currently includes column selection, sorting, and filtering. Can be extended to include more features like grouping, etc.
            @param {}
            @private
            @memberof com.slb.chxkanban.controller.Main
        */

        _setTablePersonalization() {
            this._receivingOrderReportTableCells();
            this._supplyingReportTableCells();

        },

        /* Personalization for all tables in the app. Currently includes column selection, sorting, and filtering. Can be extended to include more features like grouping, etc.
         @param {object} selectedObject - The selected plant object from the plant dropdown, used to determine which tables to personalize based on the plant type (supplying, receiving, or both).
         @private
         @memberof com.slb.chxkanban.controller.Main
        */

        _fnReportDataBinding() {
            // cleared advanced search fields when plant is changed.
            this._clearAdvancedFilter();
            const sPlantType = this.oDashBoardModel.getProperty("/selectedPlant");
            const aPlants = this.oDashBoardModel.getProperty("/plants") || [];
            const oCurrentPlant = aPlants.find(plant => plant.plant === sPlantType);
            if (!oCurrentPlant) {
                return;
            }
            if (oCurrentPlant.isReceiving) {
                const oTable = this.byId("idReceivingOrderReportTable");
                this.setFooterForSum(oTable);
                const oTableCompression = this.byId("idReceivingOrderReportTable");
                this.setFooterForSum(oTableCompression);
                //API calls for receiving plant report and comparison report.

                Promise.all([
                    this._getReceivingPlant(),
                    this._getRecevingPlantComparison(),
                    this._getRecevingInventoryRpt()
                ]).then(([oReceivingData, oComparisonData, oInventoryData]) => {
                    this._recevingTableBinding(oReceivingData);
                    this._fnDynamicTableForComparison(oComparisonData);
                    this._fnRecevingInventoryTableBinding(oInventoryData);
                }).catch((err) => {
                    this.showErrorMessage(err.message);

                });

            }
            //API calls for supplying plant report and comparison report.
            if (!oCurrentPlant.isReceiving && oCurrentPlant.isSupplying) {
                const oTable = this.byId("idSupplyingReportTable");
                this.setFooterForSum(oTable);

                Promise.all([
                    this._getSupplyingPlantData(),
                    this._getSupplyingPlantComparison(),
                    this._getSuppInventoryApiCall()

                ]).then(([oSupplyingData, oSupplyingComparisonData, oSupplyingInventoryData]) => {
                    this._supplyingTableBinding(oSupplyingData);
                    this._fnDynamicTableForSupplyingComparison(oSupplyingComparisonData);
                    this._fnSupplyingInventoryTableBinding(oSupplyingInventoryData);
                }).catch((err) => {
                    this.showErrorMessage(err.message);

                });

            }

        },


        /* Updates the pagination UI based on the data received from the backend. Sets the loaded count, 
            total count, and whether there are more records to load for both receiving and supplying reports.
           @param {object} data - The data received from the backend, containing the orderReportItems or demandReportItems and the total count.
           @param {boolean} plantType - A boolean indicating whether the plant is a receiving plant (true) or a supplying plant (false).
           @private
        */
        _updatePaginationUI(data, plantType) {

            const iTotalCount = data?.orderReportItems?.length || data?.demandReportItems?.length;
            const iDataCount = Number(data?.["@odata.count"] || 0);
            const oModel = this.getModel("mainView");
            if (plantType) {
                this._reportPagination(data, plantType, "idRecePaginationHBox");
                oModel.setProperty("/loadedCount", iTotalCount);
                oModel.setProperty("/totalCount", iDataCount);
                if (iDataCount === iTotalCount) {
                    oModel.setProperty("/hasMoreReceiving", false);
                } else {
                    oModel.setProperty("/hasMoreReceiving", true);
                }
            } else {
                oModel.setProperty("/loadedCountSuppRep", iTotalCount);
                oModel.setProperty("/totalCountSuppRepo", iDataCount);
                this._reportPagination(data, plantType, "idSuppPaginationHBox");
                if (iDataCount === iTotalCount) {
                    oModel.setProperty("/hasMoreSupplying", false);
                } else {
                    oModel.setProperty("/hasMoreSupplying", true);
                }

            }


        },

        /* pagination logic for receiving/supplying report table.
           Currently a simple "Load More" button that loads the next set of data from the backend and appends it to the existing data in the table.
           Can be extended to include infinite scrolling, page numbers, etc.
           @param {}
           @private
        */

        _reportPagination(data, plantType, sHBoxId) {
            const oLocalModel = this.getModel("mainView");

            if (plantType) {
                const iPageSize = Number(oLocalModel.getProperty("/objPagination").receReportPageSize);
                const iDataCount = Number(data["@odata.count"]);

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/receReportTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/receReportTotalPages", iTotalPages);

            } else {

                const iPageSize = Number(oLocalModel.getProperty("/objPagination").suppReportPageSize);
                const iDataCount = Number(data["@odata.count"]);

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/suppReportTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/suppReportTotalPages", iTotalPages);

            }


            this._buildPaginationButtons(sHBoxId, plantType);

        },
        _compressionPagination(data, plantType, sHBoxId) {
            const oLocalModel = this.getModel("mainView");

            if (plantType) {
                const iPageSize = Number(oLocalModel.getProperty("/objPagination").receCompressionPageSize);
                const iDataCount = Number(data["@odata.count"]);
                if(iDataCount === 0){
                    return;

                }

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/receCompressionTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/receCompressionTotalPages", iTotalPages);

            } else {

                const iPageSize = Number(oLocalModel.getProperty("/objPagination").suppCompressionPageSize);
                const iDataCount = Number(data["@odata.count"]);
                if(iDataCount === 0){
                    return;

                }

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/suppCompressionTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/suppCompressionTotalPages", iTotalPages);

            }


            this._buildPaginationButtonsForCompression(sHBoxId, plantType);

        },


        _inventoryPagination(data, plantType, sHBoxId) {
            const oLocalModel = this.getModel("mainView");

            if (plantType) {
                const iPageSize = Number(oLocalModel.getProperty("/objPagination").receCombinedInventoryPageSize);
                const iDataCount = Number(data["@odata.count"]);
                if(iDataCount === 0){
                    return;

                }

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/receCombinedInventoryTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/receCombinedInventoryTotalPages", iTotalPages);

            } else {

                const iPageSize = Number(oLocalModel.getProperty("/objPagination").suppCombinedInventoryPageSize);
                const iDataCount = Number(data["@odata.count"]);
                if(iDataCount === 0){
                    return;

                }

                const iTotalPages = Math.ceil(iDataCount / iPageSize);
                oLocalModel.setProperty("/objPagination/suppCombinedInventoryTotalCount", iDataCount);
                oLocalModel.setProperty("/objPagination/suppCombinedInventoryTotalPages", iTotalPages);

            }


            this._buildPaginationButtonsForInventory(sHBoxId, plantType);

        },



        _buildPaginationButtons(sHBoxId, plantType) {

            const oHBox = this.byId(sHBoxId);
            oHBox.removeAllItems();
            let iTotalPages;
            if (plantType) {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").receReportTotalPages;

            } else {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").suppReportTotalPages;

            }
            for (let i = 1; i <= iTotalPages; i++) {
                oHBox.addItem(
                    new Button({
                        text: i.toString(),
                        press: this.onPagePress.bind(this, plantType)
                    })
                );
            }

        },

        _buildPaginationButtonsForCompression(sHBoxId, plantType) {

            const oHBox = this.byId(sHBoxId);
            oHBox.removeAllItems();
            let iTotalPages;
            if (plantType) {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").receCompressionTotalPages;

            } else {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").suppCompressionTotalPages;

            }
            for (let i = 1; i <= iTotalPages; i++) {
                oHBox.addItem(
                    new Button({
                        text: i.toString(),
                        press: this.onPagePressCompression.bind(this, plantType)
                    })
                );
            }

        },


        _buildPaginationButtonsForInventory(sHBoxId, plantType) {

            const oHBox = this.byId(sHBoxId);
            oHBox.removeAllItems();
            let iTotalPages;
            if (plantType) {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").receCombinedInventoryTotalPages;

            } else {
                iTotalPages = this.getModel("mainView").getProperty("/objPagination").suppCombinedInventoryTotalPages;

            }
            for (let i = 1; i <= iTotalPages; i++) {
                oHBox.addItem(
                    new Button({
                        text: i.toString(),
                        press: this.onPagePressInventory.bind(this, plantType)
                    })
                );
            }

        },



        onPagePress(bPlantType, oEvent) {

            const iPage = Number(oEvent.getSource().getText());
            let iPageSize;
            if (bPlantType) {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").receReportPageSize;
            } else {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").suppReportPageSize;

            }
            const iSkip = (iPage - 1) * iPageSize;
            if (bPlantType) {
                this.onLoadMoreOrderRep(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/receCurrentPage", iPage);

            } else {
                this.onLoadMoreSuppRep(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/suppCurrentPage", iPage);

            }


        },

        onPagePressCompression(bPlantType, oEvent) {

            const iPage = Number(oEvent.getSource().getText());
            let iPageSize;
            if (bPlantType) {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").receCompressionPageSize;
            } else {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").suppCompressionPageSize;

            }
            const iSkip = (iPage - 1) * iPageSize;
            if (bPlantType) {
                this.onLoadMoreReceComprarison(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/receCompressionCurrentPage", iPage);

            } else {
                this.onLoadMoreSuppComprarison(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/suppCompressionCurrentPage", iPage);

            }


        },

        onPagePressInventory(bPlantType, oEvent) {

            const iPage = Number(oEvent.getSource().getText());
            let iPageSize;
            if (bPlantType) {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").receCombinedInventoryPageSize;
            } else {
                iPageSize = this.getModel("mainView").getProperty("/objPagination").suppCombinedInventoryPageSize;

            }
            const iSkip = (iPage - 1) * iPageSize;
            if (bPlantType) {

                this.onLoadMoreReceInventory(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/receCombinedInventoryCurrentPage", iPage);

            } else {
                this.onLoadMoreSuppInventory(iPageSize, iSkip);
                this.getModel("mainView").setProperty("/objPagination/suppCombinedInventoryCurrentPage", iPage);

            }


        },



        /* called when user clicks on the table settings button for the Odessa Ordered Report table.
         Opens the TableP13n dialog for the Odessa Ordered Report table, allowing the user to personalize the table (column selection, sorting, filtering, etc.)
        @param {sap.ui.base.Event} oEvent - The event object from the button press
        @public
      */
        onRecivingTablePersonalization: function (oEvent) {
            TableP13n.openSettings(
                this.byId("idReceivingOrderReportTable"),
                oEvent
            );
        },

        /* Called when user clicks on the table settings button for the BA Kanban Report table.
          Opens the TableP13n dialog for the BA Kanban Report table, allowing the user to personalize the table (column selection, sorting, filtering, etc.)
          @param {sap.ui.base.Event} oEvent - The event object from the button press
          @public
       */

        onOpenTableSettingsForBAKanban(oEvent) {
            TableP13n.openSettings(
                this.byId("idSupplyingReportTable"),
                oEvent
            );
        },

        /* Table cell personalization for BA Kanban Report table. Currently includes column selection, sorting, and filtering. Can be extended to include more features like grouping, etc.
           @param {}
           @private
        */

        _supplyingReportTableCells() {
            TableP13n.register(this, {
                tableId: "idSupplyingReportTable",
                metadata: [
                    { key: "material", label: "Material No.", path: "material" },
                    { key: "description", label: "Material Description", path: "description" },
                    { key: "partGroup", label: "Material Group", path: "partGroup" },
                    { key: "supplyingPlantMax", label: "BA MAX", path: "supplyingPlantMax" },
                    { key: "supplyingPlantQohWip", label: "BA QOH + WIP", path: "supplyingPlantQohWip" },
                    { key: "shippedQty", label: "Shipped", path: "shippedQty" },
                    { key: "receivingPlantDemand", label: "Odessa Demand", path: "receivingPlantDemand" },
                    { key: "productionDemand", label: "BA Prod Demand", path: "productionDemand" }
                ]
            });

        },

        /* Table cell personalization for Odessa Ordered Report table. Currently includes column selection, sorting, and filtering. Can be extended to include more features like grouping, etc.
           @param {}
           @private
        */

        _receivingOrderReportTableCells() {
            TableP13n.register(this, {
                tableId: "idReceivingOrderReportTable",
                metadata: [
                    { key: "material", label: "Material No.", path: "material", dataType: "sap.ui.model.type.String" },
                    { key: "description", label: "Material Description", path: "description", dataType: "sap.ui.model.type.String" },
                    { key: "partGroup", label: "Material Group", path: "partGroup", dataType: "sap.ui.model.type.String" },
                    { key: "supplyingPlantQoh", label: "BA QOH", path: "supplyingPlantQoh", dataType: "sap.ui.model.type.Integer" },
                    { key: "receivingPlantOrderQty", label: "Order Quantity", path: "receivingPlantOrderQty", dataType: "sap.ui.model.type.Integer" }

                ]
            });

        },

        /* Function to register the TableP13n personalization for the Supplying Comparison Report table after the dynamic table is created. 
           This allows the user to personalize the table (column selection, sorting, filtering, etc.) based on the dynamically generated columns from the backend data.
           @param {Array} aFormattedData - The modified data array with a flat structure suitable for dynamic table creation, 
           including a total row at the end, used to extract the column metadata for personalization.
           @private
       */

        _fnComparisonCells(aFormattedData, TableID) {
            // Register P13n after table creatio
            const aMetadata = Object?.keys(aFormattedData?.[0] || {})
                .filter((sKey) => {
                    return !sKey.includes("_CLR");
                })
                .map((sKey) => {
                    return {
                        key: sKey,
                        label: this._getColumnText(sKey),
                        path: sKey
                    };
                });

            TableP13n.register(this, {
                tableId: TableID,
                metadata: aMetadata
            });

        },

        onSupplyingReportGo() {
            const supplyingPlantObj = {};
            const oLocalModel = this.getModel("mainView");
            supplyingPlantObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            supplyingPlantObj.partGroup = oLocalModel.getProperty("/supplyingPartGroup") || "";
            supplyingPlantObj.search = oLocalModel?.getProperty("/searchSupplyingReports") || "";
            supplyingPlantObj.material = oLocalModel?.getProperty("/supplyingMaterial") || "";
            // supplyingPlantObj.top = this._iTopSuppReport || 20;
            this._iTopSuppReport = this.getModel("mainView").getProperty("/objPagination/suppReportPageSize") || 20;
            supplyingPlantObj.skip = 0;
            this._getSupplyingPlantData(supplyingPlantObj).then((data) => {
                this._supplyingTableBinding(data);
            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        /* called when user clicks "Go" button on Receiving Report tab. 
           Currently a placeholder function. 
           Can be implemented to fetch data from the backend based on the search criteria and bind it to the table.
           @param {} 
           @public
        */

        onReceivingReportsGo() {
            const oPlantObj = {};
            const oLocalModel = this.getModel("mainView");
            oPlantObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            oPlantObj.partGroup = oLocalModel.getProperty("/partGroupReceSearch") || "";
            oPlantObj.search = oLocalModel?.getProperty("/searchReceivingReports") || "";
            oPlantObj.material = oLocalModel?.getProperty("/materialForSearch") || "";
            // this._setDefaultPagination();
            this._iTop = this.getModel("mainView").getProperty("/objPagination/receReportPageSize") || 20;

            this._getReceivingPlant(oPlantObj).then((data) => {
                this._recevingTableBinding(data);
            }).catch((err) => {
                this.showErrorMessage(err);
            });

        },

        /* called when user clicks "Go" button on Receiving Comparison Report tab.   
            Currently a placeholder function.
            Can be implemented to fetch data from the backend based on the search criteria and bind it to the table.
            @param {}
            @public
        */

        onReceivingComparisonGo() {
            const recevingCompObj = {};
            const oLocalModel = this.getModel("mainView");
            recevingCompObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            recevingCompObj.partGroup = oLocalModel.getProperty("/partGroupCompSearch") || "";
            recevingCompObj.search = oLocalModel?.getProperty("/compSearchValue") || "";
            recevingCompObj.material = oLocalModel?.getProperty("/materialCompSearch") || "";

            this._iTopRecComp = oLocalModel.getProperty("/objPagination/receCompressionPage") || 10;
            // recevingCompObj.skip = 0;

            this._getRecevingPlantComparison(recevingCompObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("ComparisonReport").setData([]);
                        this.byId("idReceComparisonTable").setModel([]);



                        const compReport = this.getModel("mainView").getProperty("/selectedReceComparisonPlantName");

                        this.updateTableCount("idReceComparisonTable",
                            "recevingCompTitleText",
                            "/recevingCompTitle",
                            this._getPlantName(),
                            compReport,
                            0);

                    this._compressionPagination("0", true, "idReceComparisonBtnHBox");
                    // this.getModel("mainView").setProperty("/objPagination/receCompressionPageSize", null);

                    } else {
                        this._fnDynamicTableForComparison(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        /* called when user clicks "Go" button on Receiving Combined Inventory Report tab.
            Currently a placeholder function.
            Can be implemented to fetch data from the backend based on the search criteria and bind it to the table.
            @param {}
            @public
        */

        onReceCombinedInventoryGo() {
            //set default pagination values
            // this._setDefaultPagination();
            const recevingInvObj = {};
            const oLocalModel = this.getModel("mainView");
            recevingInvObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            recevingInvObj.partGroup = oLocalModel.getProperty("/partGroupReceInvSearch") || "";
            recevingInvObj.search = oLocalModel?.getProperty("/searchReceInv") || "";
            recevingInvObj.material = oLocalModel?.getProperty("/materialRecInvSrh") || "";

            recevingInvObj.top = this._iTopReceInventory || 20;
            recevingInvObj.skip = 0;

            this._getRecevingInventoryRpt(recevingInvObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("OdessaCombinedInventoryModel").setData([]);
                        this.byId("idReceCombinedInventoryTable").setModel([]);

                        //Update table header count and title
                        const dataCount = "0";
                        this.updateTableCount("idReceCombinedInventoryTable", "receCombinedInventoryText", "/receCombinedInventoryTitle", "", "", dataCount);
                        // this.getModel("mainView").setProperty("/objPagination", 0);
                        this._inventoryPagination(dataCount, true, "idReceCombinedInventoryPagiHBox");


                    } else {
                        this._fnRecevingInventoryTableBinding(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        /* called when user clicks "Go" button on Supplying Inventory Report tab.
            Currently a placeholder function.
            Can be implemented to fetch data from the backend based on the search criteria and bind it to the table.
            @param {}
            @public
        */

        onSuppCombinedInventoryGo() {

            //set default pagination values
            // this._setDefaultPagination();
            const supplyingInvObj = {};
            const oLocalModel = this.getModel("mainView");
            supplyingInvObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            supplyingInvObj.partGroup = oLocalModel.getProperty("/partGroupSuppInvSearch") || "";
            supplyingInvObj.search = oLocalModel?.getProperty("/searchSuppInv") || "";
            supplyingInvObj.material = oLocalModel?.getProperty("/materialSuppInvSrh") || "";

            supplyingInvObj.top = 10;
            supplyingInvObj.skip = 0;

            this._getSuppInventoryApiCall(supplyingInvObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("supplyingCombinedInventoryModel").setData([]);
                        this.byId("idSuppCombinedInventoryGoButtonBox").setModel([]);

                        //Update table header count and title
                        const dataCount = "0";
                        this.updateTableCount("idSuppCombinedInventoryTable", "suppCombinedInventoryText", "/suppCombinedInventoryTitle", "", "", dataCount);
                        // this.getModel("mainView").setProperty("/objPagination", 0);
                        this._inventoryPagination(dataCount, false, "idSuppCombinedInventoryPagiHBox");
                    } else {
                        this._fnSupplyingInventoryTableBinding(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        /* called when user clicks "Go" button on supplying Comparison Report tab.
         Currently a placeholder function.
         Can be implemented to fetch data from the backend based on the search criteria and bind it to the table.
         @param {}
         @public
     */

        onSupplyingComparisonReportGo() {

            const supplyingCompObj = {};
            const oLocalModel = this.getModel("mainView");
            supplyingCompObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            supplyingCompObj.partGroup = oLocalModel.getProperty("/partGroupSuppSearch") || "";
            supplyingCompObj.search = oLocalModel?.getProperty("/suppSearch") || "";
            supplyingCompObj.material = oLocalModel?.getProperty("/materialSuppSearch") || "";
            //this._setDefaultPagination();
            this._iTopSuppComp = oLocalModel.getProperty("/objPagination/suppCompressionPage") || 10;

            this._getSupplyingPlantComparison(supplyingCompObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("SupplyingComparison")?.setData([]);
                        this.byId("idSupplyingComparisonTableId")?.setModel([]);

                        const compReport = this.getModel("mainView").getProperty("/selectedReceComparisonPlantName");

                        this.updateTableCount("idSupplyingComparisonTableId",
                            "supplyingCompTitleText",
                            "/supplyingCompTitle",
                            this._getPlantName(),
                            compReport,
                            0
                        );
                       
                        this._compressionPagination("0", false, "idSuppComparisonBtnHBox");
                    } else {
                        this._fnDynamicTableForSupplyingComparison(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        /* called when user clicks "Reset" button on Receiving Inventory Report tab.
            Resets the search criteria and fetches the default data from the backend to be displayed in the table.
            @param {}
            @public
        */

        onReceCombinedInventoryReset() {

            //set default pagination values & clear search filters
            this._oAdvancedFilter.clearFilters();
            this._setDefaultPagination();
            this._cleanFilters("receInventory");
            this._cleanSortingReceInventory();
            // reset table personalization
            this._resetTablePersonalization("idReceCombinedInventoryTable");

            const recevingInvObj = {};
            recevingInvObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            this._getRecevingInventoryRpt(recevingInvObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("OdessaCombinedInventoryModel").setData([]);
                        this.byId("idReceCombinedInventoryTable").setModel([]);
                    } else {
                        this._fnRecevingInventoryTableBinding(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        _cleanSortingReceInventory() {
            this.getModel("mainView").setProperty("/sortPropertyTableP13ReceInventory", null);
            this._sortReceInventoryProperty = null;
            this._receInventoryOrderSorting = null;

        },

        /* called when user clicks "Reset" button on Supplying Inventory Report tab.
            Resets the search criteria and fetches the default data from the backend to be displayed in the table.
            @param {}
            @public
        */

        onSuppCombinedInventoryReset() {
            //set default pagination values & clear search filters
            this._setDefaultPagination();
            this._cleanFilters("supplyingInventory");
            this._cleanSortingSuppInventory();
            // reset table personalization
            this._resetTablePersonalization("idSuppCombinedInventoryTable");
            this.getView().getModel("mainView")?.setProperty("/supplyingPlantInventoryAdvancedFilters", []);
            this._oAdvancedFilter.clearFilters();



            const supplyingInvObj = {};
            supplyingInvObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            this._getSuppInventoryApiCall(supplyingInvObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("supplyingCombinedInventoryModel").setData([]);
                        this.byId("idSuppCombinedInventoryGoButtonBox").setModel([]);

                    } else {
                        this._fnSupplyingInventoryTableBinding(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },


        _cleanSortingSuppInventory() {
            this._sortSuppInventoryProperty = null;
            this._suppInventoryOrderSorting = null;
            this.getModel("mainView").setProperty("/sortPropertyTableP13SuppInventory", null);

        },





        /* called when user clicks "Reset" button on supplying Comparison Report tab.
         Resets the search criteria and fetches the default data from the backend to be displayed in the table.
         @param {}
         @public
     */

        onSupplyingComparisonReportReset() {
            this._clearAdvancedFilter();
            this._cleanFilters("supplying");
            // Clean sorting for Supplying Comparison Report table
            this._cleanSortingSuppComparison();
            // reset table personalization
            this._resetTablePersonalization("idSupplyingComparisonTableId");
            const supplyingCompObj = {};
            supplyingCompObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            // this._setDefaultPagination();
            this._iTopSuppComp = this.getModel("mainView").getProperty("/objPagination/suppCompressionPage") || 10;
            this._getSupplyingPlantComparison(supplyingCompObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("SupplyingComparison")?.setData([]);
                        this.byId("idSupplyingComparisonTableId")?.setModel([]);
                    } else {
                        this._fnDynamicTableForSupplyingComparison(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        _cleanSortingSuppComparison() {
            this._sortSupplyingComparisonProperty = null;
            this._supplyingComparisonOrderSorting = null;

            this.getModel("mainView").setProperty("/sortPropertyTableP13SupplyingCompp",null);

        },

        /* called when user clicks "Reset" button on Odessa vs BA Comparison Report tab.
           Resets the search criteria and fetches the default data from the backend to be displayed in the table.
           @param {}
           @public
           */
        onReceivingComparisonReset() {
            this._clearAdvancedFilter();
            this._cleanFilters("receiving");

            this._cleanSortingForReceComprassion();
            // reset table personalization
            this._resetTablePersonalization("idReceComparisonTable");
            this._iTopRecComp = this.getModel("mainView").getProperty("/objPagination/receCompressionPage") || 10;
            const recevingCompObj = {};
            recevingCompObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            this._getRecevingPlantComparison(recevingCompObj)
                .then((data) => {
                    if (!data?.value || data.value.length === 0) {
                        this.getModel("ComparisonReport").setData([]);
                        this.byId("idReceComparisonTable").setModel([]);
                    } else {
                        this._fnDynamicTableForComparison(data);
                    }
                }).catch((err) => {
                    this.showErrorMessage(err.message);
                });

        },

        _cleanSortingForReceComprassion() {
            this._sortReceComparisonProperty = null;
            this._receComparisonOrderSorting = null;
            this.getModel("mainView").setProperty("/sortPropertyTableP13ReceCompp", null);


        },

        /* Function to clear the search filters for the Receiving vs BA Supplying Report tab.
            Resets the search fields in the model to empty strings, which in turn resets the input fields in the UI due to data binding.
            @param {boolean} receiving - A flag to indicate if the filters to be cleared are for the receiving report (true) or the supplying report (false). 
            Currently not used as there is only one set of filters, but can be extended in the future if needed.
            @private
        */


        _cleanFilters(plantType) {
            const oLocalModel = this.getModel("mainView");
            if (plantType === "receiving") {
                oLocalModel.setProperty("/partGroupCompSearch", "");
                oLocalModel.setProperty("/compSearchValue", "");
                oLocalModel.setProperty("/materialCompSearch", "");
            }
            if (plantType === "supplying") {
                oLocalModel.setProperty("/partGroupSuppSearch", "");
                oLocalModel.setProperty("/suppSearch", "");
                oLocalModel.setProperty("/materialSuppSearch", "");
            }
            if (plantType === "receInventory") {
                oLocalModel.setProperty("/partGroupReceInvSearch", "");
                oLocalModel.setProperty("/searchReceInv", "");
                oLocalModel.setProperty("/materialRecInvSrh", "");

            }
            if (plantType === "supplyingInventory") {
                oLocalModel.setProperty("/partGroupSuppInvSearch", "");
                oLocalModel.setProperty("/searchSuppInv", "");
                oLocalModel.setProperty("/materialSuppInvSrh", "");

            }

        },

        /* Function to bind the data to the Receiving Report table after fetching it from the backend.
      Also adds a dummy total row at the end of the table to display the total QOH and Order Quantity, which is calculated in the _recalculateAndInject function after the table is rendered.
      @param {Array} data - The data array returned from the backend to be bound to the table
      @private
      @memberof com.slb.chxkanban.controller.Main 
      */
        _supplyingTableBinding(data) {

            const oCloneData = jQuery.extend(true, {}, data);
            const dataCount = data["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/supplyingPlantDataCount", dataCount);
            // this._clearAdvancedFilter();
            data?.demandReportItems?.push({
                material: "",
                description: "",
                partGroup: "",
                supplyingPlantMax: 0,
                supplyingPlantQohWip: 0,
                shippedQty: 0,
                receivingPlantDemand: 0,
                productionDemand: 0

            });
            const oModel = this.getModel("mainView");
            oModel.setProperty("/supplyingPlantData", data?.demandReportItems);
            oModel.setProperty("/supplyingFullPlantData", data?.demandReportItems);
            // Table tile name with count of records
            this.updateTableCount("idSupplyingReportTable", "SupplyReportText", "/supplyingTitle", "", "", dataCount);
            const oTable = this.byId("idSupplyingReportTable");
            oTable.setVisibleRowCount(data?.demandReportItems?.length); // or any desired number
            //Wait for rendering
            let bRecevingPlant = false;
            oTable.attachEventOnce("rowsUpdated", () => {
                this._recalculateAndInject(oTable, bRecevingPlant);
            });
            this._updatePaginationUI(oCloneData, bRecevingPlant);

        },

        /* Function to bind the data to the Receiving Report table after fetching it from the backend.
        Also adds a dummy total row at the end of the table to display the total QOH and Order Quantity, which is calculated in the _recalculateAndInject function after the table is rendered.
        @param {Array} data - The data array returned from the backend to be bound to the table
        @private
        @memberof com.slb.chxkanban.controller.Main 
        */
        _recevingTableBinding(data) {

            const oCloneData = jQuery.extend(true, {}, data);

            const dataCount = data["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/receivingPlantDataCount", dataCount);

            // this._clearAdvancedFilter();
            data?.orderReportItems?.push({
                material: "",
                description: "",
                partGroup: "",
                receivingPlantOrderQty: 0,
                supplyingPlantQoh: 0
            });
            const oModel = this.getModel("mainView");
            oModel.setProperty("/receivingPlantData", data?.orderReportItems || []);
            oModel.setProperty("/receivingFullPlantData", data?.orderReportItems || []);
            //slected pleant name 
            this._getPlantName();
            // Table tile name with count of records
            this.updateTableCount("idReceivingOrderReportTable", "OrderdReportText", "/receivingTitle", "", "", dataCount);
            // this.updateTableCount("idReceivingOrderReportTable","", "/receivingTitle");
            const oTable = this.byId("idReceivingOrderReportTable");
            oTable.setVisibleRowCount(data?.orderReportItems?.length); // or any desired number
            //Wait for rendering
            let bRecevingPlant = true;
            oTable.attachEventOnce("rowsUpdated", () => {
                this._recalculateAndInject(oTable, bRecevingPlant);
            });
            this._updatePaginationUI(oCloneData, bRecevingPlant);


        },

        /* Function to modify the column structure of the comparison report data returned from the backend to fit the format required for the dynamic table creation.   
          The backend returns the data in a format where the plant names are nested within each material record, but the dynamic table requires a flat structure with plant names as column headers.
          This function iterates through the data and restructures it to create a flat array of objects where each plant's QOH is represented as a separate column, 
          and also adds a total row at the end for summing up the QOH values.
          @param {Array} data - The original data array returned from the backend for the comparison report
          @returns {Array} - The modified data array with a flat structure suitable for dynamic table creation, including a total row at the end.
          @private
      */

        _compresionTableColumnModification(data, plantType) {

            const aFormattedData = data.map(item => {
                const oRow = {
                    material: item.material,
                    description: item.description,
                    MaterialGroup: item.partGroup
                };

                item.plants.forEach(plant => {
                    oRow[`${plant.plantName}_QOH`] = plant.qoh;
                    oRow[`${plant.plantName}_CLR`] = plant.category;
                });

                return oRow;
            });

            // sorting logic for receiving comparison report

            if (plantType === "receiving") {

                if (aFormattedData.length > 0 && this._sortReceComparisonProperty) {
                    let bDesc = this._receComparisonOrderSorting;
                    let sPath = this._sortReceComparisonProperty;

                    // Sort only normal data
                    aFormattedData.sort((a, b) => {
                        if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                        if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                        return 0;
                    });

                } else {

                    const aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13ReceCompp");

                    if (aSorters && aSorters.length) {
                        aFormattedData.sort((a, b) => {
                            for (let i = 0; i < aSorters.length; i++) {
                                const oSorter = aSorters[i];
                                const sPath = oSorter.sPath;
                                const bDesc = oSorter.bDescending;

                                let vA = a[sPath];
                                let vB = b[sPath];

                                if (vA === null) { vA = ""; }
                                if (vB === null) { vB = ""; }

                                if (vA < vB) {
                                    return bDesc ? 1 : -1;
                                }

                                if (vA > vB) {
                                    return bDesc ? -1 : 1;
                                }
                            }

                            return 0;
                        });
                    }

                }

            } else {

                if (aFormattedData.length > 0 && this._sortSupplyingComparisonProperty) {
                    let bDesc = this._supplyingComparisonOrderSorting;
                    let sPath = this._sortSupplyingComparisonProperty;

                    // Sort only normal data
                    aFormattedData.sort((a, b) => {
                        if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                        if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                        return 0;
                    });

                } else {

                    const aSorters = this.getModel("mainView").getProperty("/sortPropertyTableP13SupplyingCompp");

                    if (aSorters && aSorters.length) {
                        aFormattedData.sort((a, b) => {
                            for (let i = 0; i < aSorters.length; i++) {
                                const oSorter = aSorters[i];
                                const sPath = oSorter.sPath;
                                const bDesc = oSorter.bDescending;

                                let vA = a[sPath];
                                let vB = b[sPath];

                                if (vA === null) { vA = ""; }
                                if (vB === null) { vB = ""; }

                                if (vA < vB) {
                                    return bDesc ? 1 : -1;
                                }

                                if (vA > vB) {
                                    return bDesc ? -1 : 1;
                                }
                            }

                            return 0;
                        });
                    }

                }

            }



            // Create Total Row
            if (aFormattedData.length > 0) {
                const oTotalRow = {};
                Object.keys(aFormattedData[0]).forEach(key => {
                    if (key === "material") {
                        oTotalRow[key] = "";
                    } else if (
                        key === "description" ||
                        key === "MaterialGroup"
                    ) {
                        oTotalRow[key] = "";
                    } else {
                        oTotalRow[key] = 0;
                    }

                });
                aFormattedData.push(oTotalRow);
            }
            return aFormattedData;
        },

        /* Function to bind the data to the Supplying Inventory Report table after fetching it from the backend.
           Also adds a dummy total row at the end of the table to display the total inventory, which is calculated in the _fnInventorySum function.
           @param {Array} data - The data array returned from the backend to be bound to the table
           @private
           @memberof com.slb.chxkanban.controller.Main 
        */

        _fnSupplyingInventoryTableBinding(oData) {
            // this._clearAdvancedFilter();
            //store oData for pagination logic 
            this.getModel("mainView").setProperty("/supplyingInventoryOdata", oData);
            const aFormattedData = this._formatedInventoryData(oData?.value);

            // Store group headers in model for later use in dynamic table personalization, Excel Download and column creation
            this.getModel("mainView").setProperty("/inventorySupplyingGroupHeaders", aFormattedData?.groupHeaders);

            this._combineInventoryDataForSupplying(aFormattedData, oData?.value);
            this._supplyingCombinedInventoryTableCells(aFormattedData.data);
            //set last row for sum 
            const oTable = this.byId("idSuppCombinedInventoryTable");
            this.setFooterForSum(oTable);
            //Update table header count and title
            const dataCount = oData["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/supplyingInventoryDataCount", dataCount);
            this.updateTableCount("idSuppCombinedInventoryTable", "suppCombinedInventoryText", "/suppCombinedInventoryTitle", "", "", dataCount);
            // Display fotter sum
            this._fnInventorySum("supplyingCombinedInventoryModel");
            // Every time when filter and sorting will apply sum need to re-calculate 
            oTable.attachRowsUpdated(() => {
                this._fnInventorySum("supplyingCombinedInventoryModel");
            });
            // Display only visible rows
            oTable.setVisibleRowCount(aFormattedData?.data?.length);
            // Pagination Logic 
            const bRecInven = false;
            // this._fnReceInvPagination(oData, bRecInven);
            this._inventoryPagination(oData, bRecInven, "idSuppCombinedInventoryPagiHBox");

        },

        /* Function to bind the data to the Receiving Inventory Report table after fetching it from the backend.
           Also adds a dummy total row at the end of the table to display the total inventory, which is calculated in the _fnInventorySum function.
           @param {Array} data - The data array returned from the backend to be bound to the table
           @private
           @memberof com.slb.chxkanban.controller.Main 
        */

        _fnRecevingInventoryTableBinding(oData) {
            // this._clearAdvancedFilter();
            //store oData for pagination logic 
            this.getModel("mainView").setProperty("/receivingInventoryOdata", oData);
            const aFormattedData = this._formatedInventoryData(oData?.value);
            //store formated data for advanced search and filter logic
            this.getModel("mainView").setProperty("/receivingInventoryFormatedData", aFormattedData?.data);
            // Store group headers in model for later use in dynamic table personalization, Excel Download and column creation
            this.getModel("mainView").setProperty("/inventoryReceivingGroupHeaders", aFormattedData?.groupHeaders);
            this._combineInventoryDataForReceving(aFormattedData, oData?.value);
            this._recevingCombinedInventoryTableCells(aFormattedData.data);
            //set last row for sum 
            const oTable = this.byId("idReceCombinedInventoryTable");
            this.setFooterForSum(oTable);
            //Update table header count and title
            const dataCount = oData["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/receivingInventoryDataCount", dataCount);
            this.updateTableCount("idReceCombinedInventoryTable", "receCombinedInventoryText", "/receCombinedInventoryTitle", "", "", dataCount);
            // Display fotter sum
            this._fnInventorySum("OdessaCombinedInventoryModel");
            // Every time when filter and sorting will apply sum need to re-calculate
            oTable.attachRowsUpdated(() => {
                this._fnInventorySum("OdessaCombinedInventoryModel");
            });
            // Display only visible rows
            oTable.setVisibleRowCount(aFormattedData?.data?.length);
            // Pagination Logic 
            const bRecInven = true;
            //this._fnReceInvPagination(oData, bRecInven);

            this._inventoryPagination(oData, bRecInven, "idReceCombinedInventoryPagiHBox");

        },

        /* Function to handle pagination logic for the inventory tables.
           The backend returns the total count of records in the @odata.count property, and the current set of loaded records in the value array. 
           This function compares
            the length of the loaded records with the total count to determine 
           if there are more records to load, 
           and updates the model properties accordingly to control the visibility of the "Load More" button and display the counts in the UI.
           @param {Object} oData - The original OData response object returned from the backend for the inventory report, 
           containing both the loaded records and the total count.
           @param {boolean} bRecInven - A flag to indicate if the pagination is for the receiving inventory table (true) or the supplying inventory table (false), 
           used to update the correct model properties for each table.
           @private
        */

        _fnReceInvPagination(oData, bRecInven) {
            const aExistngData = oData?.value?.filter((items) => {
                return items.material !== "";
            });
            const iTotalCount = aExistngData?.length || 0;
            const iDataCount = oData["@odata.count"];
            const oModel = this.getModel("mainView");
            if (bRecInven) {
                oModel.setProperty("/loadedCountRecInv", iTotalCount);
                oModel.setProperty("/totalCountRecInv", iDataCount);
                if (iDataCount === iTotalCount) {
                    oModel.setProperty("/hasMoreRecInv", false);
                } else {
                    oModel.setProperty("/hasMoreRecInv", true);

                }
            } else {
                oModel.setProperty("/loadedCountSuppInv", iTotalCount);
                oModel.setProperty("/totalCountSuppInv", iDataCount);

                if (iDataCount === iTotalCount) {
                    oModel.setProperty("/hasMoreSuppInv", false);
                } else {
                    oModel.setProperty("/hasMoreSuppInv", true);

                }

            }


        },

        /* Table cell personalization for Odessa Ordered Report table. 
          Currently includes column selection, sorting, and filtering. 
          Can be extended to include more features like grouping, etc.
          @param {}
          @private
      */

        _recevingCombinedInventoryTableCells(data) {
            const oHeaderData = this.getModel("mainView").getProperty("/inventoryReceivingGroupHeaders");

            const aMetaData = Object.keys(data?.[0] || {}).map((sKey) => {

                let sLabel = sKey;

                if (sKey.includes("_")) {
                    const [sPrefix, sSuffix] = sKey.split("_");

                    if (oHeaderData[sPrefix]) {
                        sLabel = `${oHeaderData[sPrefix]}_${sSuffix}`;
                    }
                }

                return {
                    key: sKey,
                    label: this._getColumnText(sLabel),
                    path: sKey
                };
            });
            TableP13n.register(this, {
                tableId: "idReceCombinedInventoryTable",
                metadata: aMetaData
            });

        },

        _supplyingCombinedInventoryTableCells(data) {
            const oHeaderData = this.getModel("mainView").getProperty("/inventorySupplyingGroupHeaders");

            const aMetaData = Object.keys(data?.[0] || {}).map((sKey) => {

                let sLabel = sKey;

                if (sKey.includes("_")) {
                    const [sPrefix, sSuffix] = sKey.split("_");

                    if (oHeaderData[sPrefix]) {
                        sLabel = `${oHeaderData[sPrefix]}_${sSuffix}`;
                    }
                }

                return {
                    key: sKey,
                    label: this._getColumnText(sLabel),
                    path: sKey
                };
            });
            TableP13n.register(this, {
                tableId: "idSuppCombinedInventoryTable",
                metadata: aMetaData
            });

        },

        /*called from _tablePersonalization to initialize the combined inventory table for odessa report.
     This table is a combination of the BA and Odessa inventory data, and is used to show the total inventory for each part. 
     The columns are dynamically generated based on the data returned from the backend, and the table is personalized using the same TableP13n utility as the other tables in the app.
     @param {}
     @private
   */
        _combineInventoryDataForReceving(formattedData, aData) {
            this.getModel("mainView").setProperty("/OdessaCombinedInventoryData", formattedData.data);
            var that = this;

            //Need to recheck again
            if (aData.length > 0) {
                const aColumns = this._createInventoryColumns(aData?.[0]);
                DynamicTable.createGroupedDynamicTable(that, {
                    tableId: "idReceCombinedInventoryTable",
                    modelName: "OdessaCombinedInventoryModel",
                    data: formattedData.data,
                    columns: aColumns
                });
            }
        },




        _combineInventoryDataForSupplying(formattedData, aData) {
            this.getModel("mainView").setProperty("/supplyingCombinedInventoryData", formattedData.data);
            var that = this;
            const aColumns = this._createInventoryColumns(aData[0]);
            DynamicTable.createGroupedDynamicTable(that, {
                tableId: "idSuppCombinedInventoryTable",
                modelName: "supplyingCombinedInventoryModel",
                data: formattedData.data,
                columns: aColumns
            });
        },

        _createInventoryColumns: function (oFirstRow) {

            const aColumns = [];

            const mFixedColumns = {
                material: "Material No.",
                description: "Material Description",
                partGroup: "Material Group"

            };

            Object.keys(mFixedColumns).forEach(function (sField) {

                aColumns.push({
                    group: "",
                    field: sField,
                    label: mFixedColumns[sField],
                    isAggregatable: false
                });

            });

            [
                "supplyingPlant",
                "receivingPlant",
                "combinedSummary"
            ].forEach(function (sSection) {

                const oSection = oFirstRow ? oFirstRow[sSection] : {};

                const sGroupName = oSection.plantName;

                Object.keys(oSection)
                    .filter(function (sKey) {
                        return sKey !== "plant" &&
                            sKey !== "plantName";
                    })
                    .forEach(function (sKey) {

                        aColumns.push({
                            group: sGroupName,
                            field: sSection + "_" + sKey,
                            label: sKey.toUpperCase(),
                            isAggregatable: true
                        });

                    });

            });

            // Add In Transit at the end
            aColumns.push({
                group: "",
                field: "inTransit",
                label: "In Transit",
                isAggregatable: false
            });

            return aColumns;

        },

        _formatedInventoryData(aData) {


            const oGroupHeaders = {
                combinedSummary: aData?.[0]?.combinedSummary?.plantName || "Combined Summary",
                receivingPlant: aData?.[0]?.receivingPlant?.plantName || "Receiving Plant",
                supplyingPlant: aData?.[0]?.supplyingPlant?.plantName || "Supplying Plant"
            };


            const fnFlatten = (oData, sPrefix) => {
                return Object.fromEntries(
                    Object.entries(oData)
                        .filter(([sKey]) => !["plant", "plantName"].includes(sKey))
                        .map(([sKey, value]) => [`${sPrefix}_${sKey}`, value])
                );
            };

            const aFormattedData = aData.map(item => {

                const {
                    combinedSummary = {},
                    receivingPlant = {},
                    supplyingPlant = {},
                    ...baseData
                } = item;

                return {
                    ...baseData,
                    ...fnFlatten(combinedSummary, "combinedSummary"),
                    ...fnFlatten(receivingPlant, "receivingPlant"),
                    ...fnFlatten(supplyingPlant, "supplyingPlant")
                };
            });


            //Dummy Sum Row Creation
            if (aFormattedData.length > 0) {
                const oTotalRow = {
                    material: ""
                };
                Object.keys(aFormattedData[0]).forEach(key => {
                    if (key === "material") {
                        oTotalRow[key] = "";
                    } else if (key === "description" || key === "partGroup" || key === "partGroupName" || key === "inTransit") {
                        oTotalRow[key] = "";
                    } else {
                        oTotalRow[key] = 0;

                    }
                });
                aFormattedData.push(oTotalRow);
            }

            return {
                data: aFormattedData,
                groupHeaders: oGroupHeaders
            };

        },

        /* Function to handle the personalization settings for the Receving Combined Inventory table.
           Opens the TableP13n dialog for the specified table when the user clicks on the personalization button in the UI.
           @param {Object} oEvent - The event object from the click event, used to pass to the TableP13n utility for opening the settings dialog.
           @private
        */

        onPresReceCombinedInventorySetting(oEvent) {
            TableP13n.openSettings(
                this.byId("idReceCombinedInventoryTable"),
                oEvent
            );
        },

        /* Function to handle the personalization settings for the Supplying Combined Inventory table.
           Opens the TableP13n dialog for the specified table when the user clicks on the personalization button in the UI.
           @param {Object} oEvent - The event object from the click event, used to pass to the TableP13n utility for opening the settings dialog.
           @private
        */


        onSuppCombinedInventorySetting(oEvent) {
            TableP13n.openSettings(
                this.byId("idSuppCombinedInventoryTable"),
                oEvent
            );
        },


        /* Function to create and bind the dynamic table for the Supplying comparison report.
         Configures the table with the appropriate columns, sorting, and coloring based on the data values.
         @param {Array} data - The data array returned from the backend to be bound to the table
         @private
      */

        _fnDynamicTableForSupplyingComparison(data, noFormatColumns) {
            // this._clearAdvancedFilter();
            if (data?.value?.length === 0) {
                return;

            }
            const dataCount = data["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/comparisonSupplyingCount", dataCount);
            let aFormattedData;
            if (!noFormatColumns) {
                aFormattedData = this._compresionTableColumnModification(data?.value);
            } else {
                aFormattedData = data?.value;
            }

            this.getModel("mainView").setProperty("/comparisonSupplyingData", aFormattedData);
            // Register P13n for the dynamically created comparison table.
            this._fnComparisonCells(aFormattedData, "idSupplyingComparisonTableId");
            const aDefaultColumns = Object.keys(aFormattedData?.[0] || {}).filter(
                sColumn => !sColumn.includes("_CLR")
            );
            const coloredColumn = [];
            aDefaultColumns.forEach(column => {
                if (column.includes("QOH")) {
                    coloredColumn.push(column);
                }
            });
            var oConfig = {
                tableId: "idSupplyingComparisonTableId",
                modelName: "SupplyingComparison",
                data: aFormattedData,
                defaultVisibleColumns: aDefaultColumns,
                sortableColumns: coloredColumn,
                colorColumns: coloredColumn
            };
            var that = this;
            DynamicTable.createDynamicTable(that, oConfig);
            this._fnOdessaComparisonSum("SupplyingComparison");
            const oTable = this.byId("idSupplyingComparisonTableId");
            this.setFooterForSum(oTable);
            oTable.setVisibleRowCount(aFormattedData?.length);

            // show total count 
            this.updateTableCount("idSupplyingComparisonTableId",
                "supplyingCompTitleText",
                "/supplyingCompTitle",
                (coloredColumn[0] || "").replace(/_.*/, ""),
                (coloredColumn[1] || "").replace(/_.*/, ""),
                dataCount
            );
            // storing config data for filter use
            oTable._config = oConfig;
            oTable._reApplyColors = DynamicTable._applyComparisonTableColors.bind(this, oTable, oConfig);
            // RE-APPLY COLORS AFTER TABLE UPDATE (E.G. AFTER SORTING, FILTERING, ETC.)
            oTable.attachRowsUpdated(function () {
                DynamicTable._applyComparisonTableColors(oTable, oConfig);
                this._fnOdessaComparisonSum("SupplyingComparison");
            }.bind(this));
            const bRecComp = false;
            //this._fnReceCompPagination(data, bRecComp);
            // supp comparison pagination logic,
            this._compressionPagination(data, bRecComp, "idSuppComparisonBtnHBox");

        },

        /* Function to create and bind the dynamic table for the Odessa vs BA comparison report.
           Configures the table with the appropriate columns, sorting, and coloring based on the data values.
           @param {Array} data - The data array returned from the backend to be bound to the table
           @private
        */

        _fnDynamicTableForComparison(data, noFormatColumns) {
            // this._clearAdvancedFilter();


            let aFormattedData;
            if (!noFormatColumns) {
                aFormattedData = this._compresionTableColumnModification(data?.value, "receiving");

            } else {
                aFormattedData = data?.value;
            }
            this.getModel("mainView").setProperty("/comparisonRecevingData", aFormattedData);
            this._fnComparisonCells(aFormattedData, "idReceComparisonTable");
            const aDefaultColumns = Object.keys(aFormattedData?.[0]).filter(
                sColumn => !sColumn.includes("_CLR")
            );
            const coloredColumn = [];
            aDefaultColumns.forEach(column => {
                if (column.includes("QOH")) {

                    coloredColumn.push(column);
                }
            });
            var oConfig = {
                tableId: "idReceComparisonTable",
                modelName: "ComparisonReport",
                data: aFormattedData,
                defaultVisibleColumns: aDefaultColumns,
                sortableColumns: coloredColumn,
                colorColumns: coloredColumn
            };
            var that = this;
            DynamicTable.createDynamicTable(that, oConfig);
            this._fnOdessaComparisonSum("ComparisonReport");
            const oTable = this.byId("idReceComparisonTable");
            oTable._config = oConfig;
            this.setFooterForSum(oTable);
            oTable.setVisibleRowCount(aFormattedData?.length);
            oTable._reApplyColors = DynamicTable._applyComparisonTableColors.bind(this, oTable, oConfig);

            // show total count 
            const dataCount = data["@odata.count"] || "0";
            this.getModel("mainView").setProperty("/comparisonRecevingCount", dataCount);
            this.updateTableCount("idReceComparisonTable",
                "recevingCompTitleText",
                "/recevingCompTitle",
                coloredColumn[0].replace(/_.*/, ""),
                coloredColumn[1].replace(/_.*/, ""),
                dataCount);
            // RE-APPLY COLORS AFTER TABLE UPDATE (E.G. AFTER SORTING, FILTERING, ETC.)
            oTable.attachRowsUpdated(function () {
                DynamicTable._applyComparisonTableColors(oTable, oConfig);
                this._fnOdessaComparisonSum("ComparisonReport");

            }.bind(this));
            const bRecComp = true;
            //this._fnReceCompPagination(data, bRecComp);

            // for pagination logic,
            this._compressionPagination(data, bRecComp, "idReceComparisonBtnHBox");


        },


        _fnReceCompPagination(data, bRecComp) {
            const aExistngData = data?.value?.filter((items) => {
                return items.material !== "";
            });
            const iTotalCount = aExistngData?.length || 0;
            const iDataCount = data["@odata.count"];
            const oModel = this.getModel("mainView");
            if (bRecComp) {
                oModel.setProperty("/loadedCountRecComp", iTotalCount);
                oModel.setProperty("/totalCountRecComp", iDataCount);
            } else {
                oModel.setProperty("/loadedCountSuppRep", iTotalCount);
                oModel.setProperty("/totalCountSuppRepo", iDataCount);

            }
            if (iDataCount === iTotalCount) {
                oModel.setProperty("/hasMoreRecComp", false);
            } else {
                oModel.setProperty("/hasMoreRecComp", true);

            }

        },

        /* called when user clicks on the table settings button for Comparison Report table.
           Opens the TableP13n dialog for the Odessa vs BA Comparison Report table, allowing the user to personalize the table (column selection, sorting, filtering, etc.)
          @param {sap.ui.base.Event} oEvent - The event object from the button press
          @public
       */
        onReceivingComparisonSetting(oEvent) {
            TableP13n.openSettings(
                this.byId("idReceComparisonTable"),
                oEvent
            );
        },

        /* called when user clicks on the table settings button for supplying Comparison Report table.
           Opens the TableP13n dialog for the supplying Comparison Report table, allowing the user to personalize the table (column selection, sorting, filtering, etc.)
          @param {sap.ui.base.Event} oEvent - The event object from the button press
          @public
       */

        onSupplyingComparisonSettings(oEvent) {
            TableP13n.openSettings(
                this.byId("idSupplyingComparisonTableId"),
                oEvent
            );

        },


        onLoadMoreOrderRep(iPageSize, iSkip) {
            this._iTop = iPageSize;
            const oReceivingPlantObj = {};
            oReceivingPlantObj.partGroup = this.getModel("mainView").getProperty("/partGroupForSearch") || "";
            oReceivingPlantObj.search = this.getModel("mainView")?.getProperty("/searchReceivingReports") || "";
            oReceivingPlantObj.material = this.getModel("mainView")?.getProperty("/materialForSearch") || "";
            oReceivingPlantObj.skip = iSkip || 0;
            this._getReceivingPlant(oReceivingPlantObj).then((data) => {
                if (data?.orderReportItems.length !== 0) {
                    this._recevingTableBinding(data);
                }
            });
        },

        onLoadMoreReceComprarison(iPageSize, iSkip) {
            this._iTopRecComp = iPageSize;
            this._getRecevingPlantComparison({ skip: iSkip }).then((oData) => {
                this._fnDynamicTableForComparison(oData);
            });
        },

        onLoadMoreSuppComprarison(iPageSize, iSkip) {
            this._iTopSuppComp = iPageSize;
            this._getSupplyingPlantComparison({ skip: iSkip }).then((oData) => {
                this._fnDynamicTableForSupplyingComparison(oData);
            });
        },

        onLoadMoreReceInventory(iPageSize, iSkip) {
            this._iTopReceInventory = iPageSize;
            this._getRecevingInventoryRpt({ skip: iSkip }).then((oData) => {
                this._fnRecevingInventoryTableBinding(oData);
            });

        },

        onLoadMoreSuppInventory(iPageSize, iSkip) {
            this._iTopSuppInventory = iPageSize;
            this._getSuppInventoryApiCall({ skip: iSkip }).then((oData) => {
                this._fnSupplyingInventoryTableBinding(oData);
            });

        },
        /* pagination logic for receiving comparison report table.
           Currently a simple "Load More" button that loads the next set of data from the backend and appends it to the existing data in the table.
           Can be extended to include infinite scrolling, page numbers, etc.
           @param {}
           @private
        */

        onLoadMoreRecCom() {
            this._iPageRecComp++;
            const iSkip = this._iPageRecComp * this._iTopRecComp;
            this._getRecevingPlantComparison({ skip: iSkip }).then((data) => {
                const aFormattedData = this._compresionTableColumnModification(data?.value, "receiving");
                const oExistngData = this.getModel("mainView").getProperty("/comparisonRecevingData") || [];
                let aNewData = oExistngData.filter(item => item.material !== "");
                if (data?.value.length !== 0) {
                    data.value = [...aNewData, ...aFormattedData];
                    const noFormatColumns = true;
                    this._fnDynamicTableForComparison(data, noFormatColumns);
                }
            });
        },

        /* pagination logic for supplying comparison report table.
           Currently a simple "Load More" button that loads the next set of data from the backend and appends it to the existing data in the table.
           Can be extended to include infinite scrolling, page numbers, etc.
           @param {}
           @private
        */

        onLoadMoreSuppComp() {
            this._iPageSuppComp++;
            const iSkip = this._iPageSuppComp * this._iTopSuppComp;
            this._getSupplyingPlantComparison({ skip: iSkip }).then((data) => {
                const aFormattedData = this._compresionTableColumnModification(data?.value);
                const oExistngData = this.getModel("mainView").getProperty("/comparisonSupplyingData") || [];
                let aNewData = oExistngData.filter(item => item.material !== "");
                if (data?.value.length !== 0) {
                    data.value = [...aNewData, ...aFormattedData];
                    const noFormatColumns = true;
                    this._fnDynamicTableForSupplyingComparison(data, noFormatColumns);
                }
            });
        },

        /* pagination logic for supplying  Order report table.
          Currently a simple "Load More" button that loads the next set of data from the backend and appends it to the existing data in the table.
          Can be extended to include infinite scrolling, page numbers, etc.
          @param {}
          @private
       */
        onLoadMoreSuppRep(iPage, iSkip) {
            this._iTopSuppReport = iPage;
            const oSupplyingPlantObj = {};
            oSupplyingPlantObj.partGroup = this.getModel("mainView").getProperty("/supplyingPartGroup") || "";
            oSupplyingPlantObj.search = this.getModel("mainView")?.getProperty("/searchSupplyingReports") || "";
            oSupplyingPlantObj.material = this.getModel("mainView")?.getProperty("/supplyingMaterial") || "";
            oSupplyingPlantObj.skip = iSkip || 0;
            this._getSupplyingPlantData(oSupplyingPlantObj).then((data) => {
                if (data?.demandReportItems.length !== 0) {
                    this._supplyingTableBinding(data);
                }
            });
        },

        /* Function to calculate the sum of the QOH columns in the Odessa vs BA comparison report and inject the total values into the dummy total row at the end of the table.
           Iterates through the data rows and sums up the values for each QOH column, then updates the total row with the calculated sums and refreshes the model to update the table display.
           @param {string} sModelName - The name of the model containing the comparison report data
           @private
        */
        _fnOdessaComparisonSum(sModelName) {
            const aData = this.getModel(sModelName).getData();
            const oTotalRow = aData.find(item => item.material === "");
            if (!oTotalRow || !aData.length) {
                return;
            }
            const aQOHColumns = Object.keys(aData?.[0]).filter(
                key => key.endsWith("_QOH")
            );
            const oTotals = {};

            aQOHColumns.forEach(col => {
                oTotals[col] = 0;
            });
            aData.forEach(item => {
                if (item.material === "") {
                    return;
                }
                aQOHColumns.forEach(col => {
                    oTotals[col] += Number(item[col]) || 0;
                });
            });
            aQOHColumns.forEach(col => {
                oTotalRow[col] = oTotals[col];
            });
            this.getModel(sModelName).refresh(true);
        },

        /* Function to calculate the sum of columns in the inventory tables and inject the total values into the dummy total row at the end of the table.
           Iterates through the data rows , then updates the total row with the calculated sums and refreshes the model to update the table display.
           @param {string} sModelName - The name of the model containing the inventory report data
           @private
        */

        _fnInventorySum(sModelName) {
            const aData = this.getModel(sModelName).getData();
            const oTotalRow = aData.find(item => item.material === "");
            if (!oTotalRow || !aData.length) {
                return;
            }
            const aQOHColumns = Object.keys(aData?.[0]).filter(
                key => key.includes("_") || key === "inTransit"
            );
            const oTotals = {};

            aQOHColumns.forEach(col => {
                oTotals[col] = 0;
            });
            aData.forEach(item => {
                if (item.material === "") {
                    return;
                }
                aQOHColumns.forEach(col => {
                    oTotals[col] += Number(item[col]) || 0;
                });
            });
            aQOHColumns.forEach(col => {
                oTotalRow[col] = oTotals[col];
            });
            this.getModel(sModelName).refresh(true);
        },




        /* called when user clicks "Reset" button on Supplying Report tab.
           Resets the search criteria and fetches the default data from the backend to be displayed in the table.
           @param {} 
           @public
           @memberof com.slb.chxkanban.controller.Main
        */
        onSupplyingReportReset() {
            const clear = false;
            this._clearAdvancedFilter();
            this._resetSearchFields(clear);
            this._cleanSortSuppReport();
            // reset table personalization
            this._resetTablePersonalization("idSupplyingReportTable");
            const supplyingPlantObj = {};
            supplyingPlantObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            supplyingPlantObj.partGroup = "";
            supplyingPlantObj.search = "";
            supplyingPlantObj.material = "";
            // this._setDefaultPagination();
            this._iTopSuppReport = this.getModel("mainView").getProperty("/objPagination/suppReportPageSize") || 20;
            supplyingPlantObj.skip = 0;

            this._getSupplyingPlantData(supplyingPlantObj).then((data) => {
                this._supplyingTableBinding(data);
                // clear table selection for table
                this.byId("idSupplyingReportTable").clearSelection();
                this.getModel("mainView").setProperty("/searchSupplyingReports", "");
                this.byId("idSupplyingReportTable")?.clearSelection();
            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        _cleanSortSuppReport() {
            this._sortPropertySupp = null;
            this._suppOrderSorting = null;
            this.getModel("mainView").setProperty("/sortPropertyTableP13Supp", null);

        },
        /* called when user clicks "Reset" button on Receiving Report tab.
           Resets the search criteria and fetches the default data from the backend to be displayed in the table.
           @param {} 
           @public
        */
        onReceivingReportsReset() {
            this._clearAdvancedFilter();
            this._cleanReceSortOrder();
            const clear = true;
            this._resetSearchFields(clear);
            // reset table personalization
            this._resetTablePersonalization("idReceivingOrderReportTable");
            const oPlantObj = {};
            oPlantObj.plant = this.oDashBoardModel.getProperty("/selectedPlant") || "";
            oPlantObj.partGroup = "";
            oPlantObj.search = "";
            oPlantObj.material = "";
            this._iTop = this.getModel("mainView").getProperty("/objPagination/receReportPageSize") || 20;
            oPlantObj.skip = 0;
            this._getReceivingPlant(oPlantObj).then((data) => {
                this._recevingTableBinding(data);

                //clear table selection for table
                this.byId("idReceivingOrderReportTable").clearSelection();

                this.getModel("mainView").setProperty("/searchReceivingReports", "");

            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        _cleanReceSortOrder() {
            this._sortProperty = null;
            this._receOrderSorting = null;
            this.getModel("mainView").setProperty("/sortPropertyTableP13Rece", null);

        },
        /* Utility function to reset the search fields in the Receiving Report tab after the user clicks the "Reset" button.
           Clears the values of the search fields in the model to reflect the reset state in the UI.
           @param {}
           @private
        */
        _resetSearchFields: function (clean) {
            if (clean) {
                this.getModel("mainView").setProperty("/searchReceivingReports", "");
                this.getModel("mainView").setProperty("/materialForSearch", "");
                this.getModel("mainView").setProperty("/partGroupReceSearch", "");

            } else {
                this.getModel("mainView").setProperty("/searchSupplyingReports", "");
                this.getModel("mainView").setProperty("/supplyingMaterial", "");
                this.getModel("mainView").setProperty("/supplyingPartGroup", "");

            }

        },
        /*  odessa report Excel export handler.
            Calls the downloadExcel function in the backend which generates the Excel file and returns it as a response. 
            The frontend then triggers the download of the Excel file.
            @param {}
            @public
        */
        async onExportSupplyingExcel() {

            const aSelectedRows = this._getSelectedRowsData("idSupplyingReportTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/supplyingPlantData");

                aData = await this._getSupplyingPlantDownloadData();
            } else {
                aData = this._fnFotterSumSupplyingReport(aSelectedRows, "/supplyingPlantData");
            }
            // const aColumns = Object.keys(aData[0]).map((key) => {
            //     return {
            //         label: this._getColumnText(key),
            //         property: key,
            //         type: "string"
            //     };
            // });

            const oTable = this.byId("idSupplyingReportTable");

            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            DownloadFile.DynamicExcelDownload(aColumns, this._removeDuplicateTotal(aData), "Supplying_Report");

        },

        async _getSupplyingPlantDownloadData() {
            const iTop = this.getModel("mainView").getProperty("/supplyingPlantDataCount") || 0;

            const downloadData = await this._getSupplyingPlantData(null, iTop);

            const aData = downloadData.demandReportItems;

            // Calculate totals
            const oTotal = {
                material: "",
                description: "",
                partGroup: "",
                supplyingPlant: "",
                supplyingPlantName: "",
                receivingPlant: "",
                receivingPlantName: "",

                productionDemand: 0,
                receivingPlantDemand: 0,
                shippedQty: 0,
                supplyingPlantMax: 0,
                supplyingPlantQohWip: 0
            };

            aData.forEach(function (item) {
                oTotal.productionDemand += Number(item.productionDemand || 0);
                oTotal.receivingPlantDemand += Number(item.receivingPlantDemand || 0);
                oTotal.shippedQty += Number(item.shippedQty || 0);
                oTotal.supplyingPlantMax += Number(item.supplyingPlantMax || 0);
                oTotal.supplyingPlantQohWip += Number(item.supplyingPlantQohWip || 0);
            });

            // Add TOTAL row at the end
            aData.push(oTotal);

            return aData;


        },

        /*  Supplying order report PDF export handler.
            Calls the downloadPDF function in the backend which generates the PDF and returns it as a response. 
            The frontend then triggers the download of the PDF file.
            @param {}
            @public
        */
        async onExportSupplyingPDF() {

            const aSelectedRows = this._getSelectedRowsData("idSupplyingReportTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/supplyingPlantData");

                aData = await this._getSupplyingPlantDownloadData();
            } else {
                aData = this._fnFotterSumSupplyingReport(aSelectedRows, "/supplyingPlantData");
            }

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            this._pdfDownloadForOrderReport(this._removeDuplicateTotal(aData), "Supplying_Report", "idSupplyingReportTable");


        },

        async onPdfDownloadReccOrder() {
            const aSelectedRows = this._getSelectedRowsData("idReceivingOrderReportTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/receivingPlantData");
                aData = await this._getReceivingorderPlantDownloadData();
            } else {
                aData = this._fnFotterSumSupplyingReport(aSelectedRows, "/receivingPlantData");
            }
            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }

            this._pdfDownloadForOrderReport(this._removeDuplicateTotal(aData), "Receiving_Report", "idReceivingOrderReportTable");

        },

        _pdfDownloadForOrderReport: async function (aData, fileName, tableId) {


            const { jsPDF } = window.jspdf;
            // eslint-disable-next-line new-cap  
            const doc = new jsPDF({
                orientation: "landscape"
            });

            // const aColumns = Object.keys(aData[0]);
            const oTable = this.byId(tableId);
            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));
            if (aColumns.length === 0) {
                return;

            }
            const aRows = aData.map(item =>
                aColumns.map(col => item[col.property])
            );
            const aFormattedColumns = aColumns.map(col => {
                return this._getColumnText(col.property);
            });

            window.autoTable(doc, {
                head: [aFormattedColumns],
                body: aRows,
                theme: "grid",
                styles: {
                    fontSize: 8
                }
            });

            doc.save(fileName + ".pdf");

        },


        async onReceivingCompExportPDF() {

            const aSelectedRows = this._getSelectedRowsData("idReceComparisonTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/comparisonRecevingData");
                // aData = this.getModel("ComparisonReport").getData();
                aData = await this._getReceivingComparisonDownloadData();
            } else {
                aData = this._fnFotterSumComp(aSelectedRows, "/comparisonRecevingData");
            }

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }

            this._PDFfownloadComparisonReport(this._removeDuplicateTotal(aData), "Comparison_Report.pdf", "idReceComparisonTable");
        },

        async onSupplyingCompExportPDF() {
            const aSelectedRows = this._getSelectedRowsData("idSupplyingComparisonTableId");
            let aData;
            if (aSelectedRows.length === 0) {
                //aData = this.getModel("mainView").getProperty("/comparisonSupplyingData");
                // aData = this.getModel("SupplyingComparison").getData();
                aData = await this._getSupplyingComparisonDownloadData();

            } else {
                aData = this._fnFotterSumComp(aSelectedRows, "/comparisonSupplyingData");
            }
            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            this._PDFfownloadComparisonReport(this._removeDuplicateTotal(aData), "Supplying_Report.pdf", "idSupplyingComparisonTableId");

        },

        _PDFfownloadComparisonReport(aData, sFileName, tableId) {

            const { jsPDF } = window.jspdf;
            // eslint-disable-next-line new-cap  
            const doc = new jsPDF({
                orientation: "landscape"
            });

            const oTable = this.byId(tableId);
            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));

            if (aColumns.length === 0) {
                return;

            }
            const aRows = aData.map(item =>
                aColumns.map(col => item[col.property])
            );
            const aFormattedColumns = aColumns.map(col => {
                return this._getColumnText(col.property);
            });



            // aColumns = aColumns.filter(
            //     sColumn => !sColumn.includes("_CLR")
            // );

            window.autoTable(doc, {
                head: [aFormattedColumns],
                // body: aData.map(item => aFormattedColumns.map(col => item[col])),
                body: aRows,
                theme: "grid",
                styles: {
                    fontSize: 8
                }
            });

            doc.save(sFileName);

        },

        /* Function to fetch the part types for the search dropdown.
           Makes a call to the backend to get the distinct part types based on the selected plant and binds it to the dropdown model.
           @param {}
           @returns {Promise} - A promise that resolves with the part types data or rejects with an error.
           @private
        */

        _fnReportBinding(selectedObject) {
            this._setDefaultPagination();

            Promise.all([this._getMaterialAPI(),
            this._fnPartTypeSearch(),
            this._fnGetPlants()
            ]).then(([oMaterials, oPartTypes, oPlants]) => {
                this.getModel("mainView").setProperty("/materialsData", oMaterials);
                this.getModel("mainView").setProperty("/partTypeForSearch", oPartTypes);

                this.getModel("mainView").setProperty("/plantsDetails", oPlants);
                this.getModel("mainView").setProperty("/selectedReceComparisonPlant", [oPlants[0]?.plant]);
                this.getModel("mainView").setProperty("/selectedReceComparisonPlantName", [oPlants[0]?.plantName]);
                this.getModel("mainView").setProperty("/selectedSuppComparisonPlant", [oPlants[0]?.plant]);
                this.getModel("mainView").setProperty("/selectedReceInventoryPlant", oPlants[0]?.plant);
                this.getModel("mainView").setProperty("/selectedSuppInventoryPlant", oPlants[0]?.plant);
                this._fnReportDataBinding(selectedObject);
            }).catch((error) => {
                this.showErrorMessage(error.message);
            });
        },


        /*Receiving plant report Excel export handler.
           Calls the downloadExcel function in the backend which generates the Excel file and returns it as a response. 
           The frontend then triggers the download of the Excel file.
           @param {}
           @public
        */
        // onExportExcelReceivingPlants: function () {
        //     const aSelectedRows = this._getSelectedRowsData("idReceivingOrderReportTable");
        //     let aData;
        //     if (aSelectedRows.length === 0) {
        //         aData = this.getModel("mainView").getProperty("/receivingPlantData");
        //     } else {
        //         aData = this._fnFotterSumSupplyingReport(aSelectedRows, "/receivingPlantData");
        //     }
        //     const aColumns = Object.keys(aData[0]).map((key) => {
        //         return {
        //             label: this._getColumnText(key),
        //             property: key,
        //             type: "string"
        //         };
        //     });



        //     DownloadFile.DynamicExcelDownload(aColumns, this._removeDuplicateTotal(aData), "Receiving_Report");

        // },


        async _getReceivingorderPlantDownloadData() {

            const iTop = this.getModel("mainView").getProperty("/receivingPlantDataCount") || 0;

            const downloadData = await this._getReceivingPlant(null, iTop);



            // Get the array
            var aData = downloadData?.orderReportItems;

            // Calculate totals
            var iReceivingPlantQty = 0;
            var iSupplyingPlantQoh = 0;

            aData.forEach(function (item) {
                iReceivingPlantQty += Number(item.receivingPlantOrderQty || 0);
                iSupplyingPlantQoh += Number(item.supplyingPlantQoh || 0);
            });

            // Add dummy total row
            aData.push({
                description: "",
                material: "",
                partGroup: "",
                receivingPlant: "",
                receivingPlantName: "",
                receivingPlantOrderQty: iReceivingPlantQty,
                supplyingPlant: "",
                supplyingPlantName: "",
                supplyingPlantQoh: iSupplyingPlantQoh


            });

            return aData;

        },

        onExportExcelReceivingPlants: async function () {

            const oTable = this.byId("idReceivingOrderReportTable");

            const aSelectedRows = this._getSelectedRowsData("idReceivingOrderReportTable");

            let aData;

            if (aSelectedRows.length) {

                aData = this._fnFotterSumSupplyingReport(aSelectedRows, "/receivingPlantData");

            } else {
                aData = await this._getReceivingorderPlantDownloadData();

            }


            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }

            DownloadFile.DynamicExcelDownload(
                aColumns,
                this._removeDuplicateTotal(aData),
                "Receiving_Report"
            );

        },

        _hasOnlyTotalRow(aData) {

            if (!aData || aData.length === 0) {
                return true;
            }

            return aData.every(function (oItem) {
                return !oItem.material &&
                    !oItem.description &&
                    !oItem.partGroup;
            });

        },




        _removeDuplicateTotal(aData) {

            // let bTotalFound = false;

            // return aData.filter(function (oItem) {

            //     if (oItem.material === "") {

            //         if (bTotalFound) {
            //             return false;
            //         }

            //         bTotalFound = true;
            //     }

            //     return true;
            // });

            let bTotalFound = false;

            return aData.filter(function (oItem) {

                const bIsTotalRow =
                    !oItem.material &&
                    !oItem.description &&
                    !oItem.partGroup;

                if (bIsTotalRow) {

                    if (bTotalFound) {
                        return false;
                    }

                    bTotalFound = true;
                }

                return true;
            });

        },
        /* eslint-disable consistent-return */
        async _getSupplyingComparisonDownloadData() {
            const iTop = this.getModel("mainView").getProperty("/comparisonSupplyingCount") || 0;

            const data = await this._getSupplyingPlantComparison(null, iTop);
            if (data?.value?.length === 0) {
                return;

            }
            const aFormattedData = this._compresionTableColumnModification(data?.value);

            // Last record is the dummy row
            const oTotal = aFormattedData[aFormattedData.length - 1];

            // Reset all *_QOH values in dummy row
            Object.keys(oTotal).forEach(function (key) {
                if (key.endsWith("_QOH")) {
                    oTotal[key] = 0;
                }
            });



            // Sum all records except the last (dummy row)
            for (let i = 0; i < aFormattedData.length - 1; i++) {

                const item = aFormattedData[i];

                Object.keys(item).forEach(function (key) {

                    if (key.endsWith("_QOH")) {
                        oTotal[key] += Number(item[key] || 0);
                    }

                });
            }


            return aFormattedData;


        },
        /* eslint-disable consistent-return */
        async _getReceivingComparisonDownloadData() {
            const iTop = this.getModel("mainView").getProperty("/comparisonRecevingCount") || 0;

            const data = await this._getRecevingPlantComparison(null, iTop);
            if (data?.value?.length === 0) {
                return;
            }
            const aFormattedData = this._compresionTableColumnModification(data?.value, "receiving");

            // Last record is the dummy row
            const oTotal = aFormattedData[aFormattedData.length - 1];

            // Reset all *_QOH values in dummy row
            Object.keys(oTotal).forEach(function (key) {
                if (key.endsWith("_QOH")) {
                    oTotal[key] = 0;
                }
            });



            // Sum all records except the last (dummy row)
            for (let i = 0; i < aFormattedData.length - 1; i++) {

                const item = aFormattedData[i];

                Object.keys(item).forEach(function (key) {

                    if (key.endsWith("_QOH")) {
                        oTotal[key] += Number(item[key] || 0);
                    }

                });
            }



            return aFormattedData;


        },



        /* Receiving plant report Excel export handler.*/
        async onReceivingCompExportExcel() {

            const aSelectedRows = this._getSelectedRowsData("idReceComparisonTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/comparisonRecevingData");
                // aData = this.getModel("ComparisonReport").getData();

                aData = await this._getReceivingComparisonDownloadData();
            } else {
                aData = this._fnFotterSumComp(aSelectedRows, "/comparisonRecevingData");
            }
            // const aColumns = Object.keys(aData[0]).map((key) => {
            //     return {
            //         label: this._getColumnText(key),
            //         property: key,
            //         type: "string"
            //     };
            // });
            const oTable = this.byId("idReceComparisonTable");

            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));
            if (aColumns.length === 0) {
                return;

            }

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            DownloadFile.DynamicExcelDownload(aColumns, this._removeDuplicateTotal(aData), "Comparison_Report");
        },
        /* Supplying plant report Excel export handler.*/
        async onSupplyingCompExportExcel() {
            const aSelectedRows = this._getSelectedRowsData("idSupplyingComparisonTableId");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/comparisonSupplyingData");
                // aData = this.getModel("SupplyingComparison").getData();

                aData = await this._getSupplyingComparisonDownloadData();

            } else {
                aData = this._fnFotterSumComp(aSelectedRows, "/comparisonSupplyingData");
            }
            // const aColumns = Object.keys(aData[0]).map((key) => {
            //     return {
            //         label: this._getColumnText(key),
            //         property: key,
            //         type: "string"
            //     };
            // });

            const oTable = this.byId("idSupplyingComparisonTableId");

            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.getLabel().getText(),
                    property: oColumn.data("p13nKey"),
                    type: "string"
                }));

            if (this._hasOnlyTotalRow(aData)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            DownloadFile.DynamicExcelDownload(aColumns, this._removeDuplicateTotal(aData), "Supplying_Report");
        },

        /* Utility function to calculate the sum of the QOH columns for the selected rows in the comparison reports and inject a total row at the end of the selected data.
           This function is used to provide a summary of the selected rows when exporting to Excel, allowing the user to see the totals for the selected data in the exported file.
           @param {Array} selectedData - The array of selected row data from the comparison report table
           @param {string} sModelPath - The path in the model where the full comparison report data is stored, used to find the total row object to inject the sums into
           @returns {Array} - The modified array of selected data with a total row appended at the end containing the sums of the QOH columns
           @private
        */
        _fnFotterSumComp(selectedData, sModelPath) {

            const aData = selectedData;
            const oTotalRow = this.getModel("mainView").getProperty(sModelPath).find(item => item.material === "");
            const aQOHColumns = Object.keys(aData?.[0]).filter(
                key => key.endsWith("_QOH")
            );
            const oTotals = {};

            aQOHColumns.forEach(col => {
                oTotals[col] = 0;
            });
            aData.forEach(item => {
                if (item.material === "") {
                    return;
                }
                aQOHColumns.forEach(col => {
                    oTotals[col] += Number(item[col]) || 0;
                });
            });
            aQOHColumns.forEach(col => {
                oTotalRow[col] = oTotals[col];
            });

            return [...selectedData, oTotalRow];

        },

        _fnFotterSumSupplyingReport(selectedData, sModelPath) {

            const aData = selectedData;
            const oTotalRow = this.getModel("mainView").getProperty(sModelPath).find(item => item.material === "");
            const aQOHColumns = Object.keys(aData?.[0]);
            const oTotals = {};

            aQOHColumns.forEach(col => {
                oTotals[col] = 0;
            });
            aData.forEach(item => {
                if (item.material === "") {
                    return;
                }
                aQOHColumns.forEach(col => {
                    oTotals[col] += Number(item[col]) || 0;
                });
            });
            aQOHColumns.forEach(col => {
                if (!(col === "material" || col === "description" || col === "partGroup")) {
                    oTotalRow[col] = oTotals[col];
                }

            });

            return [...selectedData, oTotalRow];

        },

        /* Utility function to calculate the sum of the QOH and Order Quantity for the selected rows in the Receiving Report and return an object containing the totals.
           This function is used to provide a summary of the selected rows when exporting to Excel, allowing the user to see the totals for the selected data in the exported file.
           @param {Array} aSelectedRows - The array of selected row data from the Receiving Report table
           @returns {Object} - An object containing the total QOH and Order Quantity for the selected rows, used to inject into the total row in the exported Excel file
           @private
        */

        _recReportSumExport: function (aSelectedRows) {
            let oFooterSumObj = {
                totalQOH: 0,
                totalOrderQty: 0,
                supplyingPlantQohWip: 0,
                shippedQty: 0,
                receivingPlantDemandQty: 0,
                productionDemandQty: 0
            };
            aSelectedRows.forEach(ctx => {
                oFooterSumObj.totalQOH += ctx.supplyingPlantQoh;
                oFooterSumObj.totalOrderQty += ctx.receivingPlantOrderQty;
            });
            return oFooterSumObj;

        },


        /* Utility function to get the data of the selected rows in a table based on the table ID.
           This function retrieves the selected indices from the table, gets the corresponding data objects for those indices, and returns an array of the selected row data.
           @param {string} sTableId - The ID of the table from which to get the selected rows data
           @returns {Array} - An array of data objects corresponding to the selected rows in the table
           @private
        */
        _getSelectedRowsData: function (sTableId) {
            const oTable = this.byId(sTableId);

            return oTable.getSelectedIndices()
                .map(iIndex => oTable.getContextByIndex(iIndex)?.getObject())
                .filter(Boolean);
        },


        /** 
         * Called after the view has been rendered. 
         * Used to update the table header counts for both the Odessa Ordered Report and the BA Kanban Report based on the data returned from the backend. 
         * This ensures that the counts are accurate and reflect any filters applied by the user.
         * @param
         * @public
         * @memberof com.slb.chxkanban.controller.Main
         * 
         */

        onAfterRendering() {



        },

        /* Handler for material selection change in the search criteria of the Receiving Report tab.
           Filters the material dropdown based on the user input to allow for easier selection of materials.
           @param {sap.ui.base.Event} oEvent - The event object from the material input change
           @public
        */
        onMaterialSelectionChange(oEvent) {
            const sValue = oEvent.getSource().getValue();
            const oCombo = oEvent.getSource();
            const oFilter = new Filter(
                "material", FilterOperator.Contains, sValue
            );
            oCombo.getBinding("items").filter([oFilter]);
        },

        /* Handler for part type selection change in the search criteria of the Receiving Report tab.
           Fetches the part types from the backend based on the user input and updates the dropdown model to reflect the filtered part types.
           @param {sap.ui.base.Event} oEvent - The event object from the part type input change
           @public
        */
        onPartTypeSelectionChange(oEvent) {
            const sValue = oEvent.getSource().getValue();
            this._fnPartTypeSearch(sValue).then((data) => {
                this.getModel("mainView").setProperty("/partTypeForSearch", data);
            }).catch((error) => {
                this.showErrorMessage(error.message);

            });

        },
        _fnColumnSum(oTable, bRecevingPlant) {
            const oBinding = oTable.getBinding("rows");
            const aContexts = oBinding.getCurrentContexts();
            let oFooterSumObj = {
                totalQOH: 0,
                totalOrderQty: 0,
                supplyingPlantQohWip: 0,
                shippedQty: 0,
                receivingPlantDemandQty: 0,
                productionDemandQty: 0,
                supplyingPlantMax: 0
            };
            if (bRecevingPlant) {
                aContexts.forEach(ctx => {
                    const obj = ctx.getObject();
                    // Skip dummy total row
                    if (obj.material === "") { return; }
                    oFooterSumObj.totalQOH += Number(obj.supplyingPlantQoh || 0);
                    oFooterSumObj.totalOrderQty += Number(obj.receivingPlantOrderQty || 0);
                });

            } else {

                aContexts.forEach(ctx => {
                    const obj = ctx.getObject();
                    // Skip dummy total row
                    if (obj.material === "") { return; }

                    oFooterSumObj.supplyingPlantMax += Number(obj.supplyingPlantMax || 0);
                    oFooterSumObj.supplyingPlantQohWip += Number(obj.supplyingPlantQohWip || 0);
                    oFooterSumObj.shippedQty += Number(obj.shippedQty || 0);
                    oFooterSumObj.receivingPlantDemandQty += Number(obj.receivingPlantDemand || 0);
                    oFooterSumObj.productionDemandQty += Number(obj.productionDemand || 0);

                });

            }
            return oFooterSumObj;
        },

        /* Utility function to recalculate the total QOH and Order Quantity for the Receiving Report table and inject it into the dummy total row at the end of the table.
           This function is called after the data is loaded and bound to the table to ensure that the total row reflects the correct sums based on the currently displayed data.
           @param {sap.ui.table.Table} oTable - The Receiving Report table for which to recalculate and inject the totals
           @private
        */

        _recalculateAndInject: function (oTable, bRecevingPlant) {
            let oFooterSum = this._fnColumnSum(oTable, bRecevingPlant);
            const oModel = this.getModel("mainView");
            if (bRecevingPlant) {
                const aData = oModel.getProperty("/receivingPlantData") || [];
                aData?.forEach((item, index) => {
                    if (item.material === "") {
                        oModel.setProperty(`/receivingPlantData/${index}/supplyingPlantQoh`, oFooterSum.totalQOH);
                        oModel.setProperty(`/receivingPlantData/${index}/receivingPlantOrderQty`, oFooterSum.totalOrderQty);
                    }
                });

            } else {
                const aData = oModel.getProperty("/supplyingPlantData") || [];
                aData.forEach((item, index) => {
                    if (item.material === "") {
                        oModel.setProperty(`/supplyingPlantData/${index}/supplyingPlantMax`, oFooterSum.supplyingPlantMax);
                        oModel.setProperty(`/supplyingPlantData/${index}/supplyingPlantQohWip`, oFooterSum.supplyingPlantQohWip);
                        oModel.setProperty(`/supplyingPlantData/${index}/shippedQty`, oFooterSum.shippedQty);
                        oModel.setProperty(`/supplyingPlantData/${index}/receivingPlantDemand`, oFooterSum.receivingPlantDemandQty);
                        oModel.setProperty(`/supplyingPlantData/${index}/productionDemand`, oFooterSum.productionDemandQty);
                    }
                });
            }
        },
        /* Utility function to fetch part types based on search text for the dropdown in the search criteria of the reports.
           Makes a call to the backend with the search text and returns the filtered part types to be displayed in the dropdown.
           @param {string} searchText - The text entered by the user in the part type search field
           @returns {Promise} - A promise that resolves with the filtered part types or rejects with an error
           @private
        */
        _fnPartTypeSearch(searchText) {

            return new Promise(async (resolve, reject) => {
                const sSearch = searchText || "";
                try {
                    const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    const oAction = this.getModel("dashboardService").bindContext("/getPartGroups(...)");
                    oAction.setParameter("plant", sPlant);
                    oAction.setParameter("search", sSearch);
                    await oAction.execute();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData?.value || []);
                } catch (error) {
                    reject(error);
                }
            });
        },

        _fnGetPlants() {

            return new Promise(async (resolve, reject) => {

                try {
                    const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    const oAction = this.getModel().bindContext("/getRelatedPlants(...)");
                    oAction.setParameter("plant", sPlant);
                    await oAction.execute();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData?.value || []);
                } catch (error) {
                    reject(error);
                }
            });
        },


        _getMaterialAPI() {

            return new Promise(async (resolve, reject) => {
                const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                const aFilters = [new Filter("plant", FilterOperator.EQ, sPlant),
                new Filter("board", FilterOperator.EQ, "Y")
                ];

                try {
                    const oBinding = this.getView().getModel("championService").bindList("/Material", undefined, undefined, aFilters);
                    const aContexts = await oBinding.requestContexts();
                    const aData = aContexts.map(oContext => oContext.getObject());
                    resolve(aData || []);
                } catch (error) {
                    reject(error);
                }
            });

        },

        /* called when user clicks on the column header to sort the Receiving Report table.
           Sorts the table based on the selected column and sort order. Also ensures that the total row (if present) is always at the bottom of the table and not affected by the sorting.
           @param {sap.ui.base.Event} oEvent - The event object from the column header click
           @public
        */

        onSort: function (oEvent) {
            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            const sPath = oColumn.getSortProperty();
            this._sortProperty = sPath;
            const bDesc = oEvent.getParameter("sortOrder") === "Descending";
            this._receOrderSorting = bDesc;
            const oModel = this.getModel("mainView");
            let aData = oModel.getProperty("/receivingPlantData");
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            oModel.setProperty("/receivingPlantData", aData);
        },

        onSortReceComparison(oEvent) {

            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            const sPath = oColumn.getSortProperty();
            const bDesc = oEvent.getParameter("sortOrder") === "Descending";
            this._sortReceComparisonProperty = sPath;
            this._receComparisonOrderSorting = bDesc;
            // const oModel = this.getModel("mainView");
            // let aData = oModel.getProperty("/receivingPlantData");
            let aData = this.getView().getModel("ComparisonReport").getData();
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            // oModel.setProperty("/receivingPlantData", aData);
            this.getView().getModel("ComparisonReport").setData(aData);


        },

        onSortSuppComprasion(oEvent) {
            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            const sPath = oColumn.getSortProperty();
            const bDesc = oEvent.getParameter("sortOrder") === "Descending";

            this._sortSupplyingComparisonProperty = sPath;
            this._supplyingComparisonOrderSorting = bDesc;
            // const oModel = this.getModel("mainView");
            // let aData = oModel.getProperty("/receivingPlantData");
            let aData = this.getView().getModel("SupplyingComparison").getData();
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            // oModel.setProperty("/receivingPlantData", aData);
            this.getView().getModel("SupplyingComparison").setData(aData);

        },

        onSortSuppCombinedInventory(oEvent) {
            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            let sPath = oColumn.getSortProperty();
            let bDesc = oEvent.getParameter("sortOrder") === "Descending";
            // re-map selected column to backend field if mapping exists
            let sortedColumn;
            if (this._fieldMapping[sPath]) {
                sortedColumn = this._fieldMapping[sPath];
            }

            this._sortSuppInventoryProperty = sortedColumn || sPath;
            this._suppInventoryOrderSorting = bDesc;
            // const oModel = this.getModel("mainView");
            // let aData = oModel.getProperty("/receivingPlantData");
            let aData = this.getView().getModel("supplyingCombinedInventoryModel").getData();
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            // oModel.setProperty("/receivingPlantData", aData);
            this.getView().getModel("supplyingCombinedInventoryModel").setData(aData);

        },

        onSortReceCombinedInventory(oEvent) {
            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            let sPath = oColumn.getSortProperty();
            const bDesc = oEvent.getParameter("sortOrder") === "Descending";

            // re-map selected column to backend field if mapping exists
            let sortedColumn;
            if (this._fieldMapping[sPath]) {
                sortedColumn = this._fieldMapping[sPath];
            }

            this._sortReceInventoryProperty = sortedColumn || sPath;
            this._receInventoryOrderSorting = bDesc;
            // const oModel = this.getModel("mainView");
            // let aData = oModel.getProperty("/receivingPlantData");
            // let aData = this.getView().getModel('SupplyingComparison').getData();
            let aData = this.getView().getModel("OdessaCombinedInventoryModel").getData();
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            // oModel.setProperty("/receivingPlantData", aData);
            this.getView().getModel("OdessaCombinedInventoryModel").setData(aData);

        },
        /* called when user clicks on the column header to sort the Supplying Report table.
          Sorts the table based on the selected column and sort order. Also ensures that the total row (if present) is always at the bottom of the table and not affected by the sorting.
          @param {sap.ui.base.Event} oEvent - The event object from the column header click
          @public
       */

        onSuppReportSort(oEvent) {

            oEvent.preventDefault();
            const oColumn = oEvent.getParameter("column");
            const sPath = oColumn.getSortProperty();
            this._sortPropertySupp = sPath;
            const bDesc = oEvent.getParameter("sortOrder") === "Descending";
            this._suppOrderSorting = bDesc;
            const oModel = this.getModel("mainView");
            let aData = oModel.getProperty("/supplyingPlantData");
            // Separate total row
            const oTotal = aData.find(item => item.material === "");
            const aNormal = aData.filter(item => item.material !== "");
            // Sort only normal data
            aNormal.sort((a, b) => {
                if (a[sPath] < b[sPath]) { return bDesc ? 1 : -1; }
                if (a[sPath] > b[sPath]) { return bDesc ? -1 : 1; }
                return 0;
            });
            // Reattach total at bottom
            aData = [...aNormal, oTotal];
            oModel.setProperty("/supplyingPlantData", aData);

        },

        /* Utility function to get the display text for a column based on the column key.
           This function checks the i18n model for a text corresponding to the column key and returns it. 
           If no text is found, it returns the column key itself as a fallback.
           @param {string} sColumn - The key of the column for which to get the display text
           @returns {string} - The display text for the column
           @private
        */

        _getColumnText: function (sColumn) {
            const oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            return oBundle.hasText(sColumn) ? oBundle.getText(sColumn) : sColumn;
        },

        /* Utility function to set the default pagination values for both the Receiving Report and Supplying Report tables.
           Initializes the pagination properties in the model to their default values, which are used to control the number of rows displayed and the current page for each report.
           @param {}
           @private
        */

        _setDefaultPagination() {

            //Report pagination
            this._iTop = 10;
            this._iPage = 0;
            this._iTopSuppReport = 10;
            this._iPageSuppReport = 0;

            // compression report pagination
            this._iTopRecComp = 10;
            this._iPageRecComp = 0;

            //supplying comparison
            this._iTopSuppComp = 10;
            this._iPageSuppComp = 0;

            // combined inventory report pagination

            this._iTopReceInventory = 10;
            this._iPageReceInventory = 0;

            this._iTopSuppInventory = 10;
            this._iPageSuppInventory = 0;

            const oPagination = {
                receReportPageSize: 10,
                receReportCurrentPage: 1,
                receReportTotalCount: 0,
                receReportTotalPages: 0,
                suppReportPageSize: 10,
                suppReportCurrentPage: 1,
                suppReportTotalCount: 0,
                suppReportTotalPages: 0,

                // Comparison report pagination
                receCompressionPageSize: 10,
                receCompressionTotalCount: 1,
                receCompressionTotalPages: 0,
                receCompressionPage: 10,

                suppCompressionPageSize: 10,
                suppCompressionTotalCount: 1,
                suppCompressionTotalPages: 0,
                suppCompressionPage: 10,


                // Comibined inventory report pagination
                suppCombinedInventoryPageSize: 10,
                suppCombinedInventoryTotalCount: 0,
                suppCombinedInventoryTotalPages: 0,
                suppCombinedInventoryPage: 1,

                receCombinedInventoryPageSize: 10,
                receCombinedInventoryTotalCount: 0,
                receCombinedInventoryTotalPages: 0,
                receCombinedInventoryPage: 1



            };
            this.getModel("mainView").setProperty("/objPagination", oPagination);
        },

        /* Event handler for changing the page size in the Receiving Report table from dropdown selection.
           Updates the page size in the model and reloads the data from the backend based on the new page size.
           @param {sap.ui.base.Event} oEvent - The event object from the page size change
           @public
        */

        onRecePageSizeChange(oEvent) {

            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/receReportPageSize", Number(skey));
            this.onLoadMoreOrderRep(iTop, iSkip);

        },

        onReceComparisonPageSizeChange(oEvent) {
            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/receCompressionPageSize", Number(skey));
            this.onLoadMoreReceComprarison(iTop, iSkip);

        },

        onReceCombinedInventoryPageSizeChange(oEvent) {
            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/receCombinedInventoryPageSize", Number(skey));
            this.onLoadMoreReceInventory(iTop, iSkip);

        },

        onSuppComparisonPageSizeChange(oEvent) {
            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/suppCompressionPageSize", Number(skey));
            this.onLoadMoreSuppComprarison(iTop, iSkip);


        },

        onSuppCombinedInventoryPageSizeChange(oEvent) {
            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/suppCombinedInventoryPageSize", Number(skey));
            this.onLoadMoreSuppInventory(iTop, iSkip);

        },

        onSuppPageSizeChange(oEvent) {
            const skey = oEvent.getSource().getSelectedKey();
            const iTop = Number(skey);
            const iSkip = 0;
            this.getModel("mainView").setProperty("/objPagination/suppReportPageSize", Number(skey));
            this.onLoadMoreSuppRep(iTop, iSkip);

        },

        _getPlantName() {
            const selectedPlant = this.oDashBoardModel.getProperty("/selectedPlant");
            const oPlantData = this.oDashBoardModel.getProperty("/plants");
            const plantObj = oPlantData.find(plant => plant.plant === selectedPlant);
            if (plantObj) {
                return plantObj.plantName;

            } else {
                return "";
            }

        },


        async onExportSuppInventoryPDF() {

            const aSelectedRows = this._getSelectedRowsData("idSuppCombinedInventoryTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/supplyingCombinedInventoryModel");
                // aData = this.getModel("supplyingCombinedInventoryModel").getData();
                aData = await this._getSupplyingInventoryDownloadData();

            } else {
                aData = this._fnFotterSumInventory(aSelectedRows, "/supplyingCombinedInventoryModel");
                // oSumData = this._fnPDFInventorySum(aData);

            }
            const oTable = this.byId("idSuppCombinedInventoryTable");
            if (this._hasOnlyTotalRow(aData?.data)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            this._PDFdownloadInventoryReport(this._removeDuplicateTotal(aData?.data), "SupplyingInventoryReport.pdf", "inventorySupplyingGroupHeaders", oTable);

        },


        async onExportReceInventoryPDF() {

            const aSelectedRows = this._getSelectedRowsData("idReceCombinedInventoryTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/OdessaCombinedInventoryModel");
                // aData = this.getModel("OdessaCombinedInventoryModel").getData();
                aData = await this._getReceivingInventoryDownloadData();

            } else {
                aData = this._fnFotterSumInventory(aSelectedRows, "/OdessaCombinedInventoryModel");

            }
            const oTable = this.byId("idReceCombinedInventoryTable");
            if (this._hasOnlyTotalRow(aData?.data)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            this._PDFdownloadInventoryReport(this._removeDuplicateTotal(aData?.data), "ReceivingInventoryReport.pdf", "inventoryReceivingGroupHeaders", oTable);

        },



        /* Utility function to calculate the sum of columns for the selected rows in the inventory reports and inject a total row at the end of the selected data.
           This function is used to provide a summary of the selected rows when exporting to Excel, allowing the user to see the totals for the selected data in the exported file.
           @param {Array} selectedData - The array of selected row data from the inventory report table
           @param {string} sModelPath - The path in the model where the full inventory report data is stored, used to find the total row object to inject the sums into
           @returns {Array} - The modified array of selected data with a total row appended at the end containing the sums of the relevant columns
           @private
        */

        /* eslint-disable consistent-return */
        _fnFotterSumInventory(aSelectedRows) {


            const aData = aSelectedRows;

            if (!aData.length) {
                return aData;
            }
            if (aData.length > 0) {

                const oTotalRow = {
                    material: ""
                };
                Object.keys(aData[0]).forEach(key => {
                    if (key === "material") {
                        oTotalRow[key] = "";
                    } else if (key === "description" || key === "partGroup" || key === "partGroupName" || key === "inTransit") {
                        oTotalRow[key] = "";
                    } else {
                        oTotalRow[key] = 0;

                    }
                });
                aData.push(oTotalRow);


            }

            if (aData.length > 0) {
                const oTotalRow = aData.find(item => item.material === "");
                if (!oTotalRow || !aData.length) {

                    return;
                }
                const aQOHColumns = Object.keys(aData[0]).filter(
                    key => key.includes("_")
                );
                const oTotals = {};

                aQOHColumns.forEach(col => {
                    oTotals[col] = 0;
                });
                aData.forEach(item => {
                    if (item.material === "") {

                        return;
                    }
                    aQOHColumns.forEach(col => {
                        oTotals[col] += Number(item[col]) || 0;
                    });
                });
                aQOHColumns.forEach(col => {
                    oTotalRow[col] = oTotals[col];
                });

            }

            return aData;

        },
        /* eslint-enable consistent-return */


        /* Handler for PDF export of the Receiving/Supplying Inventory Report.
           Uses the jsPDF library to generate a PDF document on the client side based on the data currently displayed in the Receiving Inventory Report table.
           The PDF is formatted with a landscape orientation and includes a table with the relevant columns and data. The generated PDF is then triggered for download in the user's browser.
           @param {}
           @public
         */

        _PDFdownloadInventoryReport(aData, sFileName, groupPath, oTable) {

            const { jsPDF } = window.jspdf;
            // eslint-disable-next-line new-cap  
            const doc = new jsPDF({
                orientation: "landscape",
                unit: "mm",
                format: "a3"
            });

            // const oMapping = this.getModel("mainView").getProperty(`/${groupPath}`);

            // const aHead = [
            //     [
            //         { content: "Material No.", rowSpan: 2 },
            //         { content: "Material Description", rowSpan: 2 },
            //         { content: "Part Group", rowSpan: 2 },
            //         { content: "In Transit", rowSpan: 2 },

            //         { content: oMapping.supplyingPlant, colSpan: 4 },
            //         { content: oMapping.receivingPlant, colSpan: 3 },
            //         { content: oMapping.combinedSummary, colSpan: 4 }
            //     ],
            //     [
            //         "MIN",
            //         "MAX",
            //         "QOH",
            //         "WIP",

            //         "MIN",
            //         "MAX",
            //         "QOH",

            //         "MIN",
            //         "MAX",
            //         "QOH",
            //         "WIP"
            //     ]
            // ];

            if (oTable.getColumns().filter(oCol => oCol.getVisible()).length === 0) {
                return;

            }



            const aRow1 = [];
            const aRow2 = [];

            let sCurrentGroup = "";
            let oCurrentGroup = null;

            oTable.getColumns()
                .filter(oCol => oCol.getVisible())
                .forEach(function (oCol) {

                    const aLabels = oCol.getMultiLabels();

                    // Material No, Description, Part Group, In Transit
                    if (aLabels.length === 1) {

                        aRow1.push({
                            content: aLabels[0].getText(),
                            rowSpan: 2
                        });

                        return;
                    }

                    // BA / Odessa / BA + Odessa
                    const sGroup = aLabels[0].getText();
                    const sChild = aLabels[1].getText();

                    if (sCurrentGroup !== sGroup) {

                        sCurrentGroup = sGroup;

                        oCurrentGroup = {
                            content: sGroup,
                            colSpan: 1
                        };

                        aRow1.push(oCurrentGroup);

                    } else {

                        oCurrentGroup.colSpan++;
                    }

                    aRow2.push(sChild);

                });

            const aHead = [aRow1, aRow2];

            const aBody = aData.map(oItem => [
                oItem.material,
                oItem.description,
                oItem.partGroup,
                oItem.inTransit,

                oItem.supplyingPlant_min,
                oItem.supplyingPlant_max,
                oItem.supplyingPlant_qoh,
                oItem.supplyingPlant_wip,

                oItem.receivingPlant_min,
                oItem.receivingPlant_max,
                oItem.receivingPlant_qoh,

                oItem.combinedSummary_min,
                oItem.combinedSummary_max,
                oItem.combinedSummary_qoh,
                oItem.combinedSummary_wip
            ]);

            window.autoTable(doc, {
                head: aHead,
                body: aBody,
                theme: "grid",
                styles: {
                    fontSize: 8,
                    halign: "center",
                    valign: "middle"
                },
                headStyles: {
                    fillColor: [0, 176, 80]
                },
                columnStyles: {
                    0: { cellWidth: 35 },
                    1: { cellWidth: 45 },
                    2: { cellWidth: 25 },
                    3: { cellWidth: 20 }
                }
            });

            doc.save(sFileName);

        },
        /* eslint-disable consistent-return */
        async onExportSuppInventoryExcel() {

            const aSelectedRows = this._getSelectedRowsData("idSuppCombinedInventoryTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("mainView").getProperty("/supplyingCombinedInventoryData");
                // aData = this.getModel("supplyingCombinedInventoryModel").getData();
                aData = await this._getSupplyingInventoryDownloadData();

            } else {
                aData = this._fnFotterSumInventory(aSelectedRows, "/supplyingCombinedInventoryModel");

            }
            // const aColumnsNew = this._columnConnversion(aData, "/inventorySupplyingGroupHeaders");
            const oTable = this.byId("idSuppCombinedInventoryTable");
            const aColumnsNew = this._columnConnversion(oTable);

            if (this._hasOnlyTotalRow(aData?.data)) {
                MessageToast.show("Please select at least one material.");
                return;
            }

            DownloadFile.DynamicExcelDownload(aColumnsNew, this._removeDuplicateTotal(aData?.data), "Supplying_Report");

        },

        async _getSupplyingInventoryDownloadData() {
            const iTop = this.getModel("mainView").getProperty("/supplyingInventoryDataCount") || 0;

            const oData = await this._getSuppInventoryApiCall(null, iTop);

            if (oData?.value.length === 0) {
                return;
            }

            const aFormattedData = this._formatedInventoryData(oData?.value);

            const oTotal = aFormattedData.data[aFormattedData.data.length - 1];

            // Reset numeric fields
            Object.keys(oTotal).forEach(function (key) {
                if (typeof oTotal[key] === "number") {
                    oTotal[key] = 0;
                }
            });



            for (let i = 0; i < aFormattedData.data.length - 1; i++) {

                const item = aFormattedData.data[i];

                Object.keys(item).forEach(function (key) {

                    const value = Number(item[key]);

                    if (!isNaN(value)) {
                        oTotal[key] = Number(oTotal[key] || 0) + value;
                    }

                });
            }



            return aFormattedData;


        },

        /* eslint-disable consistent-return */
        async _getReceivingInventoryDownloadData() {
            const iTop = this.getModel("mainView").getProperty("/receivingInventoryDataCount") || 0;

            const oData = await this._getRecevingInventoryRpt(null, iTop);
            if (oData?.value.length === 0) {
                return;
            }

            const aFormattedData = this._formatedInventoryData(oData?.value);

            const oTotal = aFormattedData.data[aFormattedData.data.length - 1];

            // Reset numeric fields
            Object.keys(oTotal).forEach(function (key) {
                if (typeof oTotal[key] === "number") {
                    oTotal[key] = 0;
                }
            });



            for (let i = 0; i < aFormattedData.data.length - 1; i++) {

                const item = aFormattedData.data[i];

                Object.keys(item).forEach(function (key) {

                    const value = Number(item[key]);

                    if (!isNaN(value)) {
                        oTotal[key] = Number(oTotal[key] || 0) + value;
                    }

                });
            }



            return aFormattedData;


        },

        async onExportRecInventroyExcel() {

            const aSelectedRows = this._getSelectedRowsData("idReceCombinedInventoryTable");
            let aData;
            if (aSelectedRows.length === 0) {
                // aData = this.getModel("OdessaCombinedInventoryModel").getData();

                aData = await this._getReceivingInventoryDownloadData();

            } else {
                aData = this._fnFotterSumInventory(aSelectedRows, "/OdessaCombinedInventoryModel");

            }
            const oTable = this.byId("idReceCombinedInventoryTable");
            const aColumnsNew = this._columnConnversion(oTable);

            if (this._hasOnlyTotalRow(aData?.data)) {
                MessageToast.show("Please select at least one material.");
                return;
            }
            // const aColumnsNew = this._columnConnversion(aData, "/inventoryReceivingGroupHeaders");

            DownloadFile.DynamicExcelDownload(aColumnsNew, this._removeDuplicateTotal(aData?.data), "ReceivingInventory_Report");

        },



        _columnConnversion(oTable) {
            // _columnConnversion(aData, sPath) {

            return oTable.getColumns()
                .filter(function (oColumn) {
                    return oColumn.getVisible() &&
                        oColumn.data("p13nKey"); // Ignore checkbox/row header columns
                })
                .map(function (oColumn) {

                    let sLabel = "";

                    // Handle MultiLabel
                    const aMultiLabels = oColumn.getMultiLabels();
                    if (aMultiLabels && aMultiLabels.length) {
                        sLabel = aMultiLabels
                            .map(function (oLabel) {
                                return oLabel.getText();
                            })
                            .join(" - ");   // BA - MIN
                    } else {
                        sLabel = oColumn.getLabel()?.getText() || "";
                    }

                    return {
                        label: sLabel,
                        property: oColumn.data("p13nKey"),
                        type: "string"
                    };
                });

            // const oMapping = this.getModel("mainView").getProperty(sPath);

            // return Object.keys(aData?.[0]).map(sKey => {

            //     const sMapKey = Object.keys(oMapping)
            //         .find(key => sKey.startsWith(key + "_"));

            //     let sLabel = sKey;

            //     if (sMapKey) {
            //         const sSuffix = sKey.substring(sMapKey.length);
            //         sLabel = oMapping[sMapKey] + sSuffix;
            //     }

            //     return {
            //         label: this._getColumnText(sLabel),
            //         property: sKey,
            //         type: "string"
            //     };
            // });
        },

        /* Handler for selection finish event of the plant multi-combo box in the Receiving Inventory Report filter.
           Updates the selected plants in the model based on the user's selection in the multi-combo box.
           @param {sap.ui.base.Event} oEvent - The event object from the selection finish event of the multi-combo box
           @public
        */

        onHandleSelectionFinishReceInventory(oEvent) {
            const aSelectedKeys = oEvent.getSource().getSelectedKey();
            this.getModel("mainView").setProperty("/selectedReceInventoryPlant", aSelectedKeys);
            this._getRecevingInventoryRpt().then((data) => {
                this._fnRecevingInventoryTableBinding(data);
            }).catch((err) => {
                this.showErrorMessage(err.message);
            });

        },

        /* Handler for selection finish event of the plant multi-combo box in the Supplying Inventory Report filter.
           Updates the selected plants in the model based on the user's selection in the multi-combo box.
           @param {sap.ui.base.Event} oEvent - The event object from the selection finish event of the multi-combo box
           @public
        */

        onHandleSelectionFinishSuppInventory(oEvent) {
            const aSelectedKeys = oEvent.getSource().getSelectedKey();
            this.getModel("mainView").setProperty("/selectedSuppInventoryPlant", aSelectedKeys);
            this._getSuppInventoryApiCall().then((data) => {
                this._fnSupplyingInventoryTableBinding(data);
            }).catch((err) => {
                this.showErrorMessage(err.message);

            });


        },


        onHandleFilterButtonPressed: function () {

            const aMetadata = [
                {
                    key: "material",
                    label: "Material No.",
                    path: "material",
                    dataType: "sap.ui.model.type.String"
                },
                {
                    key: "description",
                    label: "Material Description",
                    path: "description",
                    dataType: "sap.ui.model.type.String"
                },
                {
                    key: "partGroup",
                    label: "Part Group",
                    path: "partGroup",
                    dataType: "sap.ui.model.type.String"
                },
                {
                    key: "supplyingPlantQoh",
                    label: "BA QOH",
                    path: "supplyingPlantQoh",
                    dataType: "sap.ui.model.type.Integer"
                },
                {
                    key: "receivingPlantOrderQty",
                    label: "Order Quantity",
                    path: "receivingPlantOrderQty",
                    dataType: "sap.ui.model.type.Integer"
                }

            ];

            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idReceivingOrderReportTable"),
                metadata: aMetadata,
                filterId: "idReceivingOrderReportTable",

                getData: () => {
                    return this.getModel("mainView").getProperty("/receivingFullPlantData");
                },
                afterFilter: async (aData) => {
                    // this.getModel("mainView").setProperty("/receivingPlantData", aData);
                    // this.byId("idReceivingOrderReportTable").setVisibleRowCount(aData.length);
                    // this._recalculateAndInject(this.byId("idReceivingOrderReportTable"), true);
                    this.getView().getModel("mainView").setProperty("/receivingPlantAdvancedFilters", []);
                    let oData = await this._getReceivingPlant();
                    this._recevingTableBinding(oData);
                },

                onApplyReceivingTableBindingFilters: async (aFiltered) => {

                    // aFiltered.push(this._createReceivingTotal());
                    // this.getModel("mainView").setProperty("/receivingPlantData", aFiltered);
                    // this.byId("idReceivingOrderReportTable").setVisibleRowCount(aFiltered.length);
                    // this._recalculateAndInject(this.byId("idReceivingOrderReportTable"), true);

                    let oData = await this._getReceivingPlant();
                    this._recevingTableBinding(oData);

                },
                createDummyRow: () => {

                    return {
                        material: "",
                        description: "",
                        partGroup: "",
                        receivingPlantOrderQty: 0,
                        supplyingPlantQoh: 0
                    };

                }
            });

        },

        onHandleAdvFilterSuppRpt: function () {

            const aMetadata = [
                { key: "material", label: "Material No.", path: "material", dataType: "sap.ui.model.type.String" },
                { key: "description", label: "Material Description", path: "description", dataType: "sap.ui.model.type.String" },
                { key: "partGroup", label: "Material Group", path: "partGroup", dataType: "sap.ui.model.type.String" },
                { key: "supplyingPlantMax", label: "BA MAX", path: "supplyingPlantMax", dataType: "sap.ui.model.type.Integer" },
                { key: "supplyingPlantQohWip", label: "QOH + WIP", path: "supplyingPlantQohWip", dataType: "sap.ui.model.type.Integer" },
                { key: "shippedQty", label: "Shipped", path: "shippedQty", dataType: "sap.ui.model.type.Integer" },
                { key: "receivingPlantDemand", label: "Odessa Demand", path: "receivingPlantDemand", dataType: "sap.ui.model.type.Integer" },
                { key: "productionDemand", label: "BA Prod Demand", path: "productionDemand", dataType: "sap.ui.model.type.Integer" }

            ];

            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idSupplyingReportTable"),
                metadata: aMetadata,
                filterId: "idSupplyingReportTable",

                getData: () => {
                    return this.getModel("mainView").getProperty("/supplyingFullPlantData");
                },
                afterFilter: async (aData) => {
                    // this.getModel("mainView").setProperty("/supplyingPlantData", aData);
                    // this.byId("idSupplyingReportTable").setVisibleRowCount(aData.length);
                    // this._recalculateAndInject(this.byId("idSupplyingReportTable"), false);

                    this.getView().getModel("mainView").setProperty("/supplyingPlantAdvancedFilters", []);
                    let oData = await this._getSupplyingPlantData();
                    this._supplyingTableBinding(oData);
                },

                onApplySupplyTableBindingFilters: async (aFiltered) => {

                    // aFiltered.push(this._createReceivingTotal());

                    // aFiltered =await this.getDemandReportData("");
                    // aFiltered = aFiltered.demandReportItems;
                    // this.getModel("mainView").setProperty("/supplyingPlantData", aFiltered);
                    // this.byId("idSupplyingReportTable").setVisibleRowCount(aFiltered.length);
                    // this._recalculateAndInject(this.byId("idSupplyingReportTable"), false);

                    let oData = await this._getSupplyingPlantData();
                    this._supplyingTableBinding(oData);

                },
                createDummyRow: () => {

                    return {
                        description: "",
                        material: "",
                        partGroup: "",
                        partGroupName: "",
                        productionDemand: 0,
                        receivingPlantDemand: "",
                        shippedQty: 0,
                        supplyingPlantMax: "",
                        supplyingPlantQohWip: ""
                    };

                }
            });

        },

        onHandleAdvFilterSuppCompRpt: function () {
            const aFormattedData = this.getModel("mainView").getProperty("/comparisonSupplyingData") || [];
            const aStringFields = ["material", "description", "MaterialGroup"];
            const aMetadata = Object?.keys(aFormattedData?.[0] || {})
                .filter((sKey) => !sKey.includes("_CLR"))
                .map((sKey) => {

                    let obj = {
                        key: sKey,
                        label: this._getColumnText(sKey),
                        path: sKey,
                        dataType: aStringFields.includes(sKey)
                            ? "sap.ui.model.type.String"
                            : "sap.ui.model.type.Integer"
                    };

                    if (sKey.includes("_")) {
                        let comparisionPlantsList = this.getModel("mainView").getProperty("/plantsDetails");
                        let aAllPlants = this.oDashBoardModel.getProperty("/plants");
                        let plantName = sKey.split("_")?.[0];
                        let sPlantId = "";
                        aAllPlants.map((item) => {
                            if (item?.plantName === plantName) {
                                sPlantId = item?.plant;
                            }
                        });
                        comparisionPlantsList.map((item) => {
                            if (item?.plantName === plantName) {
                                sPlantId = item?.plant;
                            }
                        });
                        obj.sPlantId = sPlantId;
                    }

                    return obj;
                });

            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idSupplyingComparisonTableId"),
                metadata: aMetadata,
                filterId: "idSupplyingComparisonTableId",


                getData: () => {
                    return this.getModel("mainView").getProperty("/comparisonSupplyingData");
                },
                afterFilter: (aData) => {
                    // this.getModel("SupplyingComparison")?.setData(aData);
                    // this._fnOdessaComparisonSum("SupplyingComparison");
                    // const oTable = this.byId("idSupplyingComparisonTableId");
                    // oTable.setVisibleRowCount(aData.length);
                    // oTable.attachEventOnce("rowsUpdated", function () {
                    //     DynamicTable._applyComparisonTableColors(oTable, oTable._config);
                    // });

                    this._oController.getModel("mainView").setProperty("/supplyingPlantComparisonAdvancedFilters", []);
                    this.onSupplyingComparisonReportGo();
                },

                onApplySupplyingComparisonFilter: (aFiltered) => {
                    // this.getModel("SupplyingComparison")?.setData(aFiltered);
                    // this._fnOdessaComparisonSum("SupplyingComparison");
                    // const oTable = this.byId("idSupplyingComparisonTableId");
                    // oTable.setVisibleRowCount(aFiltered.length);
                    // oTable.attachEventOnce("rowsUpdated", function () {
                    //     DynamicTable._applyComparisonTableColors(oTable, oTable._config);
                    // });

                    this.onSupplyingComparisonReportGo();
                },
                createDummyRow: () => {

                    if (aFormattedData.length > 0) {
                        const oTotalRow = {};
                        Object.keys(aFormattedData[0]).forEach(key => {
                            if (key === "material") {
                                oTotalRow[key] = "";
                            } else if (
                                key === "description" ||
                                key === "MaterialGroup"
                            ) {
                                oTotalRow[key] = "";
                            } else {
                                oTotalRow[key] = 0;
                            }

                        });
                        return oTotalRow;
                    }

                    return {};



                }
            });

        },

        onHandleAdvFilterReceCompRpt: function () {
            const aFormattedData = this.getModel("mainView").getProperty("/comparisonRecevingData") || [];
            const aStringFields = ["material", "description", "MaterialGroup"];
            const aMetadata = Object.keys(aFormattedData?.[0])
                .filter((sKey) => !sKey.includes("_CLR"))
                .map((sKey) => {

                    let obj = {
                        key: sKey,
                        label: this._getColumnText(sKey),
                        path: sKey,
                        dataType: aStringFields.includes(sKey)
                            ? "sap.ui.model.type.String"
                            : "sap.ui.model.type.Integer"
                    };

                    if (sKey.includes("_")) {
                        let comparisionPlantsList = this.getModel("mainView").getProperty("/plantsDetails");
                        let aAllPlants = this.oDashBoardModel.getProperty("/plants");
                        let plantName = sKey.split("_")?.[0];
                        let sPlantId = "";
                        aAllPlants.map((item) => {
                            if (item?.plantName === plantName) {
                                sPlantId = item?.plant;
                            }
                        });
                        comparisionPlantsList.map((item) => {
                            if (item?.plantName === plantName) {
                                sPlantId = item?.plant;
                            }
                        });
                        obj.sPlantId = sPlantId;
                    }

                    return obj;

                });

            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idReceComparisonTable"),
                metadata: aMetadata,
                filterId: "idReceComparisonTable",

                getData: () => {
                    return this.getModel("mainView").getProperty("/comparisonRecevingData");
                },
                afterFilter: (aData) => {

                    // this.getModel("ComparisonReport").setData(aData);

                    // this._fnOdessaComparisonSum("ComparisonReport");
                    // const oTable = this.byId("idReceComparisonTable");
                    // oTable.setVisibleRowCount(aData.length);
                    // oTable.attachEventOnce("rowsUpdated", function () {
                    //     DynamicTable._applyComparisonTableColors(oTable, oTable._config);
                    // });
                    this._oController.getModel("mainView").setProperty("/receivingComparisonAdvancedFilters", []);
                    this.onReceivingComparisonGo();
                },

                onApplyReceComparisonAdvancedFilter: (aFiltered) => {
                    // this.getModel("ComparisonReport").setData(aFiltered);
                    // this._fnOdessaComparisonSum("ComparisonReport");
                    // const oTable = this.byId("idReceComparisonTable");
                    // oTable.setVisibleRowCount(aFiltered.length);
                    // oTable.attachEventOnce("rowsUpdated", function () {
                    //     DynamicTable._applyComparisonTableColors(oTable, oTable._config);
                    // });
                    this.onReceivingComparisonGo();

                },
                createDummyRow: () => {

                    if (aFormattedData.length > 0) {
                        const oTotalRow = {};
                        Object.keys(aFormattedData[0]).forEach(key => {
                            if (key === "material") {
                                oTotalRow[key] = "";
                            } else if (
                                key === "description" ||
                                key === "MaterialGroup"
                            ) {
                                oTotalRow[key] = "";
                            } else {
                                oTotalRow[key] = 0;
                            }

                        });
                        return oTotalRow;
                    }

                    return {};



                }
            });

        },

        onHandleFilterReceInventory() {

            const data = this.getModel("mainView").getProperty("/receivingInventoryFormatedData") || [];
            const oHeaderData = this.getModel("mainView").getProperty("/inventoryReceivingGroupHeaders");

            const aStringFields = [
                "material",
                "description",
                "partGroup"
            ];

            const aMetaData = Object.keys(data[0] || {}).map((sKey) => {

                let sLabel = sKey;

                if (sKey.includes("_")) {
                    const [sPrefix, sSuffix] = sKey.split("_");

                    if (oHeaderData[sPrefix]) {
                        sLabel = `${oHeaderData[sPrefix]}_${sSuffix}`;
                    }
                }

                return {
                    key: sKey,
                    label: this._getColumnText(sLabel),
                    path: sKey,
                    dataType: aStringFields.includes(sKey)
                        ? "sap.ui.model.type.String"
                        : "sap.ui.model.type.Integer"
                };
            });


            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idReceCombinedInventoryTable"),
                metadata: aMetaData,
                filterId: "idReceCombinedInventoryTable",

                getData: () => {
                    return data;
                },
                afterFilter: async (aData) => {
                    // set filtered data to model for table binding
                    this.getModel("OdessaCombinedInventoryModel").setData(aData);
                    // for footer sum
                    this._fnInventorySum("OdessaCombinedInventoryModel");
                    const oTable = this.byId("idReceCombinedInventoryTable");
                    oTable.setVisibleRowCount(aData.length);

                    this.getView().getModel("mainView").setProperty("/receivingPlantInventoryAdvancedFilters", []);
                    let oData = await this._getRecevingInventoryRpt();
                    this._fnRecevingInventoryTableBinding(oData);
                },

                onApplyReceCombinedTableBindingFilters: async (aFiltered) => {

                    // set filtered data to model for table binding
                    // this.getModel("OdessaCombinedInventoryModel").setData(aFiltered);
                    // // for footer sum
                    // this._fnInventorySum("OdessaCombinedInventoryModel");
                    // const oTable = this.byId("idReceCombinedInventoryTable");
                    // oTable.setVisibleRowCount(aFiltered.length);
                    this.onReceCombinedInventoryGo();
                    // let oData = await this._getRecevingInventoryRpt();
                    // this._fnRecevingInventoryTableBinding(oData);

                },
                createDummyRow: () => {
                    const aFormattedData = data;
                    //Dummy Sum Row Creation
                    if (aFormattedData.length > 0) {
                        const oTotalRow = {
                            material: ""
                        };
                        Object.keys(aFormattedData[0]).forEach(key => {
                            if (key === "material") {
                                oTotalRow[key] = "";
                            } else if (key === "description" || key === "partGroup" || key === "partGroupName" || key === "inTransit") {
                                oTotalRow[key] = "";
                            } else {
                                oTotalRow[key] = 0;

                            }
                        });
                        return oTotalRow;
                    }

                    return {};
                }
            });

        },

        onHandleFilterSuppInventory() {

            const data = this.getModel("mainView").getProperty("/supplyingCombinedInventoryData") || [];
            const oHeaderData = this.getModel("mainView").getProperty("/inventorySupplyingGroupHeaders");

            const aStringFields = [
                "material",
                "description",
                "partGroup"
            ];

            const aMetaData = Object.keys(data[0] || {}).map((sKey) => {

                let sLabel = sKey;

                if (sKey.includes("_")) {
                    const [sPrefix, sSuffix] = sKey.split("_");

                    if (oHeaderData[sPrefix]) {
                        sLabel = `${oHeaderData[sPrefix]}_${sSuffix}`;
                    }
                }

                return {
                    key: sKey,
                    label: this._getColumnText(sLabel),
                    path: sKey,
                    dataType: aStringFields.includes(sKey)
                        ? "sap.ui.model.type.String"
                        : "sap.ui.model.type.Integer"
                };
            });


            this._oAdvancedFilter.open({
                controller: this,
                view: this.getView(),
                table: this.byId("idSuppCombinedInventoryTable"),
                metadata: aMetaData,
                filterId: "idSuppCombinedInventoryTable",

                getData: () => {
                    return data;
                },
                afterFilter: async (aData) => {
                    // set filtered data to model for table binding
                    // this.getModel("supplyingCombinedInventoryModel").setData(aData);
                    // // for footer sum
                    // this._fnInventorySum("supplyingCombinedInventoryModel");
                    // const oTable = this.byId("idSuppCombinedInventoryTable");
                    // oTable.setVisibleRowCount(aData.length);

                    this.getView().getModel("mainView").setProperty("/supplyingPlantInventoryAdvancedFilters", []);
                    const oSupplyingInventoryData = await this._getSuppInventoryApiCall();
                    this._fnSupplyingInventoryTableBinding(oSupplyingInventoryData);

                },

                onApplySuppCombinedTableBindingFilters: async (aFiltered) => {

                    // set filtered data to model for table binding
                    // this.getModel("supplyingCombinedInventoryModel").setData(aFiltered);
                    // for footer sum
                    // this._fnInventorySum("supplyingCombinedInventoryModel");
                    // const oTable = this.byId("idSuppCombinedInventoryTable");
                    // oTable.setVisibleRowCount(aFiltered.length);
                    const oSupplyingInventoryData = await this._getSuppInventoryApiCall();
                    this._fnSupplyingInventoryTableBinding(oSupplyingInventoryData);

                },
                createDummyRow: () => {
                    const aFormattedData = data;
                    //Dummy Sum Row Creation
                    if (aFormattedData.length > 0) {
                        const oTotalRow = {
                            material: ""
                        };
                        Object.keys(aFormattedData[0]).forEach(key => {
                            if (key === "material") {
                                oTotalRow[key] = "";
                            } else if (key === "description" || key === "partGroup" || key === "partGroupName" || key === "inTransit") {
                                oTotalRow[key] = "";
                            } else {
                                oTotalRow[key] = 0;

                            }
                        });
                        return oTotalRow;
                    }

                    return {};
                }
            });

        },
        _clearAdvancedFilter() {
            this._oAdvancedFilter.clearFilters();
        },
        onOdessaReportTabSelect() {
            this._fnReportBinding();
        },
        onBAReportTabSelect() {
            this._fnReportBinding();


        },
        _resetTablePersonalization(tableId) {
            const oTable = this.byId(tableId);
            TableP13n._removeFilters(oTable);

        },
        _healthIndexTableBinding(aResponse) {
            const oData = this.formatter._prepareHealthIndexData(aResponse?.value);

            var oConfig = {

                tableId: "idHealthIndexTable",
                modelName: "oHealthIndex",
                data: {
                    results: oData.results,
                    months: oData.months
                },
                firstColumn: {
                    header: "Material Group",
                    field: "PartType",
                    width: ""
                },
                scoreField: "Score",
                gradeField: "Grade",
                gradeFormatter: null,
                formatter: formatter

            };
            var that = this;
            DynamicTable.createHealthIndexTable(that, oConfig);
            const oTable = this.byId("idHealthIndexTable");
            // const iColumnCount = 1;
            // oTable.setFixedColumnCount(iColumnCount);

            oTable.setVisibleRowCount(oData?.results?.length);

            oTable.attachRowsUpdated(() => {
                this.formatter._applyGradeColors2(oTable);
            });

        },

        _getHealthIndexData() {


            return new Promise(async (resolve, reject) => {

                const oModel = this.getModel("mainView");
                const sStartDate = oModel.getProperty("/startDate");
                const sEndDate = oModel.getProperty("/endDate");
                const oToday = new Date();
                oToday.setHours(0, 0, 0, 0);

                if (sStartDate) {
                    const oStartDate = new Date(sStartDate + "T00:00:00");

                    if (oStartDate > oToday) {
                        MessageBox.error("Start Date cannot be a future date.");
                        return;
                    }
                }

                if (sEndDate) {
                    const oEndDate = new Date(sEndDate + "T00:00:00");

                    if (oEndDate > oToday) {
                        MessageBox.error("End Date cannot be a future date.");
                        return;
                    }
                }

                try {
                    const sPlant = this.oDashBoardModel.getProperty("/selectedPlant");
                    const oAction = this.chartServiceModel.bindContext("/healthIndex(...)");
                    oAction.setParameter("plant", sPlant);
                    oAction.setParameter("startDate", sStartDate);
                    oAction.setParameter("endDate", sEndDate);
                    this.busy.open();
                    await oAction.execute();
                    this.busy.close();
                    const aData = oAction.getBoundContext().getObject();
                    resolve(aData);
                } catch (error) {
                    this.busy.close();
                    reject(error);

                }
            });

        },

        onHealthIndexGo() {
            this._getHealthIndexData().then((data) => {
                this._healthIndexTableBinding(data);
            }).catch((error) => {
                this.showErrorMessage(error.message);
            });
        },

        onHealthIndexReset() {
            this._cleanHealthIndexFilters();
            this._getHealthIndexData().then((data) => {
                this._healthIndexTableBinding(data);
            }).catch((error) => {
                this.showErrorMessage(error.message);
            });

        },

        _cleanHealthIndexFilters() {
            this._setDefultDateRange();

            // const oModel = this.getModel("mainView");
            // oModel.setProperty("/startDate", null);
            // oModel.setProperty("/endDate", null);

        },

        onExportExcelHealthIndex() {

            const aExportData = this.getModel("oHealthIndex").getProperty("/results");
            const data = this._prepareHealthIndexExportData(aExportData);

            const oTable = this.byId("idHealthIndexTable");

            const aColumns = oTable.getColumns()
                .filter(oColumn => oColumn.getVisible())
                .map(oColumn => ({
                    label: oColumn.data("exportLabel"),
                    property: oColumn.data("exportProperty"),
                    type: "string"
                }));
            DownloadFile.DynamicExcelDownload(aColumns, data, "HealthIndex");

        },

        _prepareHealthIndexExportData: function (aData) {

            return aData.map(function (oRow) {

                const oNewRow = {
                    PartType: oRow.PartType
                };

                Object.keys(oRow).forEach(function (sKey) {

                    if (typeof oRow[sKey] === "object" && oRow[sKey] !== null) {

                        oNewRow[`${sKey}_Score`] = oRow[sKey].Score;
                        oNewRow[`${sKey}_Grade`] = oRow[sKey].Grade;
                    }

                });

                return oNewRow;
            });

        },

        onPdfDownloadHealthIndex() {
            const aData = this.getModel("oHealthIndex").getProperty("/results");
            this._PDFdownloadHealthIndex(aData, "HealthIndex.pdf");

        },

        _PDFdownloadHealthIndex(aData, sFileName) {

            const { jsPDF } = window.jspdf;
            // eslint-disable-next-line new-cap 
            const doc = new jsPDF({
                orientation: "landscape",
                unit: "mm",
                format: "a3"
            });

            const aMonths = this.getModel("oHealthIndex").getProperty("/months");

            const aHeadRow1 = [
                {
                    content: "Material Group",
                    rowSpan: 2
                }
            ];

            const aHeadRow2 = [];

            aMonths.forEach(function (sMonth) {

                const sDisplayMonth = sMonth.replace(
                    /^([A-Za-z]{3})(\d{4})$/,
                    "$1-$2"
                );

                aHeadRow1.push({
                    content: sDisplayMonth,
                    colSpan: 2
                });

                aHeadRow2.push("Score");
                aHeadRow2.push("Grade");

            });

            const aBody = aData.map(function (oRow) {

                const aRow = [
                    oRow.PartType
                ];

                aMonths.forEach(function (sMonth) {

                    aRow.push(oRow[sMonth]?.Score || "");
                    aRow.push(oRow[sMonth]?.Grade || "");

                });

                return aRow;

            });

            window.autoTable(doc, {

                head: [
                    aHeadRow1,
                    aHeadRow2
                ],

                body: aBody,

                theme: "grid",

                styles: {
                    fontSize: 8,
                    halign: "center",
                    valign: "middle"
                },

                headStyles: {
                    fillColor: [0, 176, 80]
                },

                columnStyles: {
                    0: {
                        cellWidth: 35
                    }
                }

            });

            doc.save(sFileName);

        },

        _setDefultDateRange() {

            let dTodayDate = new Date();
            let dPreviousMonthDate = new Date(dTodayDate);
            dPreviousMonthDate.setMonth(dTodayDate.getMonth() - 12);

            dTodayDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(dTodayDate));
            dPreviousMonthDate = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" }).format(new Date(dPreviousMonthDate));
            const oModel = this.getModel("mainView");
            oModel.setProperty("/startDate", dPreviousMonthDate);
            oModel.setProperty("/endDate", dTodayDate);

        },
        onHealthIndexStartDateChange: function (oEvent) {

            const oDatePicker = oEvent.getSource();
            const oSelectedDate = oDatePicker.getDateValue();

            if (!oSelectedDate) {
                return;
            }

            const oToday = new Date();

            // Remove time part
            oToday.setHours(0, 0, 0, 0);
            oSelectedDate.setHours(0, 0, 0, 0);

            if (oSelectedDate > oToday) {

                MessageBox.error(this.oBundle.getText("FUTURE_DATE_ERROR"));

                return;
            }



        },

        /* eslint-disable camelcase */

        _inventoyCountFieldMapping() {

            this._fieldMapping = {

                combinedSummary_max: "combinedMax",
                combinedSummary_min: "combinedMin",
                combinedSummary_qoh: "combinedQoh",
                combinedSummary_wip: "combinedWip",
                description: "description",
                inTransit: "inTransit",
                material: "material",
                partGroup: "partGroup",
                receivingPlant_max: "receivingPlantMax",
                receivingPlant_min: "receivingPlantMin",
                receivingPlant_qoh: "receivingPlantQoh",
                supplyingPlant_max: "supplyingPlantMax",
                supplyingPlant_min: "supplyingPlantMin",
                supplyingPlant_qoh: "supplyingPlantQoh",
                supplyingPlant_wip: "supplyingPlantWip"


            };

            /* eslint-enable camelcase */

        },
        onHealthIndexEndDateChange(oEvent) {
            const oDatePicker = oEvent.getSource();
            const oSelectedDate = oDatePicker.getDateValue();

            if (!oSelectedDate) {
                return;
            }

            const oToday = new Date();

            // Remove time part
            oToday.setHours(0, 0, 0, 0);
            oSelectedDate.setHours(0, 0, 0, 0);

            if (oSelectedDate > oToday) {

                MessageBox.error(this.oBundle.getText("FUTURE_DATE_ERROR"));



                return;
            }

        }




    });
});