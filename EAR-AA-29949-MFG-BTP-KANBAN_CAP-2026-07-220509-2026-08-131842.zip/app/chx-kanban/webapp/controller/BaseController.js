sap.ui.define(["sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, UIComponent, MessageToast, MessageBox)
 {
    "use strict";

    return Controller.extend("com.slb.chxkanban.controller.BaseController",
        {

            /*
            =====================================================
            ROUTER
            =====================================================
            */

            getRouter: function () {
                return UIComponent.getRouterFor(this);
            },

            /*
            =====================================================
            MODEL
            =====================================================
            */

            getModel: function (sModelName) {
                return this.getView().getModel(sModelName);
            },
            setModel: function (oModel, sModelName) {
                return this.getView().setModel(oModel, sModelName);
            },

            /*
            =====================================================
            RESOURCE BUNDLE
            =====================================================
            */

            getResourceBundle: function () {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },

            /* callback to update the table title with the count of items in the table, both for initial load and when data is received or changed
             @param {string} sTableId - the ID of the table to update the title for
             @param {string} sTitleKey - the key of the title text in the resource bundle
             @param {string} sModelPath - the path in the model to set the updated title to
             @public
            */
            updateTableCount: function (sTableId, sTitleKey, sModelPath, sPlant1, sPlant2,dataCount) {

                const oTable = this.byId(sTableId);
                if (!oTable) {
                    return;
                }
                const oBinding = oTable.getBinding("rows");
                if (!oBinding) {
                    return;
                }


                const fnUpdate = function () {
                    let iCount = 0;
                    //Frontend filtering count
                    const aBindingLength = oBinding.getLength();

                    iCount = aBindingLength - 1; // -1 because of the sum row
                    if(iCount < 0){
                        iCount = 0;
                    }
                    let sTitle;
                    if(sPlant1 && sPlant2){
                        sTitle  = this.getResourceBundle().getText(sTitleKey, [sPlant1, sPlant2]); 

                    }else{
                        if(sTitleKey === "supplyingCompTitleText"){
                            sTitle  = this.getResourceBundle().getText("fragmentSupplyingComparisonReport.BAComparisonTitle"); 
                        }else{
                            sTitle  = this.getResourceBundle().getText(sTitleKey); 
                        }
                    }

                    if(dataCount !== undefined){
                        iCount = dataCount;
                    }
                    
                     this.getModel("mainView").setProperty(sModelPath, `${sTitle} (${iCount})`);
 
                }.bind(this);
                //Initial update
                fnUpdate();
                //Backend update
                oBinding.attachDataReceived(fnUpdate);
                //Frontend update
                oBinding.attachChange(fnUpdate);

            },

            _onDropDownValueChange: function(oEvent)
            {
                const sSelectedKey = oEvent.getSource().getSelectedKey();
                if(!sSelectedKey)
                {
                    oEvent.getSource().setValue("");
                }
            },
             getCookie: function(sName) 
            {
                const cookies = document.cookie.split(";");
                for (let i = 0; i < cookies.length; i++) 
                {
                    const cookie = cookies[i].trim();
                    if (cookie.startsWith(sName + "=")) 
                    {
                        return decodeURIComponent(cookie.substring(sName.length + 1));
                    }
                }
                return null;
            },

            /*
            =====================================================
            REBIND TABLE
            =====================================================
            */

            rebindTable: function (sTableId, sPath, sModelName) {
                const oTable = this.byId(sTableId);
                oTable.bindRows({ path: sModelName + ">" + sPath });
            },


            /* callback to show message toast           
             @param {string} sMessage - the message to show in the toast
             @public
            */
            showMessage: function (sMessage) {
                MessageToast.show(sMessage);
            },

            /* callback for table footer to set fixed bottom row count to 1 to show the sum row
            @param {sap.ui.table.Table} oTable - the table to set the footer for
            @public
            */
            setFooterForSum: function (oTable) {
                oTable.setFixedBottomRowCount(1);
            },

            /* callback to show error message box
             @param {string} sMessage - the message to show in the error box
             @public
            */

            showErrorMessage: function (sMessage) {
                MessageBox.error(sMessage);
            }
        });
               
    

});