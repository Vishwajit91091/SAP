
/* global $ */
sap.ui.define([], function () {
    "use strict";

    return {

        /**
      * Sums QOH and WIP quantities for display on the Kanban card.
      * @param {number} iQoh - quantity on hand
      * @param {number} iWip - work in progress quantity
      * @returns {number}
      */
        qohPlusWip: function (iQoh, iWip) {
            return (Number(iQoh) || 0) + (Number(iWip) || 0);
        },

        /**
         * Determines whether the stock-decrease (move) button should be enabled.
         * Enabled only when the input quantity is positive and does not exceed QOH.
         * @param {number} iQoh - quantity on hand
         * @param {number} iStockInput - quantity entered by the user
         * @returns {boolean}
         */
        isMoveEnabled: function (iQoh, iStockInput) {
            var nQoh = Number(iQoh) || 0;
            var nInput = Number(iStockInput) || 0;
            return nQoh >= nInput && nInput > 0;
        },


        recivingPlantVisibility: function (isReceivingPlant, isSupplyingPlant) {
            return isReceivingPlant ? true : false;
        },


        sendingPlantVisibility: function (isReceivingPlant, isSupplyingPlant) {
            return !isReceivingPlant && isSupplyingPlant ? true : false;
        },

        applyGradeColor: function (oEvent, sMonth) {

            const oControl = oEvent.getSource();
            const oContext = oControl.getBindingContext();

            if (!oContext) {
                return;
            }

            const sGrade = oContext.getProperty(sMonth + "/Grade");

            // Remove old classes
            oControl.removeStyleClass("greenCell1");
            oControl.removeStyleClass("yellowCell1");
            oControl.removeStyleClass("redCell1");

            // Add new class
            switch (sGrade) {

                case "A":
                case "B":
                    oControl.addStyleClass("greenCell1");
                    break;

                case "C":
                case "D":
                    oControl.addStyleClass("yellowCell1");
                    break;

                case "F":
                    oControl.addStyleClass("redCell1");
                    break;
            }
        },

             _prepareHealthIndexData(aResponse) {

            const aMonths = [];
            const aResults = [];

            aResponse.forEach(function (oGroup) {

                const oRow = {
                    PartType: oGroup.partGroup
                };

                oGroup.healthIndexItems.forEach(function (oItem) {

                    const d = new Date(oItem.month + "-01");

                    const sMonth =
                        d.toLocaleString("en", {
                            month: "short"
                        }) +
                        d.getFullYear();

                    if (!aMonths.includes(sMonth)) {
                        aMonths.push(sMonth);
                    }

                    oRow[sMonth] = {
                        Score: oItem.avgTotalScore,
                        Grade: oItem.grade
                    };

                });

                aResults.push(oRow);

            });

            return {
                results: aResults,
                months: aMonths
            };



        },
          DateFormat: function (sDate) {
            if (!sDate) {
                return "";
            }

            const [day, month, year] = sDate.split("/");
            return `${year}-${month}-${day}`;
        },

           _applyGradeColors2: function (oTable) {

            const aColumns = oTable.getColumns();
            const aRows = oTable.getRows();

            aRows.forEach(function (oRow) {

                const oContext = oRow.getBindingContext("oHealthIndex");

                if (!oContext) {
                    return;
                }

                const $Cells = oRow.$().find("td");

                aColumns.forEach(function (oColumn, iColIndex) {

                    if (oColumn.data("type") !== "GRADE") {
                        return;
                    }

                    const sMonth = oColumn.data("month");

                    const sGrade = oContext.getProperty(sMonth + "/Grade");
                    const $Cell = $($Cells[iColIndex]);

                    $Cell.removeClass("gradeA gradeB gradeC gradeD gradeF");

                    switch (sGrade) {
                        case "A":
                            $Cell.addClass("gradeA");
                            break;

                        case "B":
                            $Cell.addClass("gradeB");
                            break;

                        case "C":
                            $Cell.addClass("gradeC");
                            break;

                        case "D":
                            $Cell.addClass("gradeD");
                            break;

                        default:
                            $Cell.addClass("gradeF");
                    }

                });

            });

        },

        /**
         * 
         * @param {boolean} isReceivingPlant - if the current selected plant is receiving or not
         * @param {boolean} isSupplyingPlant - if the current selected plant is supplying or not
         * @returns {string} return the text based on plant type
         */

        getReportButtonText: function (isReceivingPlant, isSupplyingPlant) {
            if (isReceivingPlant) {
                return "Production Demand Report";
            } else if (isSupplyingPlant) {
                return "Order Report";
            } else {
                return "Reports";
            }
        }





    };
});