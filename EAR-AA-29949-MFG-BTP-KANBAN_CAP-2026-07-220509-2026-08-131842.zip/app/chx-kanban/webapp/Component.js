sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/slb/chxkanban/model/models",
    "com/slb/chxkanban/lib/jspdf.umd.min",
    "com/slb/chxkanban/lib/jspdf.plugin.autotable.min",
    "com/slb/chxkanban/lib/html2canvas.min",
    "com/slb/chxkanban/lib/xlsx.full.min"

], (UIComponent, models) => {
    "use strict";

    return UIComponent.extend("com.slb.chxkanban.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {

          
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // enable routing
            this.getRouter().initialize();
        }
    });
});