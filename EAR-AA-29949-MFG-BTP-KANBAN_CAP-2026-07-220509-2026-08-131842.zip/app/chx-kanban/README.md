## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon May 18 2026 18:18:30 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.24.0|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>Basic V4|
|**Service Type**<br>Local CAP|
|**Service URL**<br>http://localhost:4004/odata/v4/dashboard/|
|**Module Name**<br>chx-kanban|
|**Application Title**<br>ChampionX Kanban|
|**Namespace**<br>com.slb|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.148.0|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/@sap-ux/eslint-plugin-fiori-tools#rules for the eslint rules.|

## chx-kanban

An SAP Fiori application for ChampionX Kanban.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated app, start your CAP project:  and navigate to the following location in your browser:

http://localhost:4004/chx-kanban/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


